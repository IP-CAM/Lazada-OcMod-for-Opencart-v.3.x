<?php  
require_once( __DIR__."/../vendor/autoload.php");
require_once( __DIR__."/helper.php");

// Required for auth.
$appSecret = 'I4hGHMYSWuTvJobN8Lfs0sl1EnUZNIRl';
$appKey = '100765';
$token = '50000400b37foGiBs0owf90itCIrCzRhaEBqhrsXEffvI3Gqi1fb50cf9QfhX';

// Api url.
$endpoint = \Lazada\Sdk\Lazop\UrlConstants::API_GATEWAY_URL_MY;
// To enable exception logging.
$debugMode = true;
// For array to xml generation.
$generator = new \Lazada\Sdk\Generator();
$baseDirectory = getFile(__DIR__.'/../tmp/lazada');
// For file logging when debugMode is true. Use Monolog.
$logger = new \Monolog\Logger('LAZADA');
$logger->pushHandler(new \Monolog\Handler\StreamHandler(getFile($baseDirectory, 'lazada.log'), \Monolog\Logger::DEBUG));

$params = [
            'appSecret' => $appSecret,
            'appKey' => $appKey,
            'endpoint' => $endpoint,
            'token' => $token, // null if installation via code
            'refreshToken' => null, // null if installation via code
            'expiry' => '', // optional
            'refreshExpiry' => '', // optional
            'baseDirectory' => $baseDirectory, // where upload files are saved in debug mode = true.
            'generator' => $generator,
            'logger' => $logger,
            'debugMode' => $debugMode,
            'code' => null
];

$config = new \Lazada\Sdk\Api\Config($params);
$product =  new \Lazada\Sdk\Product($config);
/** @var \Lazada\Sdk\Api\Response $brands */
$brands = $product->getBrands();
print_r($brands);die;
