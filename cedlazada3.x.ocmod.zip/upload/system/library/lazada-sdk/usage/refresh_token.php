<?php
require_once( __DIR__."/../vendor/autoload.php");
require_once( __DIR__."/helper.php");

// Required for auth.
$code = isset($_GET['code']) ? $_GET['code'] : '';
$appSecret = 'I4hGHMYSWuTvJobN8Lfs0sl1EnUZNIRl';
$appKey = '100765';
$refreshToken = '50001400223xW5TpefrRjR8k9NWoShB3jWD1cbf5f75iTgsSEWdCRBNrjtiOi';

// Api url.
$endpoint = \Lazada\Sdk\Lazop\UrlConstants::API_GATEWAY_URL_MY;
// To enable exception logging.
$debugMode = false;
// For array to xml generation.
$generator = new \Lazada\Sdk\Generator();
$baseDirectory = getFile(__DIR__.'/../tmp/lazada');
// For file logging when debugMode is true. Use Monolog.
$logger = new \Monolog\Logger('LAZADA');
$logger->pushHandler(new \Monolog\Handler\StreamHandler(getFile($baseDirectory, 'lazada.log'), \Monolog\Logger::DEBUG));

$params = [
            'appSecret' => $appSecret,
            'appKey' => $appKey,
            'endpoint' => $endpoint,
            'token' => null, // null if installation via code
            'refreshToken' => $refreshToken, // null if installation via code
            'expiry' => '', // optional
            'refreshExpiry' => '', // optional
            'baseDirectory' => $baseDirectory, // where upload files are saved in debug mode = true.
            'generator' => $generator,
            'logger' => $logger,
            'debugMode' => $debugMode,
            'code' => $code
];

$config = new \Lazada\Sdk\Api\Config($params);
$api =  new \Lazada\Sdk\Api($config);
/** @var array $token */
$token = $api->refreshToken();
print_r($token);die;
