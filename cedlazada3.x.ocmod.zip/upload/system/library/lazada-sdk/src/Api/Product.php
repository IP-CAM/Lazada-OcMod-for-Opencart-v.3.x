<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @package     Lazada-Sdk
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license     http://cedcommerce.com/license-agreement.txt
 */

namespace Lazada\Sdk\Api;

class Product extends \Lazada\Sdk\Api\Api
{
    /**
     * Retrieve Category Tree
     * @param boolean $force
     * @link  https://lazada-sellercenter.readme.io/docs/getcategorytree
     * @return array
     */
    public function getCategories($force = false)
    {
        $categoryTree = array();
        try {
            $dir = $this->config->getBaseDirectory() . DS . 'categories';
            $name =  self::ACTION_GET_CATEGORIES .'-'. $this->config->getRegion() . '.json';
            $path = $dir . DS . $name;
            // if(!is_dir($dir))
            //     mkdir($dir, 0777, true);
            // chmod($path, 0777);

            // if (file_exists($path) && !$force) {
            //     $categoryTree = file_get_contents($path);
            //     $categoryTree = json_decode($categoryTree, true);
            // } else {
                $client = new \Lazada\Sdk\Api\Client($this->config);
                $request = new \Lazada\Sdk\Api\Request('/category/tree/get','GET');
                $response = $client->execute($request);
                
                $response = new \Lazada\Sdk\Api\Response($response);
                $response->setFeedFile($path);

                $getAction = $this->getActionsUrl('ACTION_GET_CATEGORIES');
                $response->setAction($getAction);
                // file_put_contents($this->getFile($dir, $name), json_encode($response->getBody()));
                $categoryTree = $response->getBody();
                // if (!empty($response->getBody()) and
                //     $response->getStatus() == \Lazada\Sdk\Api\Response::REQUEST_STATUS_SUCCESS
                // ) {
                //     file_put_contents($this->getFile($dir, $name), json_encode($response->getBody()));
                //     $categoryTree = $response->getBody();
                // }
            // }
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), array('path' => __METHOD__));
            }
        }

        return $categoryTree;
    }

    /**
     * Retrieve Attributes for a Category
     * @param null $categoryId
     * @param bool $force
     * @return array
     */
    public function getCategoriesAttributes($categoryId = null, $force = false)
    {
        $categoryAttributeTree = array();
        if (isset($categoryId)) {
            try {
                $dir = $this->config->getBaseDirectory() . DS . 'attributes';
                $name = self::ACTION_GET_CATEGORIES_ATTRIBUTES .'-'. $this->config->getRegion() . "-{$categoryId}.json";
                $path = $dir . DS . $name;

//                if(!is_dir($dir))
//                    mkdir($dir, 0777, true);
//                chmod($path, 0777);

                if (file_exists($path) && !$force) {
                    $categoryAttributeTree = file_get_contents($path);
                    $categoryAttributeTree = json_decode($categoryAttributeTree, true);
                } else {
                    $client = new \Lazada\Sdk\Api\Client($this->config);
                    $request = new \Lazada\Sdk\Api\Request('/category/attributes/get','GET');
                    $request->addApiParam("primary_category_id", $categoryId);
                    $response = $client->execute($request);
                    $response = new \Lazada\Sdk\Api\Response($response);
                    $response->setFeedFile($path);
                    $getAction = $this->getActionsUrl('ACTION_GET_CATEGORIES_ATTRIBUTES');
                    $response->setAction($getAction);
//                    file_put_contents($this->getFile($dir, $name), json_encode($response->getBody()));
                    $categoryAttributeTree = $response->getBody();
                    // if (!empty($response->getBody()) and
                    //     $response->getStatus() == \Lazada\Sdk\Api\Response::REQUEST_STATUS_SUCCESS
                    // ) {
                    //     file_put_contents($this->getFile($dir, $name), json_encode($response->getBody()));
                    //     $categoryAttributeTree = $response->getBody();
                    // }
                }
            } catch (\Exception $e) {
                if ($this->config->getDebugMode()) {
                    $this->config->getLogger()->debug($e->getMessage(), array('path' => __METHOD__));
                }
            }
        }

        return $categoryAttributeTree;
    }

    public function getProducts($params = array())
    {
        $products = new \Lazada\Sdk\Api\Response(array());
        try {
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/products/get','GET');
            foreach ($params as $id => $value) {
                $request->addApiParam($id, $value);
            }
            $products = $client->execute($request, $this->config->getAccessToken());
            //  echo '<pre>';print_r($products);die;
            //$products->load($response);
            //$getAction = $this->getActionsUrl('ACTION_GET_PRODUCTS');
            //$products->setAction($getAction);
            //$products->setAction(self::ACTION_GET_PRODUCTS);
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), array('path' => __METHOD__));
            }
        }
        return $products;
    }

    /**
     * @param array $params
     * @param bool $force
     * @return array|bool|mixed|string
     */
    public function getBrands($params = array(), $force = true)
    {
        //$response = new \Lazada\Sdk\Api\Response([]);
        //$response->setAction(self::ACTION_GET_BRANDS);
        $brands = array();
        try {
            $dir = $this->config->getBaseDirectory() . DS . 'brands';
            $name = self::ACTION_GET_BRANDS .'-'. $this->config->getRegion() . ".json";
            $path = $dir . DS . $name;
            
            // if(!is_dir($dir))
            //     mkdir($dir, 0777, true);
            // chmod($path, 0777);
            
//            if (file_exists($path) && !$force) {
//                $brands = file_get_contents($path);
//                $brands = json_decode($brands, true);
//            } else {
                $client = new \Lazada\Sdk\Api\Client($this->config);
                $request = new \Lazada\Sdk\Api\Request('/brands/get','GET');
                $request->addApiParam('offset',$params['offset']);
                $request->addApiParam('limit',$params['limit']);
                $response = $client->execute($request);

                $response = new \Lazada\Sdk\Api\Response($response);
//                 $response->setFeedFile($path);
                $getAction = $this->getActionsUrl('ACTION_GET_BRANDS');
                $response->setAction($getAction);
                
                // file_put_contents($this->getFile($dir, $name), json_encode($response->getBody()));
                $brands = $response->getBody();
                
                // if (!empty($response->getBody()) and
                //     $response->getStatus() == \Lazada\Sdk\Api\Response::REQUEST_STATUS_SUCCESS
                // ) {
                //     file_put_contents($this->getFile($dir, $name), json_encode($response->getBody()));
                //     $brands = $response->getBody();
                // }
//            }
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), array('path' => __METHOD__));
            }
        }
        return $brands;
    }

    /**
     * Create Product on Lazada
     * @param $data
     * @return Api\Response
     * @throws \Exception
     */
    public function createProduct($data)
    {
        $response = new \Lazada\Sdk\Api\Response(array());
        $getAction = $this->getActionsUrl('ACTION_POST_PRODUCT');
        $response->setAction($getAction);
        if (isset($data)) {
            $products = array(
                'Request' => array(
                    '_attribute' => array(),
                    '_value' => $data
                )
            );

            $generator = new \Lazada\Sdk\Api\Generator($this->config);
            $products = $generator->arrayToXml($products);

            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/product/create');
            $request->addApiParam('payload', $products->__toString());
//            echo '<pre>'; print_r($products->__toString()); die;
            $response = $client->execute($request, $this->config->getAccessToken());
            
            // $response->load($params);
            // if ($this->config->getDebugMode()) {
            //     $path = $this->getFile(
            //         $this->config->getBaseDirectory(),
            //         self::ACTION_POST_PRODUCT. '-' . $this->getSuffix() . '-' . $this->config->getRegion() . '.xml'
            //     );

            //     $products->save($path);
            //     $response->setFeedFile($path);
            // }
        }

        return $response;
    }

    /**
     * Update Product on Lazada
     * @param $data
     * @return Api\Response
     * @throws \Exception
     */
    public function updateProduct($data)
    {           
        $response = new \Lazada\Sdk\Api\Response(array());
        $getAction = $this->getActionsUrl('ACTION_POST_UPDATE_PRODUCT');
        $response->setAction($getAction);
        // if(!isset($data[0]['Product']))
         if(!isset($data['Product']))
        {
            $temp_array = $data;
            $data = array();
            $data['0'] = $temp_array;
        }
        // if (isset($data[0]['Product'])) {
          if (isset($data['Product'])) {
            $products = array(
                'Request' => array(
                    '_attribute' => array(),
                    '_value' => $data
                )
            );
             
            $generator = new \Lazada\Sdk\Api\Generator($this->config);
            $products = $generator->arrayToXml($products);
            //$products = $this->config->getGenerator()->arrayToXml($products);
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/product/update');
            $request->addApiParam('payload', $products->__toString());
            $response = $client->execute($request, $this->config->getAccessToken());

            // $response->load($params);

            // if ($this->config->getDebugMode()) {
            //     $path = $this->getFile(
            //         $this->config->getBaseDirectory(),
            //         self::ACTION_POST_UPDATE_PRODUCT. '-' . $this->getSuffix() . '-' . $this->config->getRegion() . '.xml'
            //     );
            //     $products->save($path);
            //     $response->setFeedFile($path);
            // }
        }

        return $response;
    }

    /**
     * Upload images to lazada
     * @param $data
     * @return Api\Response
     * @throws \Exception
     */
    public function uploadImages($data)
    {
        $response = new \Lazada\Sdk\Api\Response(array());
        $getAction = $this->getActionsUrl('ACTION_MIGRATE_IMAGE');
        $response->setAction($getAction);
        if (isset($data)) {
            $images = array(
                'Request' => array(
                    '_attribute' => array(),
                    '_value' => $data
                )
            );
            
            $generator = new \Lazada\Sdk\Api\Generator($this->config);
            $images = $generator->arrayToXml($images);
            // $images = $this->config->getGenerator()->arrayToXml($images);
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/image/migrate');
            $request->addApiParam('payload', $images->__toString());
            $response = $client->execute($request, $this->config->getAccessToken());
            // $response->load($params);

            // if ($this->config->getDebugMode()) {
            //     $path = $this->getFile(
            //         $this->config->getBaseDirectory(),
            //         self::ACTION_MIGRATE_IMAGE. '-' . $this->getSuffix() . '-' . $this->config->getRegion() . '.xml'
            //     );
            //     $images->save($path);
            //     $response->setFeedFile($path);
            // }
        }

        return $response;
    }

    /**
     * Update Inventory Price
     * @param $data
     * @return Api\Response
     * @throws \Exception
     */
    public function updateInventoryPrice($data)
    {
        $response = new \Lazada\Sdk\Api\Response(array());
        $getAction = $this->getActionsUrl('ACTION_POST_UPDATE_PRICE_QUANTITY');
        $response->setAction($getAction);
        // if(!isset($data[0]['Product']))
        if(!isset($data['Product']))
        {
            $temp_array = $data;
            $data = array();
            $data['0'] = $temp_array;
        }
       
        // if (isset($data[0]['Product'])) {
        if (isset($data['Product'])){
            $products = array(
                'Request' => array(
                    '_attribute' => array(),
                    '_value' => $data
                )
            );
            
            $generator = new \Lazada\Sdk\Api\Generator($this->config);
            $products = $generator->arrayToXml($products);
            //$products = $this->config->getGenerator()->arrayToXml($products);
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/product/price_quantity/update');
            $request->addApiParam('payload', $products->__toString());
//            echo '<pre>';print_r($products->__toString());die;
            $response = $client->execute($request, $this->config->getAccessToken());

            // $response->load($params);

            // if ($this->config->getDebugMode()) {
            //     $path = $this->getFile(
            //         $this->config->getBaseDirectory(),
            //         self::ACTION_POST_UPDATE_PRICE_QUANTITY. '-' . $this->getSuffix() . '-' .
            //         $this->config->getRegion() . '.xml'
            //     );
            //     $products->save($path);
            //     $response->setFeedFile($path);
            // }
        }
    
        
        return $response;
    }

    /**
     * Delete Product on Lazada
     * @param array $skus
     * @return Api\Response
     * @throws \Exception
     */
    public function deleteProduct($skus)
    {
        $response = new \Lazada\Sdk\Api\Response(array());
        $getAction = $this->getActionsUrl('ACTION_POST_DELETE_PRODUCT');
        $response->setAction($getAction);
        if (isset($skus) && is_array($skus)) {
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/product/remove');
            $request->addApiParam('seller_sku_list', json_encode($skus));
            $response = $client->execute($request, $this->config->getAccessToken());
            // $response->load($params);

            // if ($this->config->getDebugMode()) {
            //     $path = $this->getFile(
            //         $this->config->getBaseDirectory(),
            //         self::ACTION_POST_DELETE_PRODUCT. '-' . $this->getSuffix() . '-' .
            //         $this->config->getRegion() . '.json'
            //     );
            //     file_put_contents($path, json_encode($skus, JSON_PRETTY_PRINT));
            //     $response->setFeedFile($path);
            // }
        }

        return $response;
    }

    public static function getActionsUrl($action){
        if($action == 'ACTION_POST_PRODUCT')
            return self::ACTION_POST_PRODUCT;
        elseif($action == 'ACTION_POST_DELETE_PRODUCT')
            return self::ACTION_POST_DELETE_PRODUCT;
        elseif($action == 'ACTION_POST_UPDATE_PRODUCT')
            return self::ACTION_POST_UPDATE_PRODUCT;
        elseif($action == 'ACTION_POST_UPDATE_PRICE_QUANTITY')
            return self::ACTION_POST_UPDATE_PRICE_QUANTITY;
        elseif($action == 'ACTION_GET_ORDER_ITEMS_MULTIPLE')
            return self::ACTION_GET_ORDER_ITEMS_MULTIPLE;
        elseif($action == 'ACTION_GET_ORDER_ITEMS')
            return self::ACTION_GET_ORDER_ITEMS;
        elseif($action == 'ACTION_GET_ORDER')
            return self::ACTION_GET_ORDER;
        elseif($action == 'ACTION_GET_ORDERS')
            return self::ACTION_GET_ORDERS;
        elseif($action == 'ACTION_GET_BRANDS')
            return self::ACTION_GET_BRANDS;
        elseif($action == 'ACTION_GET_PRODUCTS')
            return self::ACTION_GET_PRODUCTS;
        elseif($action == 'ACTION_GET_CATEGORIES_ATTRIBUTES')
            return self::ACTION_GET_CATEGORIES_ATTRIBUTES;
        elseif($action == 'ACTION_GET_CATEGORIES')
            return self::ACTION_GET_CATEGORIES;
        elseif($action == 'ACTION_POST_SEARCH_SPU')
            return self::ACTION_POST_SEARCH_SPU;
        elseif($action == 'ACTION_POST_UPLOAD_IMAGE')
            return self::ACTION_POST_UPLOAD_IMAGE;
        elseif($action == 'ACTION_POST_UPLOAD_IMAGES')
            return self::ACTION_POST_UPLOAD_IMAGES;
        elseif($action == 'ACTION_GET_CANCEL_ORDER_ITEM_REASONS')
            return self::ACTION_GET_CANCEL_ORDER_ITEM_REASONS;
        elseif($action == 'ACTION_POST_CANCEL_ORDER_ITEM')
            return self::ACTION_POST_CANCEL_ORDER_ITEM;
        elseif($action == 'ACTION_GET_SHIPMENT_PROVIDERS')
            return self::ACTION_GET_SHIPMENT_PROVIDERS;
        elseif($action == 'ACTION_POST_SET_STATUS_TO_BE_PACKED_BY_MARKET_PLACE')
            return self::ACTION_POST_SET_STATUS_TO_BE_PACKED_BY_MARKET_PLACE;
        elseif($action == 'ACTION_POST_SET_STATUS_TO_READY_TO_SHIP')
            return self::ACTION_POST_SET_STATUS_TO_READY_TO_SHIP;
        elseif($action == 'ACTION_MIGRATE_IMAGES')
            return self::ACTION_MIGRATE_IMAGES;
        elseif($action == 'ACTION_MIGRATE_IMAGE')
            return self::ACTION_MIGRATE_IMAGE;
        else
            return self::$action;
    }
}
