<?php
require_once DIR_SYSTEM."library/lazada-sdk/Autoloader.php";
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End partner_id License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedlazada
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

//namespace Lazada\Sdk\Api;

class Cedlazada
{
    private $db;
    private $session;
    private $config;
    private $currency;
    private $request;
    private $weight;
    protected $timestamp;

    private static $instance;

    /**
     * @param  object $registry Registry Object
     */
    public static function getInstance($registry)
    {
        if (is_null(static::$instance)) {
            static::$instance = new static($registry);
        }

        return static::$instance;
    }

    /**
     * @param  object $registry Registry Object
     */
    public function __construct($registry)
    {
        $this->db = $registry->get('db');
        $this->session = $registry->get('session');
        $this->config = $registry->get('config');
        $this->currency = $registry->get('currency');
        $this->request = $registry->get('request');
        $this->weight = $registry->get('weight');
        $this->openbay = $registry->get('openbay');
        $this->timestamp = time();
    }

    public function isEnabled()
    {
        $flag = false;
        if ($this->config->get('cedlazada_status')) {
            $flag = true;
            $this->_init();
        }
        return $flag;
    }

    public function isCedlazadaInstalled()
    {
        if ($this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "cedlazada_install'")->num_rows) {
            return true;
        } else {
            return false;
        }
    }

    public function installCedlazada()
    {
        // Attribute
        $cedlazada_attribute = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_attribute` (
          `attribute_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `attribute_name` text COLLATE utf8_unicode_ci NOT NULL,
          `label` text COLLATE utf8_unicode_ci NOT NULL,
          `is_mandatory` tinyint(1) NOT NULL,
          `is_sale_prop` int(11) NOT NULL,
          `attribute_type` text COLLATE utf8_unicode_ci NOT NULL,
          `input_type` text COLLATE utf8_unicode_ci NOT NULL,
          `options` longtext COLLATE utf8_unicode_ci NOT NULL,
          `category_id` bigint(20) NOT NULL,
          `region_id` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`attribute_id`)
        ) ;";

        $created = $this->db->query($cedlazada_attribute);
        if ($created)
            $this->log("cedlazada_attribute table created", 6, true);

        // Brand
        $cedlazada_brand = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_brands` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `brand_id` bigint(11) NOT NULL,
          `brand_name` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_brand);
        if ($created)
            $this->log("cedlazada_brand table created", 6, true);

        // Category
        $cedlazada_category = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_category` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `category_id` bigint(11) NOT NULL,
          `category_name` text COLLATE utf8_unicode_ci NOT NULL,
          `leaf` int(11) NOT NULL,
          `is_active` int(11) NOT NULL,
          `label` text COLLATE utf8_unicode_ci NOT NULL,
          `region` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_category);
        if ($created)
            $this->log("cedlazada_category table created", 6, true);

        // Failure Reason
        $cedlazada_failure_reason = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_failure_reason` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `name` text COLLATE utf8_unicode_ci NOT NULL,
          `type` text COLLATE utf8_unicode_ci NOT NULL,
          `reason_id` int(11) NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_failure_reason);
        if ($created)
            $this->log("cedlazada_failure_reason table created", 6, true);

        $cedlazada_uploaded_products = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_uploaded_products` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `lazada_profile_id` int(11) NOT NULL,
          `lazada_item_id` bigint(20) NOT NULL,
          `lazada_status` text COLLATE utf8_unicode_ci NOT NULL,
          `lazada_request_id` text COLLATE utf8_unicode_ci NOT NULL,
          `sku_list` text COLLATE utf8_unicode_ci NOT NULL,
          `response_data` longtext COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_uploaded_products);
        if ($created)
            $this->log("cedlazada_uploaded_product table created", 6, true);

        // Profile
        $cedlazada_profile = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_profile` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `profile_status` int(11) NOT NULL,
          `profile_name` text COLLATE utf8_unicode_ci NOT NULL,
          `lazada_category_id` int(11) NOT NULL,
          `lazada_category_name` text COLLATE utf8_unicode_ci NOT NULL,
          `attributes_mapping` longtext COLLATE utf8_unicode_ci NOT NULL,
          `store_category` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_profile);
        if ($created)
            $this->log("cedlazada_profile table created", 6, true);

        // Profile Product
        $cedlazada_profile_products = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_profile_products` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `lazada_profile_id` int(11) NOT NULL,
          `error_message` text COLLATE utf8_unicode_ci NOT NULL,
          `uploaded_images` longtext COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_profile_products);
        if ($created)
            $this->log("cedlazada_profile_products table created", 6, true);

        // Product Attribute Combination
        $cedlazada_product_attribute_combination = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_product_attribute_combination` (
          `combination_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `lazada_profile_id` int(11) NOT NULL,
          `sku_id` text COLLATE utf8_unicode_ci NOT NULL,
          `combination` text COLLATE utf8_unicode_ci NOT NULL,
          `uploaded_images` longtext COLLATE utf8_unicode_ci NOT NULL,
          `shop_sku` text COLLATE utf8_unicode_ci NOT NULL,
          `lazada_sku_id` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`combination_id`)
        ) ;";

        $created = $this->db->query($cedlazada_product_attribute_combination);
        if ($created)
            $this->log("cedlazada_product_attribute_combination table created", 6, true);

        // Uploaded Products
        $cedlazada_uploaded_products = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_uploaded_products` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `lazada_item_id` bigint(20) NOT NULL,
          `lazada_status` text COLLATE utf8_unicode_ci NOT NULL,
          `response_data` longtext COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_uploaded_products);
        if ($created)
            $this->log("cedlazada_uploaded_products table created", 6, true);


        // Order
        $cedlazada_order = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_order` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `order_place_date` datetime DEFAULT NULL COMMENT 'Order Place Date',
          `opencart_order_id` int(11) DEFAULT NULL COMMENT 'Opencart Order Id',
          `status` text COLLATE utf8_unicode_ci COMMENT 'status',
          `order_data` text COLLATE utf8_unicode_ci COMMENT 'Order Data',
          `shipment_data` text COLLATE utf8_unicode_ci COMMENT 'Shipping Data',
          `lazada_order_id` text COLLATE utf8_unicode_ci COMMENT 'Reference Order Id',
          `order_item_data` text COLLATE utf8_unicode_ci COMMENT 'Order Item Data',
          `shipment_request_data` text COLLATE utf8_unicode_ci COMMENT 'Shipment Data send on shopee',
          `shipment_response_data` text COLLATE utf8_unicode_ci COMMENT 'Shipment Data get from shopee',
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_order);
        if ($created)
            $this->log("cedlazada_order table created", 6, true);

        // Order Error
        $cedlazada_order_error = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_order_error` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `lazada_order_id` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Purchase Order Id',
          `lazada_item_order_id` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Purchase Item Order Id',
          `merchant_sku` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT 'Reference_Number',
          `reason` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Reason',
          `order_data` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Order Data',
          `item_order_data` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Item Order Data',
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_order_error);
        if ($created)
            $this->log("cedlazada_order_error table created", 6, true);

        $cedlazada_shipment_provider = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedlazada_shipment_provider` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `name` text COLLATE utf8_unicode_ci NOT NULL,
          `cod` int(11) NOT NULL,
          `is_default` int(11) NOT NULL,
          `api_integration` int(11) NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedlazada_shipment_provider);
        if ($created)
            $this->log("cedlazada_shipment_provider table created", 6, true);


    }

    public function log($data, $force_log = false, $step = 6)
    {
        if ($this->config->get('cedlazada_debug') || $force_log) {
            $backtrace = debug_backtrace();
            $log = new Log('cedlazada.log');
            if (is_array($data))
                $data = json_encode($data);
            if (isset($backtrace[$step]) && isset($backtrace[$step]['class']) && isset($backtrace[$step]['class'])) {
                $log->write('(' . $backtrace[$step]['class'] . '::' . $backtrace[$step]['function'] . ') - ' . $data);
            } else {
                $log->write($data);
            }
        }
    }

    public function getAccessTokenFromLazada($data = array())
    {
        $UrlConstants = new \Lazada\Sdk\Api\UrlConstants();
        $endPoint = $UrlConstants->getRegionUrl('');

        $config = new \Lazada\Sdk\Api\Config(
            array(
                'appSecret' => $data['app_secret'],
                'appKey' => $data['app_key'],
                'endpoint' => $endPoint,
                'baseDirectory' => '',
                'debugMode' => false,
                'code' => $data['code'],
            )
        );

        $api = new \Lazada\Sdk\Api\Api($config);
        $response = $api->getToken();
        if($response['code'] == 0){
            foreach($response as $key => $value){
                if($key == 'refresh_token' || $key == 'access_token' || $key == 'refresh_expires_in' || $key == 'expires_in')
                {
                    $this->db->query("UPDATE " . DB_PREFIX . "setting SET `value` = '" . $this->db->escape($value) . "'  WHERE `code` = 'cedlazada' AND `key` = 'ced_lazada_".$key."' AND store_id = '0'");
                }
            }
        }
        return $response;
    }

    public function getAppData()
    {
        $profile_regions = $this->config->get('ced_lazada_profile_regions');
        $app_key = $this->config->get('ced_lazada_app_key');
        $app_secret = $this->config->get('ced_lazada_app_secret');
        $code = $this->config->get('ced_lazada_code');
        $access_token = $this->config->get('ced_lazada_access_token');
        $refresh_token = $this->config->get('ced_lazada_refresh_token');
        $access_token_expiry = $this->config->get('ced_lazada_expires_in');
        $refresh_token_expiry = $this->config->get('ced_lazada_refresh_expires_in');

        $UrlConstants = new \Lazada\Sdk\Api\UrlConstants();
        $endPoint = $UrlConstants->getRegionUrl($profile_regions);

        $now = strtotime(date('Y-m-d h:i:s a'));

        if(!empty($access_token) && !empty($access_token_expiry) && ($access_token_expiry < $now)){
            if(!empty($refresh_token_expiry) && ($refresh_token_expiry < $now)){
                $config = new \Lazada\Sdk\Api\Config(
                    array(
                        'appSecret' => $app_secret,
                        'appKey' => $app_key,
                        'endpoint' => $endPoint,
                        'refreshToken' => $refresh_token,
                        'baseDirectory' => $endPoint,
                        'token' => $access_token,
                    )
                );
                $api = new \Lazada\Sdk\Api\Api($config);
                $response = $api->refreshToken();

                if(isset($response['code']) && ($response['code'] == 0))
                {
                    $access_token = $response['access_token'];
                    foreach($response as $key => $value){
                        if($key == 'refresh_token' || $key == 'access_token' || $key == 'refresh_expires_in' || $key == 'expires_in')
                        {
                            $this->db->query("UPDATE " . DB_PREFIX . "setting SET `value` = '" . $this->db->escape($value) . "'  WHERE `code` = 'ced_lazada' AND `key` = 'ced_lazada_".$key."' AND store_id = '0'");
                        }
                    }
                }

            } else {
                $json['success'] = false;
                $json['message'] = 'Lazada refresh token has expired. Kindly re-install the app for continuing using the integration services.';
                $this->response->setOutput(json_encode($json));
            }
        }

        $config = new \Lazada\Sdk\Api\Config(
            array(
                'appSecret' => $app_secret,
                'appKey' => $app_key,
                'endpoint' => $endPoint,
                'baseDirectory' => $endPoint,
                'debugMode' => false,
                'code' => $code,
                'token' => $access_token,
            )
        );

        return $config;
    }

    public function getProfileData($product_id)
    {
        $response = array();
        $sql = $this->db->query("SELECT cp.`id`, cp.`lazada_category_id`, cp.`attributes_mapping` FROM `".DB_PREFIX ."cedlazada_profile_products` AS cpp LEFT JOIN `".DB_PREFIX ."cedlazada_profile` AS cp ON (cp.id = cpp.lazada_profile_id) WHERE cpp.product_id = '". (int)$product_id ."'  ");

        $result = $sql->row;

        if($sql->num_rows)
        {
            $response = array(
                'lazada_category_id' => $result['lazada_category_id'],
                'attributes_mapping' => json_decode($result['attributes_mapping'], true),
                'profile_id' => $result['id']
            );
        }

        return $response;
    }

    public function uploadAllProducts($product_ids = array(), $url = '/product/create')
    {
        $json = array();
        $product_ids = array_filter($product_ids);
        $product_ids = array_unique($product_ids);

        if (!empty($product_ids)) {
            foreach ($product_ids as $product_id)
            {
                if ($product_id > 0)
                {
                    $result = $this->getProfileData($product_id);

                    $lazada_category_id = $result['lazada_category_id'];
                    $attributes_mapping = $result['attributes_mapping'];
                    $profile_id = $result['profile_id'];

                    if(isset($attributes_mapping) && isset($lazada_category_id) && isset($profile_id))
                    {
                        $products = $this->prepareProduct($product_id, $lazada_category_id, $profile_id, $attributes_mapping, $url);

                        $query = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_uploaded_products` WHERE product_id = '". $product_id ."' ");

                        if($query->num_rows){
                            $url = '/product/update';
                        }

                        if($url == '/product/update')
                        {
                            unset($products['Product']['Attributes']['_value']['brand']);
                            unset($products['Product']['Attributes']['_value']['model']);
                            $config = $this->getAppData();
                            $product = new \Lazada\Sdk\Api\Product($config);
                            $response = (array)$product->updateProduct($products);

                            if(isset($response['code']) && ($response['code'] == '0'))
                            {
                                $json['success']=true;
                                $json['message'] = 'Product - '.$product_id.' '.' Updated Successfully';
                            } else {
                                $json['success'] = false;
                                $json['message'] = 'Product - '.$product_id.'-  '.$response['code'].'     '.$response['message'];
                                $json['detail'] = '';
                                if(isset($response['detail']) && is_array($response['detail']))
                                {
                                    foreach($response['detail'] as $key => $value)
                                    {
                                        $error = $value['field'] . ' - ' . $value['message'];
                                        if(!empty($value['seller_sku']))
                                            $json['detail'][$key] = 'Product : '. $product_id . ' - '. $value['seller_sku'] . ' : ' . $error;
                                        else
                                            $json['detail'][$key] = 'Product : '. $product_id . ' ' . $error;
                                    }
                                }
                            }

                        } else {
                            $config = $this->getAppData();
                            $product = new \Lazada\Sdk\Api\Product($config);
                            $response = (array)$product->createProduct($products);

                            if(isset($response['code']) && ($response['code'] == '0') && isset($response['data']['item_id']))
                            {
                                $item_id = $response['data']['item_id'];
                                $query = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_uploaded_products` WHERE product_id = '". $product_id ."' ");
                                if($query->num_rows) {
                                    foreach ($response['data']['sku_list'] as $value){
                                        $this->db->query("UPDATE `" . DB_PREFIX . "cedlazada_uploaded_products` SET `lazada_profile_id` = '". (int) $profile_id ."', `sku_id`= '".$value['seller_sku']."', `lazada_item_id` = '" . (int)$item_id . "', `response_data` = '" . $this->db->escape(json_encode($response['data'])) . "' WHERE product_id = '" . $product_id . "' ");
                                    }
                                } else {
                                    foreach ($response['data']['sku_list'] as $value) {
                                        $this->db->query("INSERT INTO `" . DB_PREFIX . "cedlazada_uploaded_products` SET `product_id` = '" . $product_id . "', `lazada_profile_id` = '". (int) $profile_id ."', `sku_id`= '".$value['seller_sku']."', `lazada_item_id` = '" . (int)$item_id . "', lazada_status = 'Uploaded', `response_data` = '" . $this->db->escape(json_encode($response['data'])) . "'  ");
                                    }
                                }
                                foreach($response['data']['sku_list'] as $resKey => $resVal)
                                {
                                    $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_product_attribute_combination` WHERE product_id = '". (int)$product_id ."' AND sku_id = '". $resVal['seller_sku'] ."' ");
                                    if($sql->num_rows)
                                    {
                                        $this->db->query("UPDATE `". DB_PREFIX ."cedlazada_product_attribute_combination` SET `shop_sku` = '". $this->db->escape($resVal['shop_sku']) ."', `lazada_sku_id` = '". $this->db->escape($resVal['sku_id']) ."' WHERE sku_id = '". $resVal['seller_sku'] ."' ");
                                    }
                                }
                                $json['success'] = true;
                                $json['message'] = 'Product '. $product_id . '- Uploaded Successfully!';
                            } else {
                                $json['success'] = false;
                                if(isset($response['message']) && !empty($response['message']))
                                {
                                    $this->db->query("UPDATE `". DB_PREFIX ."cedlazada_profile_products` SET error_message = '". $this->db->escape(json_encode($response['message'])) ."' WHERE product_id = '". $product_id ."' AND lazada_profile_id = '". $profile_id ."' ");
                                    $json['message'] = 'Product : '. $product_id . ' ' . $response['message'];
                                } else {
                                    $json['message'] = 'Product : '. $product_id . '- Unable to update product';
                                }

                                $json['detail'] = '';
                                if(isset($response['detail']) && is_array($response['detail']))
                                {
                                    foreach($response['detail'] as $key => $value)
                                    {
                                        $error = $value['field'] . ' - ' . $value['message'];
                                        if(!empty($value['seller_sku']))
                                            $json['detail'][$key] = 'Product : '. $product_id . ' - '. $value['seller_sku'] . ' : ' . $error;
                                        else
                                            $json['detail'][$key] = 'Product : '. $product_id . ' ' . $error;
                                    }
                                }
                            }
                        }
                    } else {
                        $json = array('success' => false, 'message' => 'Required details are missing for Prepare Product Data. Please Check your Profile for Lazada Category & Attribute');
                    }
                }
            }
        }
        return $json;
    }

    public function getProduct($product_id) {
        $query = $this->db->query("SELECT DISTINCT *, (SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'product_id=" . (int)$product_id . "') AS keyword FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) WHERE p.product_id = '" . (int)$product_id . "' AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "'");

        return $query->row;
    }

    public function prepareProduct($product_id, $lazada_category_id, $profile_id, $attributes_mapping, $url)
    {
        $products = array();
        $productData = $this->getProduct($product_id);

        $uploadedImageUrl = '';
        // Upload Image(s) & get its Url
        if($product_id && !empty($productData['image']))
        {
            $uploadedImageUrl = $this->uploadImage($product_id, $profile_id, $productData['image']);

            // Uploaded Urls
            if(!empty($uploadedImageUrl)){
                $uploadedImageUrl = json_decode($uploadedImageUrl, true);
            }
        }

        $product_prepared_data = $this->prepareSku($attributes_mapping, $product_id, $profile_id, $lazada_category_id);

        if(isset($product_prepared_data) && is_array($product_prepared_data) && !empty($product_prepared_data))
        {
            if($url == '/product/update')
            {
                if(isset($product_prepared_data['attribute']['model']))
                    unset($product_prepared_data['attribute']['model']);
                if(isset($product_prepared_data['attribute']['brand']))
                    unset($product_prepared_data['attribute']['brand']);

                $product_attribute = $product_prepared_data['attribute'];
            } else {
                $product_attribute = $product_prepared_data['attribute'];
            }

            $product_skus = $product_prepared_data['product_sku'];

            $product_sku = array();
            if(isset($product_skus['0']))
            {
                if(!isset($product_skus['0']['Sku']['Images']))
                {
                    if(isset($uploadedImageUrl) && is_array($uploadedImageUrl) && !empty($uploadedImageUrl))
                    {
                        $product_skus['0']['Sku']['Images'] = array(
                            '_attribute' => array(),
                            '_value' => $uploadedImageUrl,
                        );
                    }
                }

                $product_sku = $product_skus;
            } else {
                if(!isset($product_skus['Sku']['quantity']))
                {
                    $product_skus['Sku']['quantity'] = $productData['quantity'];
                }

                $productSpecialPrice = $this->getSpecialPrice($product_id);

                if(isset($productSpecialPrice['price']) && ($productSpecialPrice['price'] > 0))
                {
                    $product_skus['Sku']['special_price'] = (string)number_format((float)$productSpecialPrice['price'], 2, '.', '');

                    if($productSpecialPrice['date_start'] == '0000-00-00')
                    {
                        $product_skus['Sku']['special_from_date'] = date('Y-m-d');
                    } else {
                        $product_skus['Sku']['special_from_date'] = date('Y-m-d', strtotime($productSpecialPrice['date_start']));
                    }

                    if($productSpecialPrice['date_end'] == '0000-00-00')
                    {
                        $product_skus['Sku']['special_to_date'] = date('Y-m-d', strtotime("1 day"));
                    } else {
                        $product_skus['Sku']['special_to_date'] = date('Y-m-d', strtotime($productSpecialPrice['date_end']));
                    }
                }

                if(isset($uploadedImageUrl))
                {
                    $product_skus['Sku']['Images'] = array(
                        '_attribute' => array(),
                        '_value' => $uploadedImageUrl,
                    );
                }

                $product_sku['0'] = array();
                $product_sku['0'] = $product_skus;
            }

            $products = array(
                'Product' =>array(
                    'PrimaryCategory' => $lazada_category_id,
                    'Attributes' => array(
                        '_attribute' => array(),
                        '_value' => $product_attribute
                    ),
                    'Skus' => array(
                        '_attribute' => array(),
                        '_value' => $product_sku,
                    ),
                )
            );
        }

        return $products;
    }

    public function uploadImage($product_id, $profile_id, $image, $key = 'product')
    {
        $json = array();

        if($key == 'option')
        {
            $sql = $this->db->query("SELECT uploaded_images FROM `". DB_PREFIX ."cedlazada_product_attribute_combination` WHERE product_id = '". (int)$product_id ."' AND lazada_profile_id = '". (int)$profile_id ."'  ");
        } else {
            $sql = $this->db->query("SELECT uploaded_images FROM `". DB_PREFIX ."cedlazada_profile_products` WHERE product_id = '". (int)$product_id ."' AND lazada_profile_id = '". (int)$profile_id ."'  ");
        }

        if(isset($sql->row['uploaded_images']) && !empty($sql->row['uploaded_images']))
        {
            $response = json_decode($sql->row['uploaded_images'], true);

            if(isset($response['data']['image']['url']) && !empty($response['data']['image']['url']))
            {
                $json[0] = $response['data']['image']['url'];
            } else  if(isset($response[0]) && !empty($response[0]) && is_array($response[0])) {
                foreach($response as $key => $value)
                {
                    foreach($value as $key1 => $value1)
                    {
                        $json[$key] = isset($value1['data']['image']['url'])?$value1['data']['image']['url']:'';
                    }
                }
            } else {
                $json = $response;
            }
        } else {
            $productImages = $this->getProductImages($product_id);

            $urls = array();
            if(isset($productImages) && is_array($productImages) && !empty($productImages))
            {
                $urls = array();
                $urls[0]['Url'] = HTTP_CATALOG  . 'image/' . $image;
                foreach($productImages as $key => $value)
                {
                    $urls[++$key]['Url'] = HTTP_CATALOG . 'image/' . $value['image'];
                }
                //$urls = array_merge($urls, $main_image);
            } else {
                $urls[0]['Url'] = HTTP_CATALOG . 'image/'. $image;
            }

            if(isset($urls) && is_array($urls) && !empty($urls))
            {
                $lazada_image_data = array();
                foreach($urls as $key => $image)
                {
                    $image_xml_data = array(
                        'Image' =>array(
                            '_attribute' => array(),
                            '_value' => $image
                        )
                    );
                    $config = $this->getAppData();
                    $product = new \Lazada\Sdk\Api\Product($config);
                    $response = (array)$product->uploadImages($image_xml_data);

                    if(isset($response['data']['image']['url']) && !empty($response['data']['image']['url']))
                    {
                        $lazada_image_data[] = $response['data']['image']['url'];
                    }
                }
                $json = $lazada_image_data;
            }

            if($key == 'option')
            {
                $this->db->query("UPDATE `". DB_PREFIX ."cedlazada_product_attribute_combination` SET `uploaded_images` = '". $this->db->escape(json_encode($lazada_image_data)) ."' WHERE product_id = '". (int)$product_id ."' AND lazada_profile_id = '". (int)$profile_id ."'  ");
            } else {
                $this->db->query("UPDATE `". DB_PREFIX ."cedlazada_profile_products` SET `uploaded_images` = '". $this->db->escape(json_encode($lazada_image_data)) ."' WHERE product_id = '". (int)$product_id ."' AND lazada_profile_id = '". (int)$profile_id ."'  ");
            }
        }

        if(!empty($json))
        {
            $image_array = array();
            foreach($json as $key => $img)
            {
                $image_array[$key]['Image'] = $img;
            }
            return json_encode($image_array);
        } else {
            return array();
        }
    }

    public function getProductImages($product_id) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_image WHERE product_id = '" . (int)$product_id . "'");

        return $query->rows;
    }

    public function getSpecialPrice($product_id) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "' AND price > 0 ORDER BY priority, price LIMIT 1");
        $price = isset($query->row['price']) ? $query->row : '0.0';

        return $price;
    }

    public function prepareSku($attributes_mapping, $product_id, $profile_id, $lazada_category_id)
    {
        $final_array = array();
        $product_sku = array();
        $product_attribute = array();
        $product_skus = array();
        $size_array = array();

        if(isset($attributes_mapping) && is_array($attributes_mapping) && !empty($attributes_mapping))
        {
            foreach($attributes_mapping as $key => $value)
            {
                $data = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedlazada_attribute WHERE attribute_id = '".$value['lazada_attribute']."' ");
                //
                if($data->num_rows > 0)
                {
                    $attribute_name = $data->row['attribute_name'];
                    $attribute_type = $data->row['attribute_type'];

                    if(!empty($value['default_values']))
                    {
                        if($attribute_type == 'sku')
                        {
                            $product_sku['Sku'][$attribute_name] = $value['default_values'];
                        } else {
                            $product_attribute[$attribute_name] = $value['default_values'];
                        }
                    } else if(!empty($value['store_attribute']))
                    {
                        $type = explode('-', $value['store_attribute']);
                        if(!empty($type))
                        {
                            if($type['0'] == 'option')
                            {
                                if(is_array($value['option']))
                                {
                                    $value['option'] = array_filter($value['option']);
                                    $options = array_filter($value['option']);
                                    unset($options['store_attribute']);
                                    unset($options['store_attribute_id']);
                                    unset($options['lazada_attribute']);

                                    $option_value = $this->getProductOptions($product_id, $type['1'], $options);
                                    if(isset($option_value) && is_array($option_value) && !empty($option_value))
                                    {
                                        $size_array[$type['1']] = $option_value;
//                                        $product_sku['Sku'][$attribute_name] = $option_value;
                                    }
                                }
                            }
//                        elseif($type['0'] == 'attribute')
//                        {
//                            $attribute = $this->getAttributeValue($type['1'], $product_id);
//                            $product_sku['Sku'][$attribute_name] = $attribute;
//                        }
                            if($type['0'] == 'product')
                            {
                                if($type['1'] == 'meta_description')
                                    $type['1'] = 'name';

                                $product_value = $this->getProductValue($type['1'], $product_id);

                                if($attribute_type == 'sku')
                                {
                                    $product_sku['Sku'][$attribute_name] = $product_value;
                                } else {
                                    $product_attribute[$attribute_name] = $product_value;
                                }
                            }
                        }
                    }
                }
            }

            $product_variants = $this->isVariantProduct($product_id, $lazada_category_id, $size_array);

            if(isset($product_variants) && is_array($product_variants) && !empty($product_variants))
            {
                foreach($product_variants as $index => $value)
                {
                    $product_sku['Sku']['SellerSku'] =  $value['variation_sku'];
                    if(isset($value['color']))
                    {
                        $product_sku['Sku']['color_family'] = $value['color'];
                    } else {
                        $product_sku['Sku']['color_family'] = $value['name'];
                    }

                    if(isset($value['size']))
                    {
                        $product_sku['Sku']['size'] = $value['size'];
                    }

                    $product_sku['Sku']['price'] = $value['price'];

                    $product_sku['Sku']['package_weight'] = $value['weight'];

                    if(isset($value['quantity']) && ($value['quantity'] > 0))
                    {
                        $product_sku['Sku']['quantity'] = $value['quantity'];
                    } else {
                        $productData = $this->getProduct($product_id);
                        $product_sku['Sku']['quantity'] = $productData['quantity'];
                    }

                    if(isset($value['image']) && !empty($value['image']))
                    {
                        $imageData = $this->uploadImage($product_id, $profile_id, $value['image'], 'option');
                        if(!empty($imageData['data']['Image']))
                           $product_sku['Sku']['Images'] = json_decode($imageData, true);
                    }

                    $product_sku['Sku'] = $this->removeNullValues($product_sku['Sku']);

                    $sql = $this->db->query("SELECT `combination` FROM `". DB_PREFIX ."cedlazada_product_attribute_combination` WHERE sku_id = '". $this->db->escape($product_sku['Sku']['SellerSku']) ."' ");
                    if($sql->num_rows == 0)
                    {
                        $combination[$product_sku['Sku']['SellerSku']] = $value['name'];
                        $this->db->query("INSERT INTO `". DB_PREFIX ."cedlazada_product_attribute_combination` (`product_id`, `lazada_profile_id`, `sku_id`, `combination`) VALUES('". (int)$product_id ."', '". (int)$profile_id ."', '". $this->db->escape($product_sku['Sku']['SellerSku']) ."', '". $this->db->escape(json_encode($combination)) ."') ");
                    }

                    $product_skus[] = $product_sku;
                }
//                if(isset($product_skus) && is_array($product_skus) && !empty($product_skus))
//                {
//                    $productSpecialPrice = $this->getSpecialPrice($product_id);
//                    if(isset($productSpecialPrice['price']) && ($productSpecialPrice['price'] > 0))
//                    {
//                        $product_sku['0']['Sku']['special_price'] = (string)number_format((float)$productSpecialPrice['price'], 2, '.', '');
//                        if($productSpecialPrice['date_start'] == '0000-00-00')
//                        {
//                            $product_sku['Sku']['special_from_date'] = date('Y-m-d');
//                        } else {
//                            $product_sku['Sku']['special_from_date'] = date('Y-m-d', strtotime($productSpecialPrice['date_start']));
//                        }
//
//                        if($productSpecialPrice['date_end'] == '0000-00-00')
//                        {
//                            $product_sku['Sku']['special_to_date'] = date('Y-m-d', strtotime("1 day"));
//                        } else {
//                            $product_sku['Sku']['special_to_date'] = date('Y-m-d', strtotime($productSpecialPrice['date_end']));
//                        }
//                    }
//                }

            } else {
                $product_sku['Sku'] = $this->removeNullValues($product_sku['Sku']);
                $product_skus = $product_sku;
            }
            if(isset($product_attribute) && is_array($product_attribute) && !empty($product_attribute) && isset($product_skus) && is_array($product_skus) && !empty($product_skus))
            {
                $final_array = array('attribute' => $product_attribute, 'product_sku' => $product_skus);
            }
        }

        return $final_array;
    }

    public function removeNullValues($data = array())
    {
        if(isset($data) && is_array($data) && !empty($data))
        {
            foreach($data as $key => $value)
            {
                if( (($key == 'package_height') || ($key == 'package_width') || ($key == 'package_weight') || ($key == 'package_length')) && ($value <= 0))
                {
                    $data[$key] = '1';
                }
                if( (($key == 'package_height') || ($key == 'package_width') || ($key == 'package_weight') || ($key == 'package_length')) && ($value > 0))
                {
                    $data[$key] = (string)number_format((float) $value,2,'.','');
                }

                if($key == 'brand')
                {
                    $data[$key] = ucfirst(strtolower($value));
                }
                if($key == 'tax_class')
                {
                    $data[$key] = 'default';
                }

                if($key == 'price')
                {
                    $data[$key] = (string)number_format((float) $this->getLazadaProductPrice($value),2,'.','');

                }
            }
        }
        return $data;
    }

    public function getProductOptions($product_id, $store_attribute, $attribute_lazada)
    {
        $product_option_data = array();
        $language_id = $this->config->get('config_language_id');

        if($product_id && $store_attribute)
        {
            if (is_numeric($store_attribute) && !empty($store_attribute))
            {
                $product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND  o.option_id = '".(int) $store_attribute."' AND  od.language_id = '" . (int)$language_id . "'");

                if ($product_option_query->num_rows && isset($attribute_lazada))
                {
                    foreach ($attribute_lazada as $option_values)
                    {
                        $product_option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option_value WHERE product_option_id = '" . (int)$product_option_query->row['product_option_id'] . "' AND option_value_id  = '" . (int)$option_values['store_attribute_id'] . "'");
                        if($product_option_value_query->num_rows && isset($option_values['lazada_attribute']) && $option_values['lazada_attribute']) {
                            $product_option_data[$option_values['store_attribute_id']] = $option_values['lazada_attribute'];
//                            break;
                        }
                    }
                }
            }
        }
        return $product_option_data;
    }

    public function getProductPrice($product_id)
    {

        $sql = $this->db->query("SELECT price FROM `" .DB_PREFIX. "product` WHERE product_id = ".$product_id." ");

        return $sql->row['price'];
    }

    public function isVariantProduct($product_id, $lazada_category_id, $size_array)
    {
        $size = false;
        $sql = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedlazada_attribute WHERE category_id = '". $lazada_category_id ."' ");
        if($sql->num_rows)
        {
            foreach($sql->rows as $attribute)
            {
                if($attribute['attribute_name'] == 'size')
                {
                    $size = true;
                }
            }
        }

        $variations = array();
        $product = $this->getProduct($product_id);
        $attirbute_combination = array();

        if($size == false)
        {
            $product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND od.language_id = '" . (int)$this->config->get('config_language_id') . "' AND od.name NOT IN ('Size', 'Radio')  ");
        } else {
            $product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND od.language_id = '" . (int)$this->config->get('config_language_id') . "' ");
        }

        if ($product_option_query && $product_option_query->num_rows)
        {
            foreach ($product_option_query->rows as $option)
            {
                $product_option_value_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `".DB_PREFIX."option_value_description` ovd ON (pov.option_value_id=ovd.option_value_id) WHERE pov.product_id = '" . (int)$product_id . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND pov.option_id = '". (int) $option['option_id'] ."' ");
                if($product_option_value_query && $product_option_value_query->num_rows)
                {
                    foreach ($product_option_value_query->rows as $option_value)
                    {
                        if(isset($option_value['product_option_value_id']) && isset($option_value['product_option_id']) && isset($option_value['option_id']) && isset($option_value['option_value_id']))
                        {
                            $image_sql = $this->db->query("SELECT `image` FROM `". DB_PREFIX ."option_value` WHERE `option_id` = '". $option_value['option_id'] ."' AND `option_value_id` = '". $option_value['option_value_id'] ."' ");
                            if($image_sql->num_rows)
                            {
                                $variant_image = $image_sql->row['image'];
                            }
                            if(isset($size_array) && is_array($size_array) && !empty($size_array))
                            {
                                foreach($size_array as $option_id => $size_option_data)
                                {
                                    if($option_id == $option_value['option_id'])
                                    {
                                        foreach($size_option_data as $option_value_id => $lazada_size_value)
                                        {
                                            if($option_value_id == $option_value['option_value_id'])
                                            {
                                                $option_value['name'] = $lazada_size_value;
                                            }
                                        }
                                    }
                                }
                            }
                            $attirbute_combination[$option_value['product_option_id']][$option_value['product_option_value_id']] = $option_value['product_option_value_id'];
                            $variant_sku = $product_id.'-'.$option_value['product_option_id'].'-'.$option_value['option_id'].'-'.$option_value['product_option_value_id'];
                            $variant_price = $this->calculateValueByPrefix($product['price'], $option_value['price'], $option_value['price_prefix']);
                            $variant_weight = $this->calculateValueByPrefix($product['weight'],  $option_value['weight'], $option_value['weight_prefix']);

                            $attirbute_combination_variant[$option_value['product_option_value_id']] = array(
                                'name' => (string)html_entity_decode($option_value['name']),
                                'stock' => (int)$option_value['quantity'],
                                'price' => (float)$variant_price,
                                'weight' => (float)$variant_weight,
                                'variation_sku' => (string)$variant_sku,
                                'image' => isset($variant_image) ? html_entity_decode($variant_image) : '',
                            );
                        }
                    }
                }
            }

            if(isset($attirbute_combination_variant) && is_array($attirbute_combination_variant) && !empty($attirbute_combination_variant))
            {
                if(count(array_values($attirbute_combination))>1)
                    $attirbute_combination_options = $this->combinations(array_values($attirbute_combination));
                else
                    $attirbute_combination_options = array($attirbute_combination_variant);

                if(!empty($attirbute_combination_options) && (count($attirbute_combination_options)>1))
                {
                    foreach ($attirbute_combination_options as $attirbute_combination_option) {
                        $name = '';
                        $qty = array();
                        $price = array();
                        $sku = '';
                        $weight = array();
                        $image = '';
                        foreach ($attirbute_combination_option as $attirbute_combination_opt)
                        {
                            if(isset($attirbute_combination_variant[$attirbute_combination_opt]) && $attirbute_combination_variant[$attirbute_combination_opt]){

                                $name .= html_entity_decode($attirbute_combination_variant[$attirbute_combination_opt]['name'].' ');
                                $qty[] = $attirbute_combination_variant[$attirbute_combination_opt]['stock'];
                                $price[] = $attirbute_combination_variant[$attirbute_combination_opt]['price'];
                                $weight[] = $attirbute_combination_variant[$attirbute_combination_opt]['weight'];
                                $sku .= $attirbute_combination_variant[$attirbute_combination_opt]['variation_sku'].'_';
                                $image .= html_entity_decode($attirbute_combination_variant[$attirbute_combination_opt]['image'].' ');
                            }
                        }

                        $variations[] = array(
                            'name' => (string)html_entity_decode(trim($name)),
                            'stock' => (int)min($qty),
                            'price' => (float)max($price),
                            'weight' => (float)max($weight),
                            'variation_sku' => (string)rtrim($sku, '_'),
                            'image' => (string)html_entity_decode(trim($image)),
                        );
                    }
                } else {
                    if(isset($attirbute_combination_options[0]))
                    {
                        foreach ($attirbute_combination_options[0] as $attirbute_combination_option)
                        {
                            $variations[] = array(
                                'name' => (string)html_entity_decode(trim($attirbute_combination_option['name'])),
                                'stock' => (int)$attirbute_combination_option['stock'],
                                'price' => (float)$attirbute_combination_option['price'],
                                'weight' => (float)$attirbute_combination_option['weight'],
                                'variation_sku' => (string)$attirbute_combination_option['variation_sku'],
                                'image' => (string)html_entity_decode(trim($attirbute_combination_option['image'])),
                            );
                        }
                    }
                }
                if(isset($variations) && is_array($variations) && !empty($variations))
                {
                    foreach($variations as &$variation)
                    {
                        if(strpos(trim($variation['name']), ' ') !== false)
                        {
                            $name = explode(' ', $variation['name']);
                            $variation['color'] = $name[0];
                            $variation['size'] = $name[1];
                        }

                        if(strpos(trim($variation['image']), ' ') !== false)
                        {
                            $image = explode(' ', $variation['image']);
                            $variation['color_image'] = $image[0];
                            $variation['size_image'] = $image[1];
                        }
                    }
                }
            }
        }

        return $variations;
    }

    public function calculateValueByPrefix($original_value, $value, $prefix) {
        switch ($prefix) {
            case '+' :
                return (float)$original_value + (float)$value;
                break;
            case '-' :
                return (float)$original_value - (float)$value;
                break;
            default :
                return $original_value;
                break;
        }
    }

    public function combinations($arrays, $i = 0) {
        if (!isset($arrays[$i])) {
            return array();
        }
        if ($i == count($arrays) - 1) {
            return $arrays[$i];
        }
        $tmp = $this->combinations($arrays, $i + 1);

        $result = array();
        foreach ($arrays[$i] as $v) {
            foreach ($tmp as $t) {
                $result[] = is_array($t) ?
                    array_merge(array($v), $t) :
                    array($v, $t);
            }
        }
        return $result;
    }

    public function getLazadaProductPrice($price)
    {
        if($price) {
            $lazada_price = 0;
            $price_variation_type = $this->config->get('ced_lazada_price_variation');
            $price_variation_type_fix =(float) $this->config->get('ced_lazada_fix_price');
            // $price_variation_type = (string)number_format($price_variation_type_fix,2);
            $price_variation_type_per =(float) $this->config->get('ced_lazada_per_price');
            // $price_variation_type_per = (string)number_format($price_variation_type_per,2);
            switch ($price_variation_type) {
                case '1':    //default
                    $lazada_price = $price;
                    break;

                case 'special':
                    $lazada_price = $price;
                    break;

                case '2':    // increase_by_fix_price
                    $lazada_price = $price + $price_variation_type_fix;
                    break;

                case '3':  // decrease_by_fix_price
                    $lazada_price = $price - $price_variation_type_fix;
                    break;

                case '4':   // increase_by_fix_percent
                    $lazada_price = $price + ($price * $price_variation_type_per)/100;
                    break;

                case '5':   // decrease_by_fix_percent
                    $lazada_price = $price - ($price * $price_variation_type_per)/100;
                    break;

                default:
                    $lazada_price = $price;
                    break;
            }
            return (string)number_format((float)$lazada_price,2,'.','') ;
        }
        return 0;
    }

    public function getAttributeValue($attribute_id, $product_id){
        $sql = $this->db->query("SELECT `text` FROM `". DB_PREFIX ."product_attribute` WHERE attribute_id = '". $attribute_id ."' AND product_id = '". $product_id ."'");
        if($sql->num_rows)
            return $sql->row['text'];
    }

    public function getProductValue($product_data, $product_id){

        if($product_data == 'stock_status_id'){
            $sql = $this->db->query("SELECT `name` AS `value` FROM `". DB_PREFIX ."product` AS p LEFT JOIN `". DB_PREFIX ."stock_status` AS ss ON(p.stock_status_id = ss.stock_status_id) WHERE p.`product_id` = '". (int)$product_id ."' ");
        } elseif(($product_data == 'manufacturer_id') || ($product_data == 'brand')){
            $sql = $this->db->query("SELECT `name` AS `value` FROM `". DB_PREFIX ."product` AS p LEFT JOIN `". DB_PREFIX ."manufacturer` AS m ON (p.manufacturer_id = m.manufacturer_id) WHERE p.`product_id` = '". (int)$product_id ."' ");
        } elseif($product_data == 'tax_class_id'){
            $sql = $this->db->query("SELECT `title` AS `value` FROM `". DB_PREFIX ."product` AS p LEFT JOIN `". DB_PREFIX ."tax_class` AS tc ON(p.tax_class_id = tc.tax_class_id) WHERE  p.`product_id` = '". (int)$product_id ."' ");
        } elseif($product_data == 'weight_class_id'){
            $sql = $this->db->query("SELECT `value` AS `value` FROM `". DB_PREFIX ."product` AS p LEFT JOIN `". DB_PREFIX ."weight_class` AS wc ON (p.weight_class_id = wc.weight_class_id) WHERE p.`product_id` = '". (int)$product_id ."' ");
        } elseif($product_data == 'length_class_id'){
            $sql = $this->db->query("SELECT `value` AS `value` FROM `". DB_PREFIX ."product` AS p LEFT JOIN `". DB_PREFIX ."length_class` AS lc ON(p.length_class_id = lc.length_class_id) WHERE  `length_class_id` = '". (int)$product_data ."' ");
        } else {
            $sql = $this->db->query("SELECT `".$product_data."` AS `value` FROM `". DB_PREFIX ."product` AS p LEFT JOIN `". DB_PREFIX ."product_description` AS pd ON (p.product_id = pd.product_id) WHERE p.product_id = '". $product_id ."' ");
        }
        if(isset($sql->row['value']))
            return $sql->row['value'];
    }

    public function updatePriceQuantity($product_ids = array())
    {
        $json = array();
        $product_ids = array_filter($product_ids);
        $product_ids = array_unique($product_ids);
        $product_data = array();

        if (!empty($product_ids))
        {
            $success_message = array();
            $error_message = array();
            foreach ($product_ids as $product_id)
            {
                if (is_numeric($product_id))
                {
                    $result = $this->getProfileData($product_id);
                    if(isset($result) && is_array($result) && !empty($result))
                    {
                        $profile_id = $result['profile_id'];

                        $preparedProductData = $this->prepareProductForPriceQuantity($product_id, $profile_id);

                        if(isset($preparedProductData) && is_array($preparedProductData) && !empty($preparedProductData))
                        {
                            $product_data = array(
                                'Product' => array(
                                    'Skus' => array(
                                        '_attribute' => array(),
                                        '_value' => $preparedProductData,
                                    ),
                                )
                            );

                            $config = $this->getAppData();
                            $product = new \Lazada\Sdk\Api\Product($config);
                            $response = (array) $product->updateInventoryPrice($product_data);

                            if(isset($response['code']) && ($response['code'] == 0))
                            {
                                $success_message[] = 'Product ID : '. $product_id . ' inventory/price updated successfully!';
                            } else {
                                if(isset($response['detail']['0']['message']) && !empty($response['detail']['0']['message']))
                                    $error_message[] = 'Product ID : '. $product_id . ' - ' . $response['detail']['0']['message'];
                                else
                                    $error_message[] = 'Product ID : '. $product_id . ' - failed to update inventory/price';
                            }
                        } else {
                            $error_message[] = 'Error while preparing data for Product ID : '. $product_id;
                        }
                    } else {
                        $error_message[] = 'Product ID : '. $product_id . ' selected product is/are not in any profile';
                    }
                }
            }
            if(!empty($success_message))
            {
                $json['success'] = true;
                $json['message'] = implode(',', $success_message);
            } else {
                $json['success'] = true;
                $json['message'] = implode(',', $error_message);
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'Product ID is missing!';
        }
        return $json;
    }

    public function prepareProductForPriceQuantity($product_id, $profile_id)
    {
        $product_sku = array();

        $productData = $this->getProduct($product_id);
        $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_product_attribute_combination` WHERE `product_id` = '". (int)$product_id ."' AND `lazada_profile_id` = '". (int)$profile_id ."' ");

        if($sql->num_rows)
        {
            $result = $sql->rows;
            foreach($result as $key => $value)
            {
                $combination = json_decode($value['combination'], true);
                if(!empty($combination))
                {
                    foreach ($combination as $combiKey => $combiValue)
                    {
                        $combi_exploded = explode('_', $combiKey);
                        $qty = array();
                        $price = array();
                        foreach($combi_exploded as $combi)
                        {
                            $options = explode('-', $combi);
                            $query = $this->db->query("SELECT * FROM `". DB_PREFIX ."product_option_value` WHERE `product_id` = '". (int)$product_id ."' AND `product_option_value_id` = '". (int) $options[3] ."' ");
                            if($query->num_rows)
                            {
                                $variant_price = $this->calculateValueByPrefix($productData['price'], $query->row['price'], $query->row['price_prefix']);

                                $qty[] = $query->row['quantity'];
                                $price[] = $variant_price;
                            }
                        }

                        $product_sku[$key]['Sku']['SellerSku'] = $value['sku_id'];

                        if(!empty($qty))
                            $product_sku[$key]['Sku']['Quantity'] = (int) min($qty);
                        if(!empty($price)){
                            $price = (string)number_format((float) max($price),2,'.','');
                            $product_sku[$key]['Sku']['Price'] = $this->getLazadaProductPrice($price);
                        }
                    }
                }
            }
        } else {
            $product_sku['Sku']['SellerSku'] = !empty($productData['sku']) ? $productData['sku'] : $productData['model'];
            if(!empty($productData['quantity']))
                $product_sku['Sku']['Quantity'] = $productData['quantity'];
            if(!empty($productData['price'])){
                $price = (string)number_format((float)$productData['price'],2,'.','');
                $product_sku['Sku']['Price'] = $this->getLazadaProductPrice($price);
            }

            $productSpecialPrice = $this->getSpecialPrice($product_id);

            if(isset($productSpecialPrice['price']) && !empty($productSpecialPrice['price']))
                $product_sku['Sku']['SalePrice'] = (string) number_format((float)$productSpecialPrice['price'],2,'.','');

            if(isset($productSpecialPrice['date_start']) && !empty($productSpecialPrice['date_start']))
                $product_sku['Sku']['SaleStartDate'] = date('Y-m-d', strtotime($productSpecialPrice['date_start']));

            if(isset($productSpecialPrice['date_end']) && !empty($productSpecialPrice['date_end']))
                $product_sku['Sku']['SaleEndDate'] = date('Y-m-d', strtotime($productSpecialPrice['date_end']));
        }

        return $product_sku;
    }

    public function removeProducts($product_ids)
    {
        $json = array();
        $sku_array = array();
        $success_message = array();
        $error_message = array();
        $product_ids = array_filter($product_ids);
        $product_ids = array_unique($product_ids);

        if (!empty($product_ids))
        {
            foreach ($product_ids as $product_id)
            {
                if (is_numeric($product_id))
                {
                    $result = $this->getProfileData($product_id);
                    $profile_id = $result['profile_id'];

                    $sql = $this->db->query("SELECT `sku_id` FROM `". DB_PREFIX ."cedlazada_product_attribute_combination` WHERE `lazada_profile_id` = '". (int)$profile_id ."' AND `product_id` = '". (int)$product_id ."' ");

                    if($sql->num_rows)
                    {
                        foreach($sql->rows as $key => $value)
                        {
                            if(!empty($value['sku_id']))
                             $sku_array[] = $value['sku_id'];
                        }
                    } else {
                        $productData = $this->getProduct($product_id);
                        if(!empty($productData['sku']))
                            $sku_array[] = $productData['sku'];
                    }
                }
            }
//
            if(isset($sku_array) && is_array($sku_array) && !empty($sku_array))
            {
                $config = $this->getAppData();
                $product = new \Lazada\Sdk\Api\Product($config);

                $response = (array) $product->deleteProduct($sku_array);
//                echo '<pre>'; print_r($response); die;
                if(isset($response['code']) && $response['code'] == 0)
                {
                    foreach($sku_array as $key => $value)
                    {
                        // SET `lazada_status` = 'DELETED'
                        $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_uploaded_products` WHERE `sku_id` = '". $value ."' ");
                        if($sql->num_rows)
                        {
                            $this->db->query("DELETE FROM `". DB_PREFIX ."cedlazada_uploaded_products` WHERE `product_id` = '". $sql->row['product_id'] ."' ");
                            $this->db->query("DELETE FROM `". DB_PREFIX ."cedlazada_product_attribute_combination` WHERE `product_id` = '". $sql->row['product_id'] ."' ");
                            $this->db->query("UPDATE `". DB_PREFIX ."cedlazada_profile_products` SET `error_message` = '', `uploaded_images` = '' WHERE `product_id` = '". $sql->row['product_id'] ."' ");
                        }
                    }
                    $json['success'] = true;
                    $json['message'] = 'Product ID(s) : '. implode(',', $product_ids) . ' removed successfully! ';
                } else {
                    $json['success'] = false;
                    $json['message'] =  '';
                    if(isset($response['message']) && !empty($response['message']))
                    {
                        $json['message'] .= 'Product ID(s) : '. implode(',', $product_ids) . ' - ' . $response['message'];
                        if(isset($response['detail']))
                        {
                            $details_msg = array();
                            foreach($response['detail'] as $detail)
                            {
                                $details_msg[] = $detail['seller_sku'] . ' -- ' . $detail['message'];
                            }
                            $json['message'] .= '  ' . implode(',', $details_msg);
                        }

                    } else
                        $json['message'] = 'Product ID(s) : '. implode(',', $product_ids) . ' - Unable to delete product ';
                }
            } else {
                $json['success'] = false;
                $json['message'] = 'Product ID(s) : '. implode(',', $product_ids) . ' array of SKU(s) is missing';
            }

            return $json;
        }
    }

    public function fetchOrder($response, $config)
    {
        try {
            if (!empty($response) && isset($response['code']) && $response['code'] == '0') {
                if (!isset($response['error'])) {
                    if (is_array($response) && !empty($response)) {
                        $order_ids = array();
                        $response = $response['data'];
                        if (is_array($response) && isset($response['orders']) && count($response['orders'])) {

                            $totalOrderFetched = count($response['orders']);
                            $response['orders'] = array_chunk($response['orders'], '5');

                            foreach ($response['orders'] as $key => $orders) {
                                $order_to_fetch = array();
                                foreach ($orders as $key => $order) {

                                    $already_exist = $this->isLazadaOrderIdExist($order['order_id']);
                                    if ($already_exist) {
                                        continue;
                                    } else {

                                        $order_ids[] = $this->prepareOrderData($order, $config);

                                        $this->log(json_encode($order),'6',true);

                                        $order_ids = array_filter($order_ids);
                                    }
                                }
                                if (count($order_ids) == $totalOrderFetched) {
                                    return array('success' => true, 'message' => $order_ids);
                                } else if (count($order_ids) && ($totalOrderFetched > count($order_ids))) {
                                    return array('success' => true, 'message' => $order_ids, 'sub_message' => 'Please see Rejected List too.');
                                } else if (count($order_ids) == 0) {
                                    return array('success' => true, 'message' => 'No new Order Found.');
                                } else {
                                    return array('success' => false, 'message' => 'Order Send to Rejected List.');
                                }
                            }
                        }
                    } else {
                        return array('success' => false, 'message' => 'No New Order From Lazada.');
                    }
                } else {
                    return array('success' => false, 'message' => $response['msg']);
                }
            } else {
                return array('success' => false, 'message' => 'No new Order found!');
            }
        } catch (Exception $e) {
            $this->log('Order Error:  ' . var_export($response, true));
            return false;
        }
    }

    public function isLazadaOrderIdExist($lazada_order_id = 0)
    {
        $isExist = false;
        if ($lazada_order_id) {
            $sql = "SELECT `id` FROM `" . DB_PREFIX . "cedlazada_order` WHERE `lazada_order_id` = '" . $lazada_order_id . "'";
            $result = $this->db->query($sql);
            if ($result && $result->num_rows) {
                $isExist = true;
            }
        }
        return $isExist;
    }

    public function prepareOrderData( $data = array(), $config) {
        if ($data) {
            $opencart_order_id = 0;
            $lazada_order_id = $data['order_id'];

            if (!$this->isLazadaOrderIdExist($lazada_order_id)) {
                $id = $this->createLazadaOrder($data, $config);
                if($id)
                    return $id;
            }
        }
    }

    public function getFailureReason($config)
    {
        $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_failure_reason` ");
        if($sql->num_rows){
            return $sql->rows;
        } else {
            $order = new \Lazada\Sdk\Api\Order($config);
            $response = $order->getCancelReasons();
            if(isset($response['data']) && $response['code'] == 0){
                foreach($response['data'] as $key => $failureReason){
                    $this->db->query("INSERT INTO `". DB_PREFIX ."cedlazada_failure_reason` (`name`, `type`, `reason_id`) VALUES('". $failureReason['name'] ."', '". $failureReason['type'] ."', '". $failureReason['reason_id'] ."') ");
                }
            }
            return $response['data'];
        }
    }

    public function getShipmentProviders($config)
    {
        $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_shipment_provider` ");
        if($sql->num_rows){
            return $sql->rows;
        } else {
            $order = new \Lazada\Sdk\Api\Order($config);
            $response = $order->getShipmentProviders();
            if(isset($response['data']) && $response['code'] == 0){
                $shipmentProviders = $response['data']['shipment_providers'];
                foreach($shipmentProviders as $key => $shipmentProvider){
                    $this->db->query("INSERT INTO `". DB_PREFIX ."cedlazada_shipment_provider` (`name`, `cod`, `is_default`, `api_integration`) VALUES('". $shipmentProvider['name'] ."', '". $shipmentProvider['cod'] ."', '". $shipmentProvider['is_default'] ."','". $shipmentProvider['api_integration'] ."') ");
                }
            }
            return $response['data'];
        }
    }

    public function getOrderItems($config, $order_id)
    {
        if(isset($order_id) && !empty($order_id))
        {
            $order = new \Lazada\Sdk\Api\Order($config);
            $response = $order->getOrderItems($order_id);

            if(isset($response['data']) && $response['code'] == 0){
                return $response;
            } else {
                return array();
            }
        } else {
            return array('success' => false, 'message' => 'Order ID Missing!');
        }
    }

    public function createLazadaOrder($data, $config)
    {
        $order_data   = array();
        $sku = '';
        $orderItems = $this->getOrderItems($config, $data['order_id']);

        if(isset($orderItems['data']) && !empty($orderItems['data'])){
            $quantity = '0';
            $quantityArray = array();

            foreach ($orderItems['data'] as $key => $orderItem) {
                if($key == 0){
                    $sku = $orderItem['sku'];
                    $quantity++;
                } else if($key == 1){
                    if($sku == $orderItems['data'][$key]['sku']){
                        $quantity++;
                    }
                } else if($key > 1){
                    if($orderItems['data'][$key]['sku'] == $orderItems['data'][$key-1]['sku']){
                        $quantity++;
                    }
                }
                $quantityArray[$sku] = $quantity;
            }
        }

        $customerOrderId      = $data['order_number'];
        $orderId              = $data['order_id'];
        $orderDate            = $data['created_at'];
        $orderStatus          = $data['statuses'];
        $customerLanguageCode = '';
        $settingOrderEmail = $this->config->get('ced_lazada_order_noti_email');
        if(!empty($settingOrderEmail)){
            $email = $settingOrderEmail;
        } else {
            $email = $orderId.'@cedlazadacustomer.com';
        }

        $totalPrice           = $data['price'];
        $quantity             = $data['items_count'];
        $national_registration_number = $data['national_registration_number'];
        $paymentMethod        = $data['payment_method'];
        $shippingCost         = $data['shipping_fee'];
        // (For Thailand only) The tax branch code for corporate customers, provided by the customer when placing the order.
        $branchNumber         = $data['branch_number'];
        // (For Thailand and Vietnam only) The customer's VAT tax code, provided by the customer when placing the order.
        $taxCode              = $data['tax_code'];
        // The voucher that is issued by Lazada
        $voucherPlatform      = $data['voucher_platform'];
        // The voucher that is issued by the seller
        $voucherSeller        = $data['voucher_seller'];
        $voucher              = $data['voucher'];
        $firstName            = $data['customer_first_name'];
        $lastName             = $data['customer_last_name'];

        if(isset($data['address_shipping']) && count($data['address_shipping']))
        {
            $shippingAddress = $data['address_shipping'];

            $shipFirstName    = $shippingAddress['first_name'];
            $shipLastName     = $shippingAddress['last_name'];
            $shipAddressLine1 = $shippingAddress['address1'];
            $shipAddressLine2 = $shippingAddress['address2'] . $shippingAddress['address3'] . $shippingAddress['address4'] . $shippingAddress['address5'];
            $shipCity           = $shippingAddress['city'];
            $shipPostalCode     = $shippingAddress['post_code'];
            $shipCountry        = $shippingAddress['country'];
            $shipPhoneNumber    = $shippingAddress['phone'];
            $settingEnableCustomer = $this->config->get('ced_lazada_enable_customer');
            $settingDefaultCustomer = $this->config->get('ced_lazada_default_customer');
            if($settingEnableCustomer == 1 && !empty($settingDefaultCustomer)){
                $sql = $this->db->query("SELECT `email` FROM `". DB_PREFIX ."customer` WHERE customer_id = '". $this->config->get('ced_lazada_default_customer') ."' ");
                if($sql->num_rows)
                    $shipCustomerEmail  = $sql->row['email'];
            } else {
                $shipCustomerEmail  = $shippingAddress['customer_email'];
            }
        }

        if(isset($data['address_billing']) && count($data['address_billing']))
        {
            $billingAddress = $data['address_billing'];

            $billFirstName    = $billingAddress['first_name'];
            $billLastName     = $billingAddress['last_name'];
            $billAddressLine1 = $billingAddress['address1'];
            $billAddressLine2 = $billingAddress['address2'] . $billingAddress['address3'] . $billingAddress['address4'] . $billingAddress['address5'];
            $billCity           = $billingAddress['city'];
            $billPostalCode     = $billingAddress['post_code'];
            $billCountry        = $billingAddress['country'];
            $billPhoneNumber    = $billingAddress['phone'];
            $settingEnableCustomer = $this->config->get('ced_lazada_enable_customer');
            $settingDefaultCustomer = $this->config->get('ced_lazada_default_customer');
            if($settingEnableCustomer == 1 && !empty($settingDefaultCustomer)){
                $sql = $this->db->query("SELECT `email` FROM `". DB_PREFIX ."customer` WHERE customer_id = '". $this->config->get('ced_lazada_default_customer') ."' ");
                if($sql->num_rows)
                    $billCustomerEmail  = $sql->row['email'];
            } else {
                $billCustomerEmail  = $billingAddress['customer_email'];
            }
        }

        // Order Array
        $order_data['invoice_prefix']     = $this->config->get('config_invoice_prefix');
        $order_data['store_id']           = $this->config->get('config_store_id');
        $order_data['store_name']         = $this->config->get('config_name');
        $order_data['store_url']          = HTTPS_SERVER;
        $order_data['customer_id']        = $customerOrderId;
        $order_data['customer_group_id']  = '1';
        $order_data['firstname']          = $firstName;
        $order_data['lastname']           = $lastName;
        $order_data['email']              = $email;
        $order_data['telephone']          = $billPhoneNumber;
        $order_data['fax']                = '';
        $order_data['order_status']       = $orderStatus;
        $order_data['custom_field']       = array();

        // Payment Detail
        $order_data['payment_firstname']      = $billFirstName;
        $order_data['payment_lastname']       = $billLastName;
        $order_data['payment_company']        = '';
        $order_data['payment_address_1']      = $billAddressLine1;
        $order_data['payment_address_2']      = $billAddressLine2;
        $order_data['payment_city']           = $billCity;
        $order_data['payment_postcode']       = $billPostalCode;
        $order_data['payment_zone']           = '';
        $order_data['payment_zone_id']        = '0';
        $order_data['payment_country']        = $billCountry;
        $order_data['payment_country_id']     = '0';
        $order_data['payment_address_format'] = '';
        $order_data['payment_custom_field']   = array();
        $payment_method_id = '0';
        $order_data['payment_method']         = $paymentMethod;
        $order_data['payment_code']           = 'LazadaPayment';
        $order_data['payment_language']       = '';
        $order_data['payment_language_id']    = '0';
        $order_data['payment_currency']       = '';
        $order_data['payment_currency_id']    = '0';

        // Shipping Detail
        $order_data['shipping_firstname']         = $shipFirstName;
        $order_data['shipping_lastname']          = $shipLastName;
        $order_data['shipping_company']           = '';
        $order_data['shipping_address_1']         = $shipAddressLine1;
        $order_data['shipping_address_2']         = $shipAddressLine2;
        $order_data['shipping_city']              = $shipCity;
        $order_data['shipping_postcode']          = $shipPostalCode;
        $order_data['shipping_zone']              = '';
        $order_data['shipping_zone_id']           = '0';
        $order_data['shipping_country']           = $shipCountry;
        $order_data['shipping_country_id']        = '0';
        $order_data['shipping_address_format']    = '';
        $order_data['shipping_custom_field']      = array( );
        $order_data['shipping_method']            = 'LazadaShipping';
        $order_data['shipping_code']              = 'LazadaShipping.LazadaShipping';

        // for products
        $total_price = isset($totalPrice) ? $totalPrice : 0;
        $total_shipping_cost = isset($shippingCost) ? $shippingCost : 0;
        // $subtotal = isset($data['subtotal']) ? $data['subtotal'] : 0;
        // $discount_amt = isset($data['discount_amt']) ? $data['discount_amt'] : 0;

        // $order_items  = $data['o:orderLines']['o:orderLine'];

        $grand_total = '0';
        if(isset($orderItems['data']) && !empty($orderItems['data'])){
            if(!isset($orderItems['data']['0']))
            {
                $temp_results = $orderItems['data'];
                $orderItems['data'] = array();
                $orderItems['data']['0'] = $temp_results;
            }

            foreach ($orderItems['data'] as $key => $orderItem) {
                foreach($quantityArray as $qtySku => $quantity){

                    if($qtySku == $orderItem['sku']){
                        $ordered_products = $this->getOpencartProductBySku($orderItem['sku'], $quantity, $data, $orderItem, $orderId, $orderItem['order_id'], $orderItem['name'], $orderItem['item_price'], $orderItem['tax_amount']);
                        $grand_total += $orderItem['item_price'];
                        $grandtotal = isset($grand_total) ? $grand_total : 0;
                        if($ordered_products)
                            $order_data['products'][] = $ordered_products;
                    }

                }
            }
        }
//echo "<pre>";print_r($order_data);die('ok');
        if(isset($order_data['products']) && count($order_data['products'])>0)
        {
            $order_data['vouchers']=array();

            $order_data['totals'][]= array(
                'code' => 'sub_total',
                'title' => 'Sub-Total',
                'value'=> $total_price,
                'sort_order' => 1
            );

            $order_data['totals'][]= array(
                'code' => 'shipping',
                'title' => 'Lazada Shipping',
                'value'=>(float) $total_shipping_cost,
                'sort_order' => 3
            );

            $order_data['totals'][]= array(
                'code' => 'total',
                'title' => 'Total',
                'value'=> (float) $grandtotal,
                'sort_order' => 9
            );

            $order_data['comment']='';
            $order_data['total']= (float) $grandtotal;
            $order_data['affiliate_id']='0';
            $order_data['commission']='0';
            $order_data['marketing_id']='0';
            $order_data['tracking']='';
            $order_data['language_id'] = $this->config->get('config_language_id');

            if (isset($this->session->data['currency']) && $this->session->data['currency']) {
                $order_data['currency_id'] = $this->currency->getId($this->session->data['currency']);
                $order_data['currency_code'] = $this->session->data['currency'];
                $order_data['currency_value'] = $this->currency->getValue($this->session->data['currency']);
            } else {
                $order_data['currency_id'] = '';
                $order_data['currency_code'] = '';
                $order_data['currency_value'] = '1';
            }

            $order_data['ip'] = '';
            $order_data['forwarded_ip'] = '';
            $order_data['user_agent'] = '';
            $order_data['accept_language'] = '';

            $query = $this->db->query("SELECT id FROM " . DB_PREFIX . "cedlazada_order WHERE lazada_order_id='".$orderId."' ");
            if($query->num_rows){
                $this->updateOrderStatus($orderId, $orderStatus);
                $respo = $this->updatelazadaOrderData($orderId, $orderStatus, $data, $orderItems['data']);
            } else {
                $opencart_order_id = $this->addLazadaOrder($order_data);
                $respo = $this->db->query("INSERT INTO " . DB_PREFIX . "cedlazada_order SET opencart_order_id =  '" . (int)$opencart_order_id . "', lazada_order_id='".$orderId."', status = '". $orderStatus ."', order_data='".$this->db->escape(json_encode($data))."', `order_place_date` = '" . $this->db->escape($orderDate) . "', `order_item_data` = '". $this->db->escape(json_encode($orderItems)) ."' , `shipment_data` = '" . $this->db->escape(json_encode($data['address_shipping'])) . "' ");
            }
            if($respo){
                $order_ids[] = $opencart_order_id;
            }
        }else{
            $this->session->data['success'] = "Lazada Order Can not Imported see Rejected List";
            // continue;
        }

        if (!empty($opencart_order_id)) {
            return $opencart_order_id;
        }
        return false;

    }

    public function updatelazadaOrderData($lazadaOrderId, $status, $data, $orderItems)
    {
        $this->db->query(" UPDATE `" . DB_PREFIX . "cedlazada_order` SET `status` = '". $this->db->escape($status) ."' , `order_data` = '". $this->db->escape(json_encode($data)) ."', `order_item_data` = '". $this->db->escape(json_encode($orderItems)) ."' WHERE `lazada_order_id` = '".$lazadaOrderId."'");
    }

    public function getOpencartProductBySku($sku, $quantity, $order_data, $item_order_data, $lazada_order_id, $lazada_item_order_id, $product_title, $lazada_price, $totalVat)
    {
        $product=array();
        
        $sql = "SELECT `product_id`,`combination` FROM `" . DB_PREFIX . "cedlazada_product_attribute_combination` WHERE `sku_id`='".$sku."'";
        $query = $this->db->query($sql);
        $result = $query->row;

        if($query->num_rows)
        {
            $combination=isset($result['combination'])?$result['combination']:'{}';
            $product_id=isset($result['product_id'])?$result['product_id']:'';
            $sql = "SELECT `status`,`minimum`,`quantity`,`model`,`price`FROM `".DB_PREFIX ."product` WHERE product_id = '".$product_id."'";
            $query = $this->db->query($sql);
            if($query->num_rows)
            {
                $status     =$query->row['status'];
                $minimum    =$query->row['minimum'];
                $qty_avail  =$query->row['quantity'];
                $model      =$query->row['model'];
                $price      =$query->row['price'];

                if($status)
                {
                    if(($qty_avail >= $quantity))
                    {
                        $product['quantity']  = $quantity;
                        $product['product_id']= $product_id;
                        $product['model']     = $model;
                        $product['subtract']  = $quantity;
                        $product['price']     = ($lazada_price) ? $lazada_price : $price;
                        $product['total']     = ($lazada_price) ? $quantity * $lazada_price : $quantity * $price;
                        $product['tax']       = ($totalVat) ? $totalVat : '0';
                        $product['reward']    = 0;
                        $product['name']      = $product_title;
                        $combination    = json_decode($combination,true);

                        foreach($combination as $key => &$value){
                            $combi_query = $this->db->query("SELECT ovd.`name` FROM `". DB_PREFIX ."product_option_value` AS pov LEFT JOIN `". DB_PREFIX ."option_value_description` AS ovd ON (ovd.option_value_id = pov.option_value_id) WHERE pov.product_id = '". $product_id ."' AND pov.option_value_id = '". $key ."'  ");
                            $combination[$key] = $combi_query->row['name'];
                        }
                        $product['option']    = $combination;
                        $product['download']  = array();
                        return $product;
                    } else {
                        $this->addOrderErrorInfo($lazada_order_id, $lazada_item_order_id, $order_data, $item_order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                        return '0';
                    }
                } else {
                    $this->addOrderErrorInfo($lazada_order_id, $lazada_item_order_id, $order_data, $item_order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                    return '0';
                }
            } else {
                $this->addOrderErrorInfo($lazada_order_id, $lazada_item_order_id, $order_data, $item_order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                return '0';
            }
        } else {
            $sql = "SELECT `product_id`, `status`, `minimum`, `quantity`, `model`, `price` FROM `" . DB_PREFIX . "product` WHERE `sku` = '".$sku."'";
            $product_data = $this->db->query($sql);
            if(empty($product_data)){
                $sql = "SELECT `product_id`, `status`, `minimum`, `quantity`, `model`, `price` FROM `" . DB_PREFIX . "product` WHERE `model` = '". $sku ."'";
                $product_data = $this->db->query($sql);
            }

            $product_id= 0 ;

            if($product_data && $product_data->num_rows && isset($product_data->row['product_id'])){
                $product_id = $product_data->row['product_id'];
                $status     = $product_data->row['status'];
                $minimum    = $product_data->row['minimum'];
                $qty_avail  = $product_data->row['quantity'];
                $model      = $product_data->row['model'];
                $price      = $product_data->row['price'];
                if($status)
                {
                    if(($qty_avail >= $quantity))
                    {
                        $product['quantity']  = $quantity;
                        $product['product_id']= $product_id;
                        $product['model']     = $model;
                        $product['subtract']  = $quantity;
                        $product['price']     = ($lazada_price) ? $lazada_price : $price;
                        $product['total']     = ($lazada_price) ? $quantity * $lazada_price : $quantity * $price;
                        $product['tax']       = ($totalVat) ? $totalVat : '0';
                        $product['reward']    = 0;
                        $product['name']      = $product_title;
                        $product['option']    = array();
                        $product['download']  = array();
                        return $product;
                    } else {
                        $this->addOrderErrorInfo($lazada_order_id, $lazada_item_order_id, $order_data, $item_order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                        return '0';
                    }
                } else {
                    $this->addOrderErrorInfo($lazada_order_id, $lazada_item_order_id, $order_data, $item_order_data,"PRODUCT STATUS IS DISABLED WITH ID ".$product_id, $sku);
                    return '0';
                }
            }else{
                $this->addOrderErrorInfo($lazada_order_id, $lazada_item_order_id, $order_data, $item_order_data,"MERCHANT SKU DOES NOT EXIST", $sku);
                return '0';
            }
        }
    }

    public function addOrderErrorInfo($lazada_order_id, $lazada_item_order_id, $order_data, $item_order_data, $error_message, $sku)
    {
        $already_exists = " SELECT * FROM `" . DB_PREFIX . "cedlazada_order_error` WHERE `merchant_sku` = '" . $sku . "' AND lazada_order_id = '" . $lazada_order_id . "' AND lazada_item_order_id = '". $lazada_item_order_id ."'  ";
        $already_exists=$this->db->query($already_exists);
        if(!$already_exists->num_rows)
        {
            $sql = " INSERT INTO `" . DB_PREFIX . "cedlazada_order_error` (`merchant_sku`, `lazada_order_id`, `lazada_item_order_id`, `order_data`, `item_order_data`, `reason`)VALUES('" . $sku . "', '" . $lazada_order_id . "', '". $lazada_item_order_id ."', '" . $this->db->escape(json_encode($order_data)) . "', '". $this->db->escape(json_encode($item_order_data)) ."', '" . $error_message . "')";
            $result=$this->db->query($sql);
            if($result){
                return $lazada_order_id;
            }
        }
    }

    public function updateOrderStatus($lazadaOrderId,$status = '')
    {
        $result = $this->db->query("SELECT `opencart_order_id` FROM `" . DB_PREFIX . "cedlazada_order` WHERE `lazada_order_id` = '" . (int)$lazadaOrderId . "'");

        if($result->num_rows){
            $order_id= $result->row['opencart_order_id'];
            $order_status_id = $this->getOrderStatusIdByName($status);
            $this->db->query("UPDATE `" . DB_PREFIX . "order` SET order_status_id = '". $order_status_id ."' WHERE order_id = '".$order_id."' ");
            $this->db->query("UPDATE `" . DB_PREFIX . "order_history` SET order_status_id = '". $order_status_id ."' WHERE order_id = '".$order_id."' ");
        }
    }

    public function getOrderStatusIdByName($name)
    {
        $sql ="SELECT `order_status_id` FROM `".DB_PREFIX."order_status` WHERE `name`='".$name."'";
        $query=$this->db->query($sql);
        if($query && $query->num_rows)
            return $query->row['order_status_id'];
    }

    public function addLazadaOrder($data)
    {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "order` SET invoice_prefix = '" . $this->db->escape($data['invoice_prefix']) . "', store_id = '" . (int)$data['store_id'] . "', store_name = '" . $this->db->escape($data['store_name']) . "', store_url = '" . $this->db->escape($data['store_url']) . "', customer_id = '" . (int)$data['customer_id'] . "', customer_group_id = '" . (int)$data['customer_group_id'] . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', telephone = '" . $this->db->escape($data['telephone']) . "', fax = '" . $this->db->escape($data['fax']) . "', payment_firstname = '" . $this->db->escape($data['payment_firstname']) . "', payment_lastname = '" . $this->db->escape($data['payment_lastname']) . "', payment_company = '" . $this->db->escape($data['payment_company']) . "', payment_address_1 = '" . $this->db->escape($data['payment_address_1']) . "', payment_address_2 = '" . $this->db->escape($data['payment_address_2']) . "', payment_city = '" . $this->db->escape($data['payment_city']) . "', payment_postcode = '" . $this->db->escape($data['payment_postcode']) . "', payment_country = '" . $this->db->escape($data['payment_country']) . "', payment_country_id = '" . (int)$data['payment_country_id'] . "', payment_zone = '" . $this->db->escape($data['payment_zone']) . "', payment_zone_id = '" . (int)$data['payment_zone_id'] . "', payment_address_format = '" . $this->db->escape($data['payment_address_format']) . "', payment_method = '" . $this->db->escape($data['payment_method']) . "', payment_code = '" . $this->db->escape($data['payment_code']) . "', shipping_firstname = '" . $this->db->escape($data['shipping_firstname']) . "', shipping_lastname = '" . $this->db->escape($data['shipping_lastname']) . "', shipping_company = '" . $this->db->escape($data['shipping_company']) . "', shipping_address_1 = '" . $this->db->escape($data['shipping_address_1']) . "', shipping_address_2 = '" . $this->db->escape($data['shipping_address_2']) . "', shipping_city = '" . $this->db->escape($data['shipping_city']) . "', shipping_postcode = '" . $this->db->escape($data['shipping_postcode']) . "', shipping_country = '" . $this->db->escape($data['shipping_country']) . "', shipping_country_id = '" . (int)$data['shipping_country_id'] . "', shipping_zone = '" . $this->db->escape($data['shipping_zone']) . "', shipping_zone_id = '" . (int)$data['shipping_zone_id'] . "', shipping_address_format = '" . $this->db->escape($data['shipping_address_format']) . "', shipping_method = '" . $this->db->escape($data['shipping_method']) . "', shipping_code = '" . $this->db->escape($data['shipping_code']) . "', comment = '" . $this->db->escape($data['comment']) . "', total = '" . (float)$data['total'] . "', affiliate_id = '" . (int)$data['affiliate_id'] . "', commission = '" . (float)$data['commission'] . "', language_id = '" . (int)$data['language_id'] . "', currency_id = '" . (int)$data['currency_id'] . "', currency_code = '" . $this->db->escape($data['currency_code']) . "', currency_value = '" . (float)$data['currency_value'] . "', ip = '" . $this->db->escape($data['ip']) . "', forwarded_ip = '" .  $this->db->escape($data['forwarded_ip']) . "', user_agent = '" . $this->db->escape($data['user_agent']) . "', accept_language = '" . $this->db->escape($data['accept_language']) . "', date_added = NOW(), date_modified = NOW() , order_status_id='".$this->getOrderStatusIdByName($data['order_status'])."'");

        $order_id = $this->db->getLastId();
        // Products
        foreach ($data['products'] as $product) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_product SET order_id = '" . (int)$order_id . "', product_id = '" . (int)$product['product_id'] . "', name = '" . $this->db->escape($product['name']) . "', model = '" . $this->db->escape($product['model']) . "', quantity = '" . (int)$product['quantity'] . "', price = '" . (float)$product['price'] . "', total = '" . (float)$product['total'] . "', tax = '" . (float)$product['tax'] . "', reward = '" . (int)$product['reward'] . "'");

            $order_product_id = $this->db->getLastId();

            if(isset($product['option']) && count($product['option'])>0){
                foreach ($product['option'] as $option_id => $option_value) {
                    $sql="SELECT pov.product_option_value_id,po.product_option_id,od.name, ovd.name as `value`,o.type FROM ".DB_PREFIX."product_option_value pov LEFT JOIN ".DB_PREFIX."product_option po ON (po.product_id=pov.product_id AND po.option_id=pov.option_id) LEFT JOIN ".DB_PREFIX."option o ON (pov.option_id =o.option_id) LEFT JOIN ".DB_PREFIX."option_description od ON (pov.option_id =od.option_id) JOIN ".DB_PREFIX."option_value_description ovd ON (pov.option_id =ovd.option_id AND pov.option_value_id=ovd.option_value_id) where pov.option_value_id =". (int)$option_value." and pov.product_id=".(int)$product['product_id'];
                    $options_data=$this->db->query($sql);
                    if($options_data->num_rows){
                        $option=$options_data->row;
                        $this->db->query("INSERT INTO " . DB_PREFIX . "order_option SET order_id = '" . (int)$order_id . "', order_product_id = '" . (int)$order_product_id . "', product_option_id = '" . (int)$option['product_option_id'] . "', product_option_value_id = '" . (int)$option['product_option_value_id'] . "', name = '" . $this->db->escape($option['name']) . "', `value` = '" . $this->db->escape($option['value']) . "', `type` = '" . $this->db->escape($option['type']) . "'");
                    }
                }
            }
        }

        // Totals
        foreach ($data['totals'] as $total) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = '" . $this->db->escape($total['code']) . "', title = '" . $this->db->escape($total['title']) . "', `value` = '" . (float)$total['value'] . "', sort_order = '" . (int)$total['sort_order'] . "'");
        }

        $this->addOrderHistory($order_id, $this->getOrderStatusIdByName($data['order_status']));

        return $order_id;
    }

    public function addOrderHistory($order_id, $order_status_id, $comment ='',$notify = true)
    {
        $this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$order_status_id . "', notify = '" . (int)$notify . "', comment = '" . $this->db->escape($comment) . "', date_added = NOW()");
        $data=array();
        $data['order_status_id']=(int)$order_status_id;
        $data['order_id']=(int)$order_id;
        $data['comment']='A fruugo Order Imported Successfully';
        $data['notify']=(int)$notify;

        $order_info = $this->getOrder($order_id);


        if ($order_info) {
            // Restock
            $product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach($product_query->rows as $product) {
                $this->db->query("UPDATE `" . DB_PREFIX . "product` SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_id = '" . (int)$product['product_id'] . "' AND subtract = '1'");

                $option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                foreach ($option_query->rows as $option) {
                    $this->db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
                }
            }

            // If order status is 0 then becomes greater than 0 send main html email
            if ($order_status_id) {
                // Load the language for any mails that might be required to be sent out
                $language = new Language($order_info['language_code']);
                $language->load($order_info['language_code']);
                $language->load('mail/order');

                $order_status_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE order_status_id = '" . (int)$order_status_id . "' AND language_id = '" . (int)$order_info['language_id'] . "'");

                if ($order_status_query->num_rows) {
                    $order_status = $order_status_query->row['name'];
                } else {
                    $order_status = '';
                }

                $subject = sprintf($language->get('text_new_subject'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'), $order_id);

                // HTML Mail
                $data = array();

                $data['title'] = sprintf($language->get('text_new_subject'), $order_info['store_name'], $order_id);

                $data['text_greeting'] = sprintf($language->get('text_new_greeting'), $order_info['store_name']);
                $data['text_link'] = $language->get('text_new_link');
                $data['text_download'] = $language->get('text_new_download');
                $data['text_order_detail'] = $language->get('text_new_order_detail');
                $data['text_instruction'] = $language->get('text_new_instruction');
                $data['text_order_id'] = $language->get('text_new_order_id');
                $data['text_date_added'] = $language->get('text_new_date_added');
                $data['text_payment_method'] = $language->get('text_new_payment_method');
                $data['text_shipping_method'] = $language->get('text_new_shipping_method');
                $data['text_email'] = $language->get('text_new_email');
                $data['text_telephone'] = $language->get('text_new_telephone');
                $data['text_ip'] = $language->get('text_new_ip');
                $data['text_order_status'] = $language->get('text_new_order_status');
                $data['text_payment_address'] = $language->get('text_new_payment_address');
                $data['text_shipping_address'] = $language->get('text_new_shipping_address');
                $data['text_product'] = $language->get('text_new_product');
                $data['text_model'] = $language->get('text_new_model');
                $data['text_quantity'] = $language->get('text_new_quantity');
                $data['text_price'] = $language->get('text_new_price');
                $data['text_total'] = $language->get('text_new_total');
                $data['text_footer'] = $language->get('text_new_footer');

                $data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');
                $data['store_name'] = $order_info['store_name'];
                $data['store_url'] = $order_info['store_url'];
                $data['customer_id'] = $order_info['customer_id'];
                $data['link'] = $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id;

                $data['order_id'] = $order_id;
                $data['date_added'] = date($language->get('date_format_short'), strtotime($order_info['date_added']));
                $data['payment_method'] = $order_info['payment_method'];
                $data['shipping_method'] = $order_info['shipping_method'];
                $data['email'] = $order_info['email'];
                $data['telephone'] = $order_info['telephone'];
                $data['ip'] = $order_info['ip'];
                $data['order_status'] = $order_status;

                if ($comment && $notify) {
                    $data['comment'] = nl2br($comment);
                } else {
                    $data['comment'] = '';
                }

                if ($order_info['payment_address_format']) {
                    $format = $order_info['payment_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['payment_firstname'],
                    'lastname'  => $order_info['payment_lastname'],
                    'company'   => $order_info['payment_company'],
                    'address_1' => $order_info['payment_address_1'],
                    'address_2' => $order_info['payment_address_2'],
                    'city'      => $order_info['payment_city'],
                    'postcode'  => $order_info['payment_postcode'],
                    'zone'      => $order_info['payment_zone'],
                    'zone_code' => $order_info['payment_zone_code'],
                    'country'   => $order_info['payment_country']
                );

                $data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

                if ($order_info['shipping_address_format']) {
                    $format = $order_info['shipping_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['shipping_firstname'],
                    'lastname'  => $order_info['shipping_lastname'],
                    'company'   => $order_info['shipping_company'],
                    'address_1' => $order_info['shipping_address_1'],
                    'address_2' => $order_info['shipping_address_2'],
                    'city'      => $order_info['shipping_city'],
                    'postcode'  => $order_info['shipping_postcode'],
                    'zone'      => $order_info['shipping_zone'],
                    'zone_code' => $order_info['shipping_zone_code'],
                    'country'   => $order_info['shipping_country']
                );

                $data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));


                // Products
                $data['products'] = array();
                $data['vouchers'] = array();

                foreach ($product_query->rows as $product) {
                    $option_data = array();

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $option_data[] = array(
                            'name'  => $option['name'],
                            'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
                        );
                    }

                    $data['products'][] = array(
                        'name'     => $product['name'],
                        'model'    => $product['model'],
                        'option'   => $option_data,
                        'quantity' => $product['quantity'],
                        'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
                        'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value'])
                    );
                }



                // Order Totals
                $data['totals'] = array();

                $order_total_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_total` WHERE order_id = '" . (int)$order_id . "' ORDER BY sort_order ASC");

                foreach ($order_total_query->rows as $total) {
                    $data['totals'][] = array(
                        'title' => $total['title'],
                        'text'  => $this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']),
                    );
                }

                // Text Mail
                $text  = sprintf($language->get('text_new_greeting'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8')) . "\n\n";
                $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";

                if ($comment && $notify) {
                    $text .= $language->get('text_new_instruction') . "\n\n";
                    $text .= $comment . "\n\n";
                }

                // Products
                $text .= $language->get('text_new_products') . "\n";

                foreach ($product_query->rows as $product) {
                    $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                    }
                }


                $text .= "\n";

                $text .= $language->get('text_new_order_total') . "\n";

                foreach ($order_total_query->rows as $total) {
                    $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                }

                $text .= "\n";

                if ($order_info['customer_id']) {
                    $text .= $language->get('text_new_link') . "\n";
                    $text .= $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id . "\n\n";
                }

                // Comment
                if ($order_info['comment']) {
                    $text .= $language->get('text_new_comment') . "\n\n";
                    $text .= $order_info['comment'] . "\n\n";
                }
                $text .= $language->get('text_new_footer') . "\n\n";

                $mail = new Mail();
                $mail->protocol = $this->config->get('config_mail_protocol');
                $mail->parameter = $this->config->get('config_mail_parameter');
                $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                $mail->setTo($order_info['email']);
                $mail->setFrom($this->config->get('config_email'));
                $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                $mail->setText($text);
                $mail->send();

                // Admin Alert Mail
                if ($this->config->get('config_order_mail')) {
                    $subject = sprintf($language->get('text_new_subject'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'), $order_id);

                    // HTML Mail
                    $data['text_greeting'] = $language->get('text_new_received');

                    if ($comment) {
                        if ($order_info['comment']) {
                            $data['comment'] = nl2br($comment) . '<br/><br/>' . $order_info['comment'];
                        } else {
                            $data['comment'] = nl2br($comment);
                        }
                    } else {
                        if ($order_info['comment']) {
                            $data['comment'] = $order_info['comment'];
                        } else {
                            $data['comment'] = '';
                        }
                    }

                    $data['text_download'] = '';

                    $data['text_footer'] = '';

                    $data['text_link'] = '';
                    $data['link'] = '';
                    $data['download'] = '';

                    // Text
                    $text  = $language->get('text_new_received') . "\n\n";
                    $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                    $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                    $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";
                    $text .= $language->get('text_new_products') . "\n";

                    foreach ($product_query->rows as $product) {
                        $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                        $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                        foreach ($order_option_query->rows as $option) {
                            if ($option['type'] != 'file') {
                                $value = $option['value'];
                            } else {
                                $value = utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.'));
                            }

                            $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                        }
                    }

                    foreach ($order_voucher_query->rows as $voucher) {
                        $text .= '1x ' . $voucher['description'] . ' ' . $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']);
                    }

                    $text .= "\n";

                    $text .= $language->get('text_new_order_total') . "\n";

                    foreach ($order_total_query->rows as $total) {
                        $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                    }

                    $text .= "\n";

                    if ($order_info['comment']) {
                        $text .= $language->get('text_new_comment') . "\n\n";
                        $text .= $order_info['comment'] . "\n\n";
                    }

                    $mail = new Mail();
                    $mail->protocol = $this->config->get('config_mail_protocol');
                    $mail->parameter = $this->config->get('config_mail_parameter');
                    $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                    $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                    $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                    $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                    $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                    $mail->setTo($this->config->get('config_email'));
                    $mail->setFrom($this->config->get('config_email'));
                    $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                    $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                    //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                    $mail->setText($text);
                    $mail->send();

                    // Send to additional alert emails
                    $emails = explode(',', $this->config->get('config_mail_alert'));
                    foreach ($emails as $email) {
                        if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            $mail->setTo($email);
                            $mail->send();
                        }
                    }
                }
            }
        }
    }

    public function getOrder($order_id)
    {
        $order_query = $this->db->query("SELECT *, (SELECT CONCAT(c.firstname, ' ', c.lastname) FROM " . DB_PREFIX . "customer c WHERE c.customer_id = o.customer_id) AS customer FROM `" . DB_PREFIX . "order` o WHERE o.order_id = '" . (int)$order_id . "'");

        if ($order_query->num_rows) {
            $reward = 0;

            $order_product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach ($order_product_query->rows as $product) {
                $reward += $product['reward'];
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['payment_country_id'] . "'");

            if ($country_query->num_rows) {
                $payment_iso_code_2 = $country_query->row['iso_code_2'];
                $payment_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $payment_iso_code_2 = '';
                $payment_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['payment_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $payment_zone_code = $zone_query->row['code'];
            } else {
                $payment_zone_code = '';
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['shipping_country_id'] . "'");

            if ($country_query->num_rows) {
                $shipping_iso_code_2 = $country_query->row['iso_code_2'];
                $shipping_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $shipping_iso_code_2 = '';
                $shipping_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['shipping_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $shipping_zone_code = $zone_query->row['code'];
            } else {
                $shipping_zone_code = '';
            }

            if ($order_query->row['affiliate_id']) {
                $affiliate_id = $order_query->row['affiliate_id'];
            } else {
                $affiliate_id = 0;
            }

            $affiliate_firstname = '';
            $affiliate_lastname = '';

            $sql = $this->db->query("SELECT filename FROM `". DB_PREFIX ."language` WHERE code = '".$this->config->get('config_language')."' ");

            $language_code = $sql->row['filename'];
            $language_filename = '';
            $language_directory = '';

            return array(
                'order_id'                => $order_query->row['order_id'],
                'invoice_no'              => $order_query->row['invoice_no'],
                'invoice_prefix'          => $order_query->row['invoice_prefix'],
                'store_id'                => $order_query->row['store_id'],
                'store_name'              => $order_query->row['store_name'],
                'store_url'               => $order_query->row['store_url'],
                'customer_id'             => $order_query->row['customer_id'],
                'customer'                => $order_query->row['customer'],
                'customer_group_id'       => $order_query->row['customer_group_id'],
                'firstname'               => $order_query->row['firstname'],
                'lastname'                => $order_query->row['lastname'],
                'email'                   => $order_query->row['email'],
                'telephone'               => $order_query->row['telephone'],
                'fax'                     => $order_query->row['fax'],
                'payment_firstname'       => $order_query->row['payment_firstname'],
                'payment_lastname'        => $order_query->row['payment_lastname'],
                'payment_company'         => $order_query->row['payment_company'],
                'payment_address_1'       => $order_query->row['payment_address_1'],
                'payment_address_2'       => $order_query->row['payment_address_2'],
                'payment_postcode'        => $order_query->row['payment_postcode'],
                'payment_city'            => $order_query->row['payment_city'],
                'payment_zone_id'         => $order_query->row['payment_zone_id'],
                'payment_zone'            => $order_query->row['payment_zone'],
                'payment_zone_code'       => $payment_zone_code,
                'payment_country_id'      => $order_query->row['payment_country_id'],
                'payment_country'         => $order_query->row['payment_country'],
                'payment_iso_code_2'      => $payment_iso_code_2,
                'payment_iso_code_3'      => $payment_iso_code_3,
                'payment_address_format'  => $order_query->row['payment_address_format'],
                'payment_method'          => $order_query->row['payment_method'],
                'payment_code'            => $order_query->row['payment_code'],
                'shipping_firstname'      => $order_query->row['shipping_firstname'],
                'shipping_lastname'       => $order_query->row['shipping_lastname'],
                'shipping_company'        => $order_query->row['shipping_company'],
                'shipping_address_1'      => $order_query->row['shipping_address_1'],
                'shipping_address_2'      => $order_query->row['shipping_address_2'],
                'shipping_postcode'       => $order_query->row['shipping_postcode'],
                'shipping_city'           => $order_query->row['shipping_city'],
                'shipping_zone_id'        => $order_query->row['shipping_zone_id'],
                'shipping_zone'           => $order_query->row['shipping_zone'],
                'shipping_zone_code'      => $shipping_zone_code,
                'shipping_country_id'     => $order_query->row['shipping_country_id'],
                'shipping_country'        => $order_query->row['shipping_country'],
                'shipping_iso_code_2'     => $shipping_iso_code_2,
                'shipping_iso_code_3'     => $shipping_iso_code_3,
                'shipping_address_format' => $order_query->row['shipping_address_format'],
                'shipping_method'         => $order_query->row['shipping_method'],
                'shipping_code'           => $order_query->row['shipping_code'],
                'comment'                 => $order_query->row['comment'],
                'total'                   => $order_query->row['total'],
                'reward'                  => $reward,
                'order_status_id'         => $order_query->row['order_status_id'],
                'affiliate_id'            => $order_query->row['affiliate_id'],
                'affiliate_firstname'     => $affiliate_firstname,
                'affiliate_lastname'      => $affiliate_lastname,
                'commission'              => $order_query->row['commission'],
                'language_id'             => $order_query->row['language_id'],
                'language_code'           => $language_code,
                'language_filename'       => $language_filename,
                'language_directory'      => $language_directory,
                'currency_id'             => $order_query->row['currency_id'],
                'currency_code'           => $order_query->row['currency_code'],
                'currency_value'          => $order_query->row['currency_value'],
                'ip'                      => $order_query->row['ip'],
                'forwarded_ip'            => $order_query->row['forwarded_ip'],
                'user_agent'              => $order_query->row['user_agent'],
                'accept_language'         => $order_query->row['accept_language'],
                'date_added'              => $order_query->row['date_added'],
                'date_modified'           => $order_query->row['date_modified']
            );
        } else {
            return;
        }
    }
}

?>