<?php
$_['heading_title'] 		= 'Lazada Integration By Cedcommerce';

$_['text_module'] 			= 'Modules';
$_['text_extension'] 		= 'Extension';
$_['text_installed'] 		= 'Lazada Integration module is now installed.';
$_['text_success']          = 'Lazada Integration module\'s Configuration saved Successfully.' ;
$_['text_edit']             = 'Edit Lazada Settings';

// Left Menu
$_['ced_lazada'] 					= 'Lazada Integration';
$_['ced_lazada_category_text']		= 'Category';
$_['ced_lazada_brand_text']		    = 'Brand';
$_['ced_lazada_profile_text']		= 'Profile';
$_['ced_lazada_product_text']		= 'Products';
$_['ced_lazada_order_text']	        = 'Order';
$_['ced_lazada_import_order_text']	= 'Imported Order(s)';
$_['ced_lazada_fail_order_text']	= 'Failed Order(s)';
$_['ced_lazada_config_text']		= 'Configuration';

// Developer Settings
$_['entry_status']			= 'Status';
$_['entry_debug']			= 'Debug Mode';

// Product Settings
$_['entry_default_store']   = 'Default Store';

// Product (Price) Settings
$_['entry_price_variation']	= 'Product Price';
$_['entry_fix_price']		= 'Modify By Fix Price';
$_['entry_per_price']		= 'Modify By Percentage Price';
$_['entry_variant_color']   = 'Variant Color';
$_['entry_variant_size']    = 'Variant Size';

// Product (Inventory) Settings
$_['entry_inventory_threshold']	= 'Set Inventory on the Basis of Threshold';
$_['entry_inventory_threshold_value']  = 'Inventory Threshold Value';
$_['entry_inventory_threshold_less']	= 'Send Inventory for Lesser Than Threshold Case';
$_['entry_inventory_threshold_greater']	= 'Send Inventory for Greater Than Threshold Case';

// Order Settings
$_['entry_order_id_prefix']	= 'Lazada Order ID Prefix';
$_['entry_order_noti_email']= 'Order Notification Email';
$_['entry_enable_customer']	= 'Enable Default Customer';
$_['entry_default_customer']= 'Default Customer';

//App setting
$_['entry_app_name']             = 'App Name';
$_['entry_app_key']              = 'App Key';
$_['entry_app_secret']		      = 'App Secret';

$_['entry_redirect_uri']      = 'Redirect Uri';
$_['entry_code']              = 'By Code';
$_['entry_default_token']     = 'Default Token';
$_['entry_allowed_regions']   = 'Allowed Regions';
$_['entry_profile_regions']    = 'Country';

$_['error_redirect_uri']      = 'Redirect Uri must not be empty!';
$_['error_app_name']          = 'App Name must not be empty!';
$_['error_app_key']           = 'App Key must not be empty!';
$_['error_lazada_category']   = 'App Secret must not be empty!';
$_['error_app_credentials']   = 'Invalid app data. Unable to save. <br/> App validation failed. Credentials are Invalid.';

// Cron Setting
$_['entry_order_cron'] = 'Order Cron';
$_['entry_product_price_cron'] = 'Inventory/Price Cron';
$_['entry_add_new_product_cron'] = 'Add New Product Cron';

$_['error_fix_price']     = 'Give fixed price to modify price with';
$_['error_per_price']     = 'Give percentage to modify price with';
$_['error_cust']          = 'Select Customer.';
   
?>