<?php
// Heading
$_['heading_title']          = 'Cedlazada Apps';

// Text
$_['text_success']           = 'Success: You have modified App!';
$_['text_default']           = 'Default';
$_['text_list']              = 'Lazada App List';
$_['text_ced_lazada']        = 'Cedlazada';
$_['text_add']               = 'Add App';
$_['text_edit']              = 'Edit App';

//Tab
$_['tab_app_info']           = 'App Information';
$_['tab_app_install']        = 'App Installation';
$_['tab_app_token']          = 'App Token';

// Column
$_['column_app_id']			  = 'App ID';
$_['column_name']             = 'App Name';
$_['column_key']              = 'App Key';
$_['column_secret']		      = 'App Secret';
$_['column_action']           = 'Action';

// Entry
$_['entry_redirect_uri']      = 'Redirect Uri';
$_['entry_code']              = 'By Code';
$_['entry_default_token']     = 'Default Token';
$_['entry_allowed_regions']   = 'Allowed Regions';

// Button

$_['button_add']              = 'Add';
$_['button_edit']             = 'Edit';

// Error 
$_['error_warning']           = 'Warning: Please check the form carefully for errors!';
$_['error_permission']        = 'Warning: You do not have permission to modify information!';
$_['error_redirect_uri']      = 'Redirect Uri must not be empty!';
$_['error_app_name']          = 'App Name must not be empty!';
$_['error_app_key']           = 'App Key must not be empty!';
$_['error_lazada_category']   = 'App Secret must not be empty!';
$_['error_app_credentials']   = 'Invalid app data. Unable to save. <br/> App validation failed. Credentials are Invalid.';

?>