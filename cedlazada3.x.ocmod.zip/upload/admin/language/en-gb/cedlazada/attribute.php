<?php
/**
* CedCommerce
*
* NOTICE OF LICENSE
*
* This source file is subject to the End User License Agreement (EULA)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://cedcommerce.com/license-agreement.txt
*
* @attribute  modules
* @package   cedlazada
* @author    CedCommerce Core Team 
* @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
* @license   http://cedcommerce.com/license-agreement.txt
*/
// Heading
$_['heading_title']          = 'Lazada Attributes';

// Text
$_['text_success']           = 'Success: You have modified Attributes!';
$_['text_list']              = 'Lazada Attribute List';
$_['text_add']               = 'Fetch Attribute';
$_['button_add']             = 'Fetch Attribute';
$_['text_ced_lazada']        = 'Cedlazada';
// Column
$_['column_attribute_name']   = 'Attribute Name';
$_['column_attribute_id']     = 'Attribute ID';
$_['column_action']           = 'Action';

// Entry
$_['entry_attribute_name']    = 'Attribute Name';
$_['entry_attribute_id']      = 'Attribute ID';

// Error
$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify attributes!';