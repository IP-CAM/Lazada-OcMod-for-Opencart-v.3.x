<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedlazada
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
// Heading
$_['heading_title'] = 'Lazada Products';

// Text
$_['text_ced_lazada']        = 'Cedlazada';
$_['text_success'] = 'Success: You have modified products!';
$_['text_success_retire'] = 'Product Deleted Successfully';
$_['text_list'] = 'Product List';

$_['button_stock_update'] = 'Update Stock & Price';
$_['button_insert'] = 'Upload';
$_['button_all'] = 'Upload All';

// Column
$_['column_name'] = 'Product Name';
$_['column_model'] = 'Model';
$_['column_image'] = 'Image';
$_['column_price'] = 'Price';
$_['column_quantity'] = 'Quantity';
$_['column_profile_name'] = 'Profile Name';
$_['column_status'] = 'Status';
$_['column_action'] = 'Action';
$_['column_wstatus'] = 'Lazada Status';

// Error
$_['error_warning'] = 'Warning: Please check the form carefully for errors!';
$_['error_permission'] = 'Warning: You do not have permission to modify products!';
$_['error_selected'] = 'Please select Product.';