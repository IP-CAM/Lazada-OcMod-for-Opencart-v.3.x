<?php
// Heading
$_['heading_title']           = 'Cedlazada Profile';

// Text
$_['text_success']            = 'Success: You have modified Profile!';
$_['text_default']            = 'Default';
$_['text_ced_lazada']         = 'Cedlazada';
$_['text_add']                = 'Add Profile';
$_['text_edit']               = 'Edit Profile';
$_['text_list']               = 'Lazada Profile List';

//Tab
$_['tab_general']             = 'General Information';
$_['tab_profile_mappings']    = 'Profile Mappings';
$_['tab_lazada_mappings']     = 'Lazada Category & Attribute';

// Column
$_['column_id']			      = 'Profile ID';
$_['column_code']             = 'Profile Code';
$_['column_name']             = 'Profile Name';
$_['column_status']		      = 'Status';
$_['column_action']           = 'Action';

// Entry
$_['entry_enable']            = 'Enable Profile:';
$_['entry_profile_code']      = 'Profile Code';
$_['entry_profile_name']      = 'Profile Name';
$_['entry_profile_app']       = 'Profile App';
$_['entry_profile_regions']   = 'Profile Regions';
$_['entry_lazada_category']   = 'Lazada Category';
$_['entry_lazada_attributes'] = 'Lazada Attribute';
$_['entry_store_attributes']  = 'Store Attribute';
$_['entry_default_value']     = 'Default Value';
$_['entry_store_category']    = 'Store Category';

// Error 
$_['error_warning']           = 'Warning: Please check the form carefully for errors!';
$_['error_permission']        = 'Warning: You do not have permission to modify information!';
$_['error_profile_code']      = 'Profile Code must not be empty!';
$_['error_profile_name']      = 'Profile Name must not be empty!';
$_['error_profile_app']       = 'Please select Profile App';
$_['error_lazada_category']   = 'Please select Category';
?>