<?php
/**
* CedCommerce
*
* NOTICE OF LICENSE
*
* This source file is subject to the End User License Agreement (EULA)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://cedcommerce.com/license-agreement.txt
*
* @category  modules
* @package   cedlazada
* @author    CedCommerce Core Team 
* @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
* @license   http://cedcommerce.com/license-agreement.txt
*/

class ControllerExtensionModuleCedlazada extends Controller{
    private $error = array();

    public function index(){
        $this->load->language('extension/module/cedlazada');
        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('ced_lazada', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] , true));
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        
        // Developer Settings
        $developer_tabs = array('status','debug');

        foreach ($developer_tabs as $developer_tab) 
         {
           $data['entry_' . $developer_tab] = $this->language->get('entry_' . $developer_tab);
         }

        //App settings
        $app_tabs = array('redirect_uri', 'app_name', 'app_key', 'app_secret', 'profile_regions', 'code', 'access_token', 'refresh_token', 'expires_in', 'refresh_expires_in');

        foreach ($app_tabs as $app_tab)
        {
            $data['entry_' . $app_tab] = $this->language->get('entry_' . $app_tab);
        }

        // Product Settings
        $product_tabs = array('default_store', 'price_variation', 'fix_price', 'per_price', 'variant_color', 'variant_size', 'inventory_threshold', 'inventory_threshold_value', 'inventory_threshold_less', 'inventory_threshold_greater');

        foreach ($product_tabs as $product_tab) 
         {
           $data['entry_' . $product_tab] = $this->language->get('entry_' . $product_tab);
         }
         $this->load->model('customer/customer');
         $data['default_customer'] = $this->model_customer_customer->getCustomers();

        // Order Settings
        $order_tabs = array('order_id_prefix', 'order_noti_email', 'enable_customer', 'default_customer');

        foreach ($order_tabs as $order_tab) 
         {
           $data['entry_' . $order_tab] = $this->language->get('entry_' . $order_tab);
         }

         // Cron Settings
        $cron_tabs = array('order_cron', 'product_price_cron', 'add_new_product_cron');

        foreach ($cron_tabs as $cron_tab) 
         {
           $data['entry_' . $cron_tab] = $this->language->get('entry_' . $cron_tab);
         }

        // Developer Settings
        foreach ($developer_tabs as $developer_tab) 
        {
            if (isset($this->request->post['ced_lazada_' . $developer_tab])) {
                $data['ced_lazada_' . $developer_tab] = $this->request->post['ced_lazada_' . $developer_tab];
            } else {
                $data['ced_lazada_' . $developer_tab] = $this->config->get('ced_lazada_' . $developer_tab);
            }
        }

        // App Settings
        foreach($app_tabs as $app_tab)
        {
            if(isset($this->request->post['ced_lazada_' . $app_tab])){
                $data['ced_lazada_' . $app_tab] = $this->request->post['ced_lazada_' . $app_tab];
            }else{
                $data['ced_lazada_' . $app_tab] = $this->config->get('ced_lazada_' . $app_tab);
            }
        }

        $this->load->model('setting/store');
   
        $data['default_stores'] = $this->model_setting_store->getStores();

        $data['price_variations'] = array(
                '1'=>'Default Price',
                '2'=>'Increase By Fix Price',
                '3'=>'Decrease By Fix Price',
                '4'=>'Increase By Fix Percent',
                '5'=>'Decrease By Fix Percent'
               );

        // Product Settings
        foreach ($product_tabs as $product_tab)
        {
            if (isset($this->request->post['ced_lazada_' . $product_tab])) {
                $data['ced_lazada_' . $product_tab] = $this->request->post['ced_lazada_' . $product_tab];
            } else {
                $data['ced_lazada_' . $product_tab] = $this->config->get('ced_lazada_' . $product_tab);
            }
        }

        // Order Settings
        foreach ($order_tabs as $order_tab)
        {
            if (isset($this->request->post['ced_lazada_' . $order_tab])) {
                $data['ced_lazada_' . $order_tab] = $this->request->post['ced_lazada_' . $order_tab];
            } else {
                $data['ced_lazada_' . $order_tab] = $this->config->get('ced_lazada_' . $order_tab);
            }
        }

        // Cron Settings
        foreach ($cron_tabs as $cron_tab)
        {
            if (isset($this->request->post['ced_lazada_' . $cron_tab])) {
                $data['ced_lazada_' . $cron_tab] = $this->request->post['ced_lazada_' . $cron_tab];
            } else {
                $data['ced_lazada_' . $cron_tab] = $this->config->get('ced_lazada_' . $cron_tab);
            }
        }

        $data['variant_data'] = array();

        $sql = $this->db->query("SELECT option_id, name FROM `". DB_PREFIX ."option_description` WHERE language_id = '". $this->config->get('config_language_id') ."' ");
        $variants = $sql->rows;

        $data['variant_data'] = $variants;

        $data['cedlazada_order_cron']   = 'wget -q -O /dev/null'. HTTPS_CATALOG . 'index.php?route=cedlazada/order/fetchOrder' .'> /dev/null 2>&1';
        $data['cedlazada_updatestock_cron'] = 'wget -q -O /dev/null'. HTTPS_CATALOG . 'index.php?route=cedlazada/product/updateStock' .'> /dev/null 2>&1';
        $data['cedlazada_addnewproduct_cron'] = 'wget -q -O /dev/null'. HTTPS_CATALOG . 'index.php?route=cedlazada/product/addNewProduct' .'> /dev/null 2>&1';


        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if(isset($this->error['fix_price'])){
            $data['error_fix_price'] = $this->error['fix_price'];
        } else {
            $data['error_fix_price'] = '';
        }

        if(isset($this->error['per_price'])){
            $data['error_per_price'] = $this->error['per_price'];
        } else {
            $data['error_per_price'] = '';
        }

        if(isset($this->error['cust'])){
            $data['error_cust'] = $this->error['cust'];
        } else {
            $data['error_cust'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
      
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/cedlazada', 'user_token=' . $this->session->data['user_token'], true)
            );
        $data['user_token']= $this->session->data['user_token'];

        $data['action'] = $this->url->link('extension/module/cedlazada', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
        
        $data['user_token'] = $this->session->data['user_token'];

        $data['ced_lazada_redirect_uri'] = HTTPS_CATALOG.'index.php?route=cedlazada/code/getCode';

        $data['regions'] = array(
            'id' => 'Indonesia',
            'my' => 'Malaysia',
            'ph' => 'Philipines',
            'vn' => 'Vietnam',
            'sg' => 'Singapore',
            'th' => 'Thailand'
            );

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/cedlazada', $data));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/cedlazada')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if($this->request->post['ced_lazada_price_variation'] == '2' || $this->request->post['ced_lazada_price_variation'] == '3'){
            if(!$this->request->post['ced_lazada_fix_price']){
                $this->error['fix_price'] = $this->language->get('error_fix_price');
            }
        }

        if($this->request->post['ced_lazada_price_variation'] == '4' || $this->request->post['ced_lazada_price_variation'] == '5'){
            if(!$this->request->post['ced_lazada_per_price']){
                $this->error['per_price'] = $this->language->get('error_per_price');
            }
        }

        if($this->request->post['ced_lazada_enable_customer'] == '1' && !$this->request->post['ced_lazada_default_customer']){
            $this->error['cust'] = $this->language->get('error_cust');
        }

        return !$this->error;
    }

    public function install() 
    {

        $this->load->model('setting/event');
        $this->model_setting_event->addEvent('add_lazada_menu', 'admin/view/common/column_left/before', 'cedlazada/column_left/eventMenu');
            
        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'extension/module/cedlazada');
        
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'extension/module/cedlazada');
            
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'cedlazada/category');
        
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'cedlazada/category');
            
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'cedlazada/brand');
        
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'cedlazada/brand');

        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'cedlazada/profile');
        
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'cedlazada/profile');
        
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'cedlazada/product');
        
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'cedlazada/product');
        
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'cedlazada/order');
        
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'cedlazada/order');
        
        $this->load->library('cedlazada');
        
        $cedlazada_lib = Cedlazada::getInstance($this->registry);
        
        if (!$cedlazada_lib->isCedlazadaInstalled()) {
        
            $cedlazada_lib->installCedlazada();
        }
             
        $this->load->model('setting/event');

        $this->model_setting_event->addEvent('ced_lazada', 'post.admin.product.add', 'cedlazada/product/addNewProductsToVariants');
    }

    public function uninstall() {
        $this->db->query("DELETE  FROM `". DB_PREFIX ."setting` WHERE `key` LIKE '%ced_lazada%'");

        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode('add_lazada_menu');
    }
}