<?php
// require_once DIR_SYSTEM."library/lazada-sdk/Autoloader.php";
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedlazada
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

class ControllerCedlazadaProduct extends Controller
{
    private $error = array();
    
    const DIRECTORY_NAME = 'products';

    public function index()
    {
        $this->load->language('cedlazada/product');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedlazada/product');

        $this->getList();
    }

    protected function getList()
    {  
        if (isset($this->request->get['profile_name'])) {
            $filter_profile_name = $this->request->get['profile_name'];
        } else {
            $filter_profile_name = null;
        }

        if (isset($this->request->get['filter_name'])) {
            $filter_name = $this->request->get['filter_name'];
        } else {
            $filter_name = null;
        }

        if (isset($this->request->get['filter_model'])) {
            $filter_model = $this->request->get['filter_model'];
        } else {
            $filter_model = null;
        }

        if (isset($this->request->get['filter_price'])) {
            $filter_price = $this->request->get['filter_price'];
        } else {
            $filter_price = null;
        }

        if (isset($this->request->get['filter_quantity'])) {
            $filter_quantity = $this->request->get['filter_quantity'];
        } else {
            $filter_quantity = null;
        }

        if (isset($this->request->get['filter_status'])) {
            $filter_status = $this->request->get['filter_status'];
        } else {
            $filter_status = null;
        }

        if (isset($this->request->get['filter_lazada_status'])) {
            $filter_lazada_status = $this->request->get['filter_lazada_status'];
        } else {
            $filter_lazada_status = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'pd.name';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_lazada_status'])) {
            $url .= '&filter_lazada_status=' . $this->request->get['filter_lazada_status'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_ced_lazada'),
            'href' => $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $data['insert'] = $this->url->link('cedlazada/product/insert', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
        $data['stock_update'] = $this->url->link('cedlazada/product/updateStock', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
        // $data['price_update'] = $this->url->link('cedlazada/product/updatePrice', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
        $data['delete'] = $this->url->link('cedlazada/product/retire', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');

        $data['products'] = array();

        $filter_data = array(
            'filter_name' => $filter_name,
            'filter_model' => $filter_model,
            'filter_price' => $filter_price,
            'filter_quantity' => $filter_quantity,
            'filter_status' => $filter_status,
            'filter_lazada_status' => $filter_lazada_status,
            'filter_profile_name' => $filter_profile_name,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );

        $this->load->model('tool/image');
        $this->load->model('cedlazada/product');

        $product_total = $this->model_cedlazada_product->getTotalProducts($filter_data);

        $results = $this->model_cedlazada_product->getProducts($filter_data);
        // echo '<pre>'; print_r($results); die;
        foreach ($results as $result) {
            $action = array();

            $action[] = array(
                'text' => $this->language->get('text_edit'),
                'href' => $this->url->link('cedlazada/product/edit', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . $result['product_id'] . $url, 'SSL')
            );

            $data['view'] = $this->language->get('text_view');

            $action[] = array(
                'text' => $this->language->get('text_view'),
                'href' => 'false'
            );

            if ($result['image'] && file_exists(DIR_IMAGE . $result['image'])) {
                $image = $this->model_tool_image->resize($result['image'], 40, 40);
            } else {
                $image = $this->model_tool_image->resize('no_image.jpg', 40, 40);
            }

            $special = false;
            $this->load->model('catalog/product');
            $product_specials = $this->model_catalog_product->getProductSpecials($result['product_id']);

            foreach ($product_specials as $product_special) {
                if (($product_special['date_start'] == '0000-00-00' || $product_special['date_start'] < date('Y-m-d')) && ($product_special['date_end'] == '0000-00-00' || $product_special['date_end'] > date('Y-m-d'))) {
                    $special = $product_special['price'];

                    break;
                }
            }

            //$cedlazada_inventry_choice    = $this->config->get('cedlazada_inventry_choice');
            //$cedlazada_price_choice   = $this->config->get('cedlazada_price_choice');

            $data['products'][] = array(
                'product_id' => $result['product_id'],
                'name' => $result['name'],
                'model' => $result['model'],
                'price' => ($result['price']) ? $result['price'] : '0.0',
                'special' => $special,
                'image' => $image,
                'profile_name' => $result['profile_name'],
                'quantity' => ($result['quantity']) ? $result['quantity'] : '0',
                'status' => ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
                'cedlazada_status' => ($result['lazada_status']) ? $result['lazada_status'] : 'Not Uploaded',
                'error_message' => isset($result['error_message']) ? $result['error_message'] : '',
                'selected' => isset($this->request->post['selected']) && in_array($result['product_id'], $this->request->post['selected']),
                'action' => $action
            );
        }
        $data['profiles'] = $this->model_cedlazada_product->getAllProfiles();
        //print_r($data);die;
        $data['all_url'] = $this->url->link('cedlazada/product/uploadall', 'user_token=' . $this->session->data['user_token'], 'SSL');
        $data['fetchstatus'] = $this->url->link('cedlazada/product/fetchstatus', 'user_token=' . $this->session->data['user_token'], 'SSL');

        $data['filter_lazada_status'] = $filter_lazada_status;
        $data['profile_filter'] = $filter_profile_name;
        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_list'] = $this->language->get('text_list');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['button_fetchstatus'] = $this->language->get('button_fetchstatus');
        $data['button_updateProduct'] = $this->language->get('button_updateProduct');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['text_image_manager'] = $this->language->get('text_image_manager');

        $data['column_image'] = $this->language->get('column_image');
        $data['column_name'] = $this->language->get('column_name');
        $data['column_model'] = $this->language->get('column_model');
        $data['column_price'] = $this->language->get('column_price');
        $data['column_quantity'] = $this->language->get('column_quantity');
        $data['column_status'] = $this->language->get('column_status');
        $data['column_wstatus'] = $this->language->get('column_wstatus');
        $data['column_action'] = $this->language->get('column_action');

        $data['button_stock_update'] = $this->language->get('button_stock_update');
        $data['button_price_update'] = $this->language->get('button_price_update');
        $data['button_insert'] = $this->language->get('button_insert');
        $data['button_all'] = $this->language->get('button_all');
        $data['button_delete'] = $this->language->get('button_delete');
        $data['button_filter'] = $this->language->get('button_filter');
        $data['column_profile_name'] = $this->language->get('column_profile_name');

        $data['user_token'] = $this->session->data['user_token'];

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_lazada_status'])) {
            $url .= '&filter_lazada_status=' . $this->request->get['filter_lazada_status'];
        }

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }
        // $data['cedlazada_status'] = $this->model_cedlazada_product->getlazadaStatuses();

        $data['sort_name'] = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . '&sort=pd.name' . $url, 'SSL');
        $data['sort_model'] = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . '&sort=p.model' . $url, 'SSL');
        $data['sort_price'] = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . '&sort=p.price' . $url, 'SSL');
        $data['sort_quantity'] = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . '&sort=p.quantity' . $url, 'SSL');
        $data['sort_status'] = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . '&sort=p.status' . $url, 'SSL');
        $data['sort_wstatus'] = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . '&sort=p.cedlazada_status' . $url, 'SSL');
        $data['sort_order'] = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . '&sort=p.sort_order' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_lazada_status'])) {
            $url .= '&filter_lazada_status=' . $this->request->get['filter_lazada_status'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $product_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));

        $data['filter_name'] = $filter_name;
        $data['filter_model'] = $filter_model;
        $data['filter_price'] = $filter_price;
        $data['filter_quantity'] = $filter_quantity;
        $data['filter_status'] = $filter_status;
        $data['filter_lazada_status'] = $filter_lazada_status;

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('cedlazada/product_list', $data));
    }

    public function update() {

        $this->language->load('cedlazada/product');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedlazada/product');
        //  echo '<pre>'; print_r($this->request->post); die;
    
        if (($this->request->server['REQUEST_METHOD'] == 'POST')) {

            $this->model_cedlazada_product->editProduct($this->request->get['product_id'], $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'], 'SSL'));
        }

        $this->getList();
    }

    public function edit(){
        $this->load->language('cedlazada/product');

        $data['heading_title'] = $this->language->get('heading_title');

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_ced_lazada'),
            'href' => $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['update'] = $this->url->link('cedlazada/product/update', 'user_token=' . $this->session->data['user_token']  . '&product_id=' . $this->request->get['product_id'], 'SSL');

        $data['back'] = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'], 'SSL');

        if(isset($this->request->get['product_id'])){
            $data['product_id'] = $this->request->get['product_id'];
        } else {
            $data['product_id'] = '';
        }
        $data['configurable_products'] = array();

        $this->load->model('cedlazada/product');
        $storedConfigData = $this->model_cedlazada_product->getConfigData($this->request->get['product_id']);
        
        if(!empty($storedConfigData))
            $data['storedConfigData'] = $storedConfigData;

        $results = $this->model_cedlazada_product->getConfigurableProducts($this->request->get['product_id']);
        // echo '<pre>'; print_r($results); die;
        if(isset($this->request->post['configurable_products'])){
            $data['configurable_products'] = $this->request->post['configurable_products'];
        } elseif(isset($results) && !empty($results)){
            $data['configurable_products'] = $results;
        } else {
            $data['configurable_products'] = array();
        }
        
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('cedlazada/product_form', $data));

    }

    public function uploadall()
    {
        $this->load->language('cedlazada/product');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('cedlazada/product');
        $productIds = $this->model_cedlazada_product->getAllLazadaProductIds();
        $url = '';
        if ($productIds && count($productIds)) {
            $total_product = count($productIds);
            $array_chunk_count = ceil($total_product / 100);
            $productIds = array_chunk($productIds, $array_chunk_count);
            $data['product_ids'] = json_encode($productIds);
            $data['heading_title'] = $this->language->get('heading_title');
            $data['button_Back'] = $this->language->get('button_Back');
            $data['back'] = $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'], 'SSL');

            $data['breadcrumbs'] = array();
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
            );

             $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_ced_lazada'),
                'href' => $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
            );
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('tool/backup', 'user_token=' . $this->session->data['user_token'], 'SSL')
            );
            $data['user_token'] = $this->session->data['user_token'];
            $data['text_list']=$this->language->get('text_list');
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');

            $this->response->setOutput($this->load->view('cedlazada/uploadallstatus', $data));
        } else {
            $this->error['warning'] = 'No Category Mapped in profile or profile does not have any product yet';
            $this->getList();
        }
    }

    public function uploadallProcess()
    {
        $json = array();
        $productIds = $this->request->post;
        // $this->request->post['profile_regions'] = 'my';

        if (!empty($productIds) && isset($productIds['selected'])) {
            $product_ids = $productIds['selected'];
            $this->load->library('cedlazada');
            $cedlazada = Cedlazada::getInstance($this->registry);
            $json = $cedlazada->uploadAllProducts($product_ids, '/product/create');
            // $this->load->model('cedlazada/product');
            // $json = $this->model_cedlazada_product->uploadAllProducts($product_ids, '/product/create');
        } else {
            $json['success'] = false;
            $json['message'] = 'No Profile Create or not product in Profile yet.';
        }

        // $this->response->addHeader('Content-Type: application/json');
        // echo '<pre>';print_r($json);die;
        $this->response->setOutput(json_encode($json));
    }

    public function massupload()
    {
        $json = array();
        $params = $this->request->post;
        
        if (isset($params['selected']) && count($params['selected']))
        {
            if (is_array($params['selected']) && count($params['selected']))
            {
                $product_ids = $params['selected'];
                $this->load->library('cedlazada');
                $cedlazada = Cedlazada::getInstance($this->registry);
                $json = $cedlazada->uploadAllProducts($product_ids, '/product/create');
                //echo '<pre>'; print_r($json); die;
                // $this->load->model('cedlazada/product');
                // $json = $this->model_cedlazada_product->uploadAllProducts($product_ids, '/product/create');
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'Error while uploading product.';
        }

        // $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function updateStock()
    {
        $this->load->language('cedlazada/product');
        $this->document->setTitle($this->language->get('heading_title'));
        // $this->load->model('cedlazada/product');
        $productIds = $this->request->post;
        if (!empty($productIds) && isset($productIds['selected'])) 
        {
            $product_ids = $productIds['selected'];
            if (is_array($product_ids) && count($product_ids)) {
                $this->load->library('cedlazada');
                $cedlazada = Cedlazada::getInstance($this->registry);
                $result = $cedlazada->updatePriceQuantity($product_ids);
                // echo '<pre>'; print_r($result); die;
                // $result = $this->model_cedlazada_product->updatePriceQuantity($product_ids, '/product/price_quantity/update');
                if(isset($result['success']) && $result['success'] == true){
                    $this->session->data['success'] = $result['message'];
                } else {
                    $this->error['warning'] = $result['message'];
                    
                }
            }
        } else {
            $this->error['warning'] = 'Please Select Product';
        }
        $this->getList();
    }

    public function retire()
    {
        $this->load->language('cedlazada/product');
        $this->document->setTitle($this->language->get('heading_title'));
        // $this->load->model('cedlazada/product');
        $result = array();
        $params = $this->request->post;
        if (isset($params['selected']) && count($params['selected'])) {
            if (is_array($params['selected']) && count($params['selected'])) {
                $product_ids = $params['selected'];
                $this->load->library('cedlazada');
                $cedlazada = Cedlazada::getInstance($this->registry);
                $result = $cedlazada->removeProducts($product_ids);
                // $result = $this->model_cedlazada_product->removeProducts($product_ids, '/product/remove');
                if(isset($result['success']) && $result['success'] == true){
                    $this->session->data['success'] = $result['message'];
                } else {
                    $this->error['warning'] = $result['message'];
                }
            }
        } else {
            $this->error['warning'] = 'Error while uploading product.';
        }
        $this->getList();
    }

    public function updateProduct()
    {
        $json = array();
        $params = $this->request->post;
        
        if (isset($params['selected']) && count($params['selected'])) {
            if (is_array($params['selected']) && count($params['selected'])) {
                $product_ids = $params['selected'];
                // $this->load->model('cedlazada/product');
                $this->load->library('cedlazada');
                $cedlazada = Cedlazada::getInstance($this->registry);
                $json = $cedlazada->uploadAllProducts($product_ids, '/product/update');
                // $json = $this->model_cedlazada_product->uploadAllProducts($product_ids, '/product/update');
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'Error while updating product.';
        }

        // $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function addNewProductsToVariants($product_id)
   {
       $query = $this->db->query("SELECT category_id FROM `". DB_PREFIX."product_to_category` WHERE product_id = '". $product_id ."' ");
       $result = $query->row;
       $categories = $this->getMappedCategoryIds();
       foreach($categories as $key => $value)
       {
          $categories[$key] = array_unique($value);
           if(in_array($result['category_id'], $value))
               $this->db->query("INSERT INTO `". DB_PREFIX ."cedlazada_profile_products` (`lazada_profile_id` , `product_id`) VALUES ('". $key ."', '". $product_id."') ");
       }
   }

    public function getMappedCategoryIds() {
        $store_category = $this->db->query("SELECT * FROM `".DB_PREFIX."cedlazada_profile`");
        $categories = array();
        if($store_category->num_rows) {
            foreach ($store_category->rows as $key => $store_cat) {
                if(json_decode($store_cat['store_category'], true)) {
                    $store_category = json_decode($store_cat['store_category'], true);
                    $profile_id = $store_cat['id'];
                    $categories[$profile_id] = $store_category;
                }
            }
            $categories = array_filter($categories);
            foreach($categories as $key => $value){
                $categories[$key] = array_unique($value);
            }
        }
        return $categories ;
    }

}