<?php
class ControllerCedlazadaColumnLeft extends Controller {
    public function eventMenu($route, &$data)
    {
        $this->load->language('extension/module/cedlazada');

        $cedlazada_menu = array();

        // Category
        $cedlazada_menu[] = array(
            'name'	   => $this->language->get('ced_lazada_category_text'),
            'href'     => $this->url->link('cedlazada/category', 'user_token=' . $this->session->data['user_token'], true),
            'children' => array()
        );

        // Brand
        $cedlazada_menu[] = array(
            'name'	   => $this->language->get('ced_lazada_brand_text'),
            'href'     => $this->url->link('cedlazada/brand', 'user_token=' . $this->session->data['user_token'], true),
            'children' => array()
        );

        // Profile
        $cedlazada_menu[] = array(
            'name'	   => $this->language->get('ced_lazada_profile_text'),
            'href'     => $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'], true),
            'children' => array()
        );

        // Product
        $cedlazada_menu[] = array(
            'name'	   => $this->language->get('ced_lazada_product_text'),
            'href'     => $this->url->link('cedlazada/product', 'user_token=' . $this->session->data['user_token'], true),
            'children' => array()
        );

        // lazada order menu
        $cedlazada_menu_order=array();
        //	if ($this->user->hasPermission('access', 'cedlazada/order')) {
        $cedlazada_menu_order[] = array(
            'name'	   => $this->language->get('ced_lazada_import_order_text'),
            'href'     => $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'], true),
            'children' => array()
        );
        $cedlazada_menu_order[] = array(
            'name'	   => $this->language->get('ced_lazada_fail_order_text'),
            'href'     => $this->url->link('cedlazada/order/fail', 'user_token=' . $this->session->data['user_token'], true),
            'children' => array()
        );

        $cedlazada_menu[] = array(
            'name'	   => $this->language->get('ced_lazada_order_text'),
            'href'     => '',
            'children' => $cedlazada_menu_order
        );

        // Configuration
        $cedlazada_menu[] = array(
            'name'	   => $this->language->get('ced_lazada_config_text'),
            'href'     => $this->url->link('extension/module/cedlazada', 'user_token=' . $this->session->data['user_token'], true),
            'children' => array()
        );

        $data['menus'][] = array(
            'id'       => 'menu-lazada',
            'icon'	   => 'icon-industry',
            'name'	   => $this->language->get('ced_lazada'),
            'href'     => '',
            'children' => $cedlazada_menu
        );

    }
}
