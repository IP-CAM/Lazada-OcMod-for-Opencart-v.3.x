<?php
require_once DIR_SYSTEM."library/lazada-sdk/Autoloader.php";
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedlazada
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

class ControllerCedlazadaOrder extends Controller
{
    private $error = array();

    public function index()
    {
        $this->load->language('cedlazada/order');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->getList();
    }

    protected function getList()
    {
        if (isset($this->request->get['filter_order_id'])) {
            $filter_order_id = $this->request->get['filter_order_id'];
        } else {
            $filter_order_id = null;
        }

        if (isset($this->request->get['filter_customer'])) {
            $filter_customer = $this->request->get['filter_customer'];
        } else {
            $filter_customer = null;
        }

        if (isset($this->request->get['filter_total'])) {
            $filter_total = $this->request->get['filter_total'];
        } else {
            $filter_total = null;
        }

        if (isset($this->request->get['filter_date_added'])) {
            $filter_date_added = $this->request->get['filter_date_added'];
        } else {
            $filter_date_added = null;
        }

        if (isset($this->request->get['filter_date_modified'])) {
            $filter_date_modified = $this->request->get['filter_date_modified'];
        } else {
            $filter_date_modified = null;
        }

        if (isset($this->request->get['filter_lazada_order_status_id'])) {
            $filter_lazada_order_status_id = $this->request->get['filter_lazada_order_status_id'];
        } else {
            $filter_lazada_order_status_id = null;
        }

        if (isset($this->request->get['filter_lazada_order_id'])) {
            $filter_lazada_order_id = $this->request->get['filter_lazada_order_id'];
        } else {
            $filter_lazada_order_id = null;
        }
        if (isset($this->request->get['filter_order_status_id'])) {
            $filter_order_status_id = $this->request->get['filter_order_status_id'];
        } else {
            $filter_order_status_id = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'o.order_id';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'DESC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['filter_order_id'])) {
            $url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
        }

        if (isset($this->request->get['filter_customer'])) {
            $url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_total'])) {
            $url .= '&filter_total=' . $this->request->get['filter_total'];
        }

        if (isset($this->request->get['filter_date_added'])) {
            $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
        }

        if (isset($this->request->get['filter_date_modified'])) {
            $url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
        }

        if (isset($this->request->get['filter_lazada_order_status_id'])) {
            $url .= '&filter_lazada_order_status_id=' . $this->request->get['filter_lazada_order_status_id'];
        }

        if (isset($this->request->get['filter_lazada_order_id'])) {
            $url .= '&filter_lazada_order_id=' . $this->request->get['filter_lazada_order_id'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_ced_lazada'),
            'href' => $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $data['shipping'] = $this->url->link('cedlazada/order/shipping', 'user_token=' . $this->session->data['user_token'], 'SSL');
        $data['fetchOrder'] = $this->url->link('cedlazada/order/fetchOrder', 'user_token=' . $this->session->data['user_token'], 'SSL');
        $data['multi'] = $this->url->link('cedlazada/order/acknowledge', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
        $data['rejected'] = $this->url->link('cedlazada/order/rejection', 'user_token=' . $this->session->data['user_token'], 'SSL');
        $data['orders'] = array();

        $filter_data = array(
            'filter_order_id' => $filter_order_id,
            'filter_customer' => $filter_customer,
            'filter_total' => $filter_total,
            'filter_date_added' => $filter_date_added,
            'filter_date_modified' => $filter_date_modified,
            'filter_lazada_order_id' => $filter_lazada_order_id,
            'filter_lazada_order_status_id' => $filter_lazada_order_status_id,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );
         $order_prefix = $this->config->get('ced_lazada_order_id_prefix');
        if(!empty($order_prefix))
            $data['order_prefix'] = $order_prefix;
        else
            $data['order_prefix'] = '';

        $this->load->model('cedlazada/order');
        $order_total = $this->model_cedlazada_order->getTotalOrders($filter_data);

        $results = $this->model_cedlazada_order->getOrders($filter_data);

        if ($results) {
            foreach ($results as $result) {
                $data['orders'][] = array(
                    'order_id' => $result['order_id'],
                    'lazada_order_id' => $result['lazada_order_id'],
                    'customer' => $result['customer'],
                    'status' => $result['order_status'],
                    'wstatus' => $result['wstatus'],
                    'total' => $this->currency->format($result['total'], $result['currency_code'], $result['currency_value']),
                    'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
                    'date_modified' => date($this->language->get('date_format_short'), strtotime($result['date_modified'])),
                    'shipping_code' => $result['shipping_code'],
                    'view' => $this->url->link('cedlazada/order/info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $result['order_id'] . $url, 'SSL'),
                    'ship' => $this->url->link('cedlazada/order/ship', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $result['order_id'] . $url, 'SSL'),
                    'selected' => isset($this->request->post['selected']) && in_array($result['order_id'], $this->request->post['selected']),
                );
            }
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_list'] = $this->language->get('text_list');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['text_confirm'] = $this->language->get('text_confirm');
        $data['text_missing'] = $this->language->get('text_missing');

        $data['column_order_id'] = $this->language->get('column_order_id');
        $data['column_lazada_order_id'] = $this->language->get('column_lazada_order_id');
        $data['column_customer'] = $this->language->get('column_customer');
        $data['column_status'] = $this->language->get('column_status');
        $data['column_wstatus'] = $this->language->get('column_wstatus');
        $data['column_total'] = $this->language->get('column_total');
        $data['column_date_added'] = $this->language->get('column_date_added');
        $data['column_date_modified'] = $this->language->get('column_date_modified');
        $data['column_action'] = $this->language->get('column_action');

        $data['entry_return_id'] = $this->language->get('entry_return_id');
        $data['entry_order_id'] = $this->language->get('entry_order_id');
        $data['entry_customer'] = $this->language->get('entry_customer');
        $data['entry_order_status'] = $this->language->get('entry_order_status');
        $data['entry_total'] = $this->language->get('entry_total');
        $data['entry_date_added'] = $this->language->get('entry_date_added');
        $data['entry_date_modified'] = $this->language->get('entry_date_modified');

        $data['button_invoice_print'] = $this->language->get('button_invoice_print');
        $data['button_shipping_print'] = $this->language->get('button_shipping_print');
        $data['button_insert'] = $this->language->get('button_insert');
        $data['button_edit'] = $this->language->get('button_edit');
        $data['button_rejection'] = $this->language->get('button_rejection');
        $data['button_shipment'] = $this->language->get('button_ship');
        $data['button_filter'] = $this->language->get('button_filter');
        $data['button_view'] = $this->language->get('button_view');

        $data['user_token'] = $this->session->data['user_token'];

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['error_module'])) {
            $data['error_warning'] = $this->error['error_module'];
        } else if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->request->post['selected'])) {
            $data['selected'] = (array)$this->request->post['selected'];
        } else {
            $data['selected'] = array();
        }

        $url = '';

        if (isset($this->request->get['filter_order_id'])) {
            $url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
        }

        if (isset($this->request->get['filter_customer'])) {
            $url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_total'])) {
            $url .= '&filter_total=' . $this->request->get['filter_total'];
        }

        if (isset($this->request->get['filter_date_added'])) {
            $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
        }

        if (isset($this->request->get['filter_date_modified'])) {
            $url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
        }

        if (isset($this->request->get['filter_lazada_order_status_id'])) {
            $url .= '&filter_lazada_order_status_id=' . $this->request->get['filter_lazada_order_status_id'];
        }

        if (isset($this->request->get['filter_lazada_order_id'])) {
            $url .= '&filter_lazada_order_id=' . $this->request->get['filter_lazada_order_id'];
        }

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_order'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . '&sort=o.order_id' . $url, 'SSL');
        $data['sort_customer'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . '&sort=customer' . $url, 'SSL');
        $data['sort_status'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, 'SSL');
        $data['sort_total'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . '&sort=o.total' . $url, 'SSL');
        $data['sort_date_added'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, 'SSL');
        $data['sort_date_modified'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_modified' . $url, 'SSL');
        $data['sort_wstatus'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . '&sort=wo.status' . $url, 'SSL');
        $data['sort_lazada_order_id'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . '&sort=wo.lazada_order_id' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['filter_order_id'])) {
            $url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
        }

        if (isset($this->request->get['filter_customer'])) {
            $url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_order_status'])) {
            $url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
        }

        if (isset($this->request->get['filter_total'])) {
            $url .= '&filter_total=' . $this->request->get['filter_total'];
        }

        if (isset($this->request->get['filter_date_added'])) {
            $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
        }

        if (isset($this->request->get['filter_date_modified'])) {
            $url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }
        $pagination = new Pagination();
        $pagination->total = $order_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));

        $data['filter_order_id'] = $filter_order_id;
        $data['filter_customer'] = $filter_customer;
        $data['filter_total'] = $filter_total;
        $data['filter_date_added'] = $filter_date_added;
        $data['filter_date_modified'] = $filter_date_modified;
        $data['filter_lazada_order_status_id'] = $filter_lazada_order_status_id;
        $data['filter_lazada_order_id'] = $filter_lazada_order_id;
        $data['filter_order_status_id'] = $filter_order_status_id;

        $this->load->model('localisation/order_status');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $data['lazada_statuses'] = array(
            'unpaid'        => 'Unpaid',
            'unverified'    => 'Unverified',
            'pending'       => 'Pending',
            'canceled'      => 'Canceled',
            'ready_to_ship' => 'Ready to Ship',
            'delivered'     => 'Delivered',
            'returned'      => 'Returned',
            'shipped'       => 'Shipped',
            'failed'        => 'Failed'
        );

        if(isset($this->request->get['created_before'])){
            $data['created_before'] = $this->request->get['created_before'];
        } else {
            $data['created_before'] = NULL;
        }

        if(isset($this->request->get['created_after'])){
            $data['created_after'] = $this->request->get['created_after'];
        } else {
            $data['created_after'] = NULL;
        }

        if(isset($this->request->get['status'])){
            $data['status'] = $this->request->get['status'];
        } else {
            $data['status'] = NULL;
        }

        if(isset($this->request->get['update_before'])){
            $data['update_before'] = $this->request->get['update_before'];
        } else {
            $data['update_before'] = NULL;
        }

        if(isset($this->request->get['sort_direction'])){
            $data['sort_direction'] = $this->request->get['sort_direction'];
        } else {
            $data['sort_direction'] = NULL;
        }

        if(isset($this->request->get['offset'])){
            $data['offset'] = $this->request->get['offset'];
        } else {
            $data['offset'] = NULL;
        }

        if(isset($this->request->get['limit'])){
            $data['limit'] = $this->request->get['limit'];
        } else {
            $data['limit'] = NULL;
        }

        if(isset($this->request->get['update_after'])){
            $data['update_after'] = $this->request->get['update_after'];
        } else {
            $data['update_after'] = NULL;
        }

        if(isset($this->request->get['sort_by'])){
            $data['sort_by'] = $this->request->get['sort_by'];
        } else {
            $data['sort_by'] = NULL;
        }

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('cedlazada/order_list', $data));
    }

    public function info()
    {
        $this->load->model('sale/order');

        if (isset($this->request->get['order_id'])) {
            $order_id = $this->request->get['order_id'];
        } else {
            $order_id = 0;
        }

        $order_info = $this->model_sale_order->getOrder($order_id);

        if ($order_info) {

            $this->load->language('cedlazada/order');

            $this->document->setTitle($this->language->get('heading_title'));

            $data['heading_title'] = $this->language->get('heading_title');

            $data['text_order_id'] = $this->language->get('text_order_id');
            $data['text_store_name'] = $this->language->get('text_store_name');
            $data['text_store_url'] = $this->language->get('text_store_url');
            $data['text_customer'] = $this->language->get('text_customer');
            $data['text_email'] = $this->language->get('text_email');
            $data['text_telephone'] = $this->language->get('text_telephone');
            $data['text_total'] = $this->language->get('text_total');
            $data['text_order_status'] = $this->language->get('text_order_status');
            $data['text_date_added'] = $this->language->get('text_date_added');
            $data['text_date_modified'] = $this->language->get('text_date_modified');

            $data['text_firstname'] = $this->language->get('text_firstname');
            $data['text_lastname'] = $this->language->get('text_lastname');
            $data['text_address_1'] = $this->language->get('text_address_1');
            $data['text_address_2'] = $this->language->get('text_address_2');
            $data['text_city'] = $this->language->get('text_city');
            $data['text_postcode'] = $this->language->get('text_postcode');
            $data['text_zone'] = $this->language->get('text_zone');
            $data['text_country'] = $this->language->get('text_country');
            $data['text_shipping_method'] = $this->language->get('text_shipping_method');
            $data['text_payment_method'] = $this->language->get('text_payment_method');

            $data['column_product'] = $this->language->get('column_product');
            $data['column_model'] = $this->language->get('column_model');
            $data['column_quantity'] = $this->language->get('column_quantity');
            $data['column_price'] = $this->language->get('column_price');
            $data['column_total'] = $this->language->get('column_total');

            $data['button_back'] = $this->language->get('button_back');

            $data['tab_order'] = $this->language->get('tab_order');
            $data['tab_payment'] = $this->language->get('tab_payment');
            $data['tab_shipping'] = $this->language->get('tab_shipping');
            $data['tab_product'] = $this->language->get('tab_product');
            $data['tab_wshipment'] = $this->language->get('tab_wshipment');
            $data['tab_worder'] = $this->language->get('tab_worder');
            $data['tab_cancel'] = $this->language->get('tab_cancel');

            $data['user_token'] = $this->session->data['user_token'];

            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_ced_lazada'),
                'href' => $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('sale/order', 'user_token=' . $this->session->data['user_token'], 'SSL')
            );

            $data['back'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'], 'SSL');

            $data['order_id'] = $this->request->get['order_id'];

            if ($order_info['invoice_no']) {
                $data['invoice_no'] = $order_info['invoice_prefix'] . $order_info['invoice_no'];
            } else {
                $data['invoice_no'] = '';
            }

            $data['store_name'] = $order_info['store_name'];
            $data['store_url'] = $order_info['store_url'];
            $data['firstname'] = $order_info['firstname'];
            $data['lastname'] = $order_info['lastname'];

            if ($order_info['customer_id']) {
                $data['customer'] = $this->url->link('sale/customer/edit', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $order_info['customer_id'], 'SSL');
            } else {
                $data['customer'] = '';
            }

            $order_prefix = $this->config->get('ced_lazada_order_id_prefix');

            if(!empty($order_prefix))
                $data['order_prefix'] = $order_prefix;
            else
                $data['order_prefix'] = '';

            $data['customer_group'] = '';
            $data['email'] = $order_info['email'];
            $data['telephone'] = $order_info['telephone'];
            
            $data['shipping_method'] = $order_info['shipping_method'];
            $data['payment_method'] = $order_info['payment_method'];
            $data['total'] = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value']);

            $this->load->model('localisation/order_status');

            $order_status_info = $this->model_localisation_order_status->getOrderStatus($order_info['order_status_id']);

            if ($order_status_info) {
                $data['order_status'] = $order_status_info['name'];
            } else {
                $data['order_status'] = '';
            }

            $data['date_added'] = date($this->language->get('date_format_short'), strtotime($order_info['date_added']));
            $data['date_modified'] = date($this->language->get('date_format_short'), strtotime($order_info['date_modified']));
            $data['payment_firstname'] = $order_info['payment_firstname'];
            $data['payment_lastname'] = $order_info['payment_lastname'];
            $data['payment_company'] = $order_info['payment_company'];
            $data['payment_address_1'] = $order_info['payment_address_1'];
            $data['payment_address_2'] = $order_info['payment_address_2'];
            $data['payment_city'] = $order_info['payment_city'];
            $data['payment_postcode'] = $order_info['payment_postcode'];
            $data['payment_zone'] = $order_info['payment_zone'];
            $data['payment_zone_code'] = $order_info['payment_zone_code'];
            $data['payment_country'] = $order_info['payment_country'];
            $data['shipping_firstname'] = $order_info['shipping_firstname'];
            $data['shipping_lastname'] = $order_info['shipping_lastname'];
            $data['shipping_company'] = $order_info['shipping_company'];
            $data['shipping_address_1'] = $order_info['shipping_address_1'];
            $data['shipping_address_2'] = $order_info['shipping_address_2'];
            $data['shipping_city'] = $order_info['shipping_city'];
            $data['shipping_postcode'] = $order_info['shipping_postcode'];
            $data['shipping_zone'] = $order_info['shipping_zone'];
            $data['shipping_zone_code'] = $order_info['shipping_zone_code'];
            $data['shipping_country'] = $order_info['shipping_country'];

            
            $this->load->model('cedlazada/order');
            $data['cancel_reasons'] = $this->model_cedlazada_order->getFailureReason();
            $data['products'] = array();

            $products = $this->model_sale_order->getOrderProducts($this->request->get['order_id']);

            foreach ($products as $product) {
                $option_data = array();

                $options = $this->model_sale_order->getOrderOptions($this->request->get['order_id'], $product['order_product_id']);

                foreach ($options as $option) {
                    if ($option['type'] != 'file') {
                        $option_data[] = array(
                            'name' => $option['name'],
                            'value' => $option['value'],
                            'type' => $option['type']
                        );
                    } else {
                        $option_data[] = array(
                            'name' => $option['name'],
                            'value' => utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.')),
                            'type' => $option['type'],
                            'href' => $this->url->link('sale/order/download', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $this->request->get['order_id'] . '&order_option_id=' . $option['order_option_id'], 'SSL')
                        );
                    }
                }

                $data['products'][] = array(
                    'order_product_id' => $product['order_product_id'],
                    'product_id' => $product['product_id'],
                    'name' => $product['name'],
                    'model' => $product['model'],
                    'option' => $option_data,
                    'quantity' => $product['quantity'],
                    'price' => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
                    'total' => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']),
                    'href' => $this->url->link('catalog/product/edit', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . $product['product_id'], 'SSL')
                );
            }
            $this->load->model('cedlazada/order');
            $data['cedlazada_shipment'] = $this->model_cedlazada_order->getShipmentProviders();

            $data['delivery_type'] = array(
                'dropship' => 'Dropshipping',
                'pickup'   => 'Pickup',
                'send_to_warehouse' => 'Send to Warehouse'
            );

            $lazada_orders = $this->model_cedlazada_order->getOrders();

            if(!empty($lazada_orders)){
                foreach($lazada_orders as $index => $lazada_order)
                {
                    $data['lazada_order_id'] = $lazada_order['lazada_order_id'];
                    $order_data = json_decode($lazada_order['order_data'], true);
                    if(is_array($order_data) && !empty($order_data)){
                        if ($order_data && isset($order_data['order_id'])) {
                            $order_details['order_id'] = $order_data['order_id'];
                        }
                        if ($order_data && isset($order_data['payment_method'])) {
                            $order_details['payment_method'] = $order_data['payment_method'];
                        }
                        if ($order_data && isset($order_data['statuses'])) {
                            $order_details['whole_order_status'] = $order_data['statuses'];
                        }
                        if ($order_data && isset($order_data['shipping_fee'])) {
                            $order_details['shipping_amount'] = $order_data['shipping_fee'];
                        }
                        if ($order_data && isset($order_data['promised_shipping_times'])) {
                            $order_details['whole_order_shipping_day'] = date('d-m-Y H:i:s', strtotime($order_data['promised_shipping_times']));
                        }
                        if ($order_data && isset($order_data['created_at'])) {
                            $order_details['create_time'] = date('d-m-Y H:i:s', strtotime($order_data['created_at']));
                        }
                        $data['shippingInfo'] = array();
                        if ($order_data && isset($order_data['address_billing']['first_name'])) {
                            $data['shippingInfo']['name'] = $order_data['address_billing']['first_name'];
                            if(!empty($order_data['address_billing']['last_name']))
                                $data['shippingInfo']['name'] = $order_data['address_billing']['first_name'] . ' ' . $order_data['address_billing']['last_name'];
                        }
                    }
                    if ($order_data && isset($order_data['address_billing']['phone'])) {
                        $data['shippingInfo']['phone'] = $order_data['address_billing']['phone'];
                        if(!empty($order_data['address_billing']['phone2']))
                            $data['shippingInfo']['phone'] = $order_data['address_billing']['phone'] . ',' . $order_data['address_billing']['phone2'];
                    }

                    if ($order_data && isset($order_data['address_billing']['customer_email'])) {
                        $data['shippingInfo']['email'] = $order_data['address_billing']['customer_email'];
                    }

                    if ($order_data && isset($order_data['address_billing']['address1'])) {
                        $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'];
                        if(!empty($order_data['address_billing']['address2']))
                            $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'] . ' ' . $order_data['address_billing']['address2'];
                        if(!empty($order_data['address_billing']['address3']))
                            $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'] . ' ' . $order_data['address_billing']['address2'] . ' ' . $order_data['address_billing']['address3'];
                        if(!empty($order_data['address_billing']['address4']))
                            $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'] . ' ' . $order_data['address_billing']['address2'] . ' ' . $order_data['address_billing']['address3'] . ' ' . $order_data['address_billing']['address4'];
                        if(!empty($order_data['address_billing']['address5']))
                            $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'] . ' ' . $order_data['address_billing']['address2'] . ' ' . $order_data['address_billing']['address3'] . ' ' . $order_data['address_billing']['address4'] . ' ' . $order_data['address_billing']['address5'];
                    }

                    if ($order_data && isset($order_data['address_billing']['city'])) {
                        $data['shippingInfo']['city'] = $order_data['address_billing']['city'];
                    }
                    
                    if ($order_data && isset($order_data['address_billing']['country'])) {
                        $data['shippingInfo']['country'] = $order_data['address_billing']['country'];
                    }
                    if ($order_data && isset($order_data['address_billing']['post_code'])) {
                        $data['shippingInfo']['zipcode'] = $order_data['address_billing']['post_code'];
                    }
                    // echo '<pre>'; print_r($order_data); die;
                    $order_item_data = json_decode($lazada_order['order_item_data'], true);
                    if(is_array($order_item_data['data']) && !empty($order_item_data['data']))
                    {
                        $lazada_item_order_ids = array();
                        // $trackingNumber = array();
                        $order_details = array();
                        foreach($order_item_data['data'] as $key => $order_item)
                        {
                            $lazada_item_order_ids[$key] = $order_item['order_id'];
                            // $trackingNumber[$key] = $order_item['tracking_code'];
                            $data['tracking_number'] = $order_item['tracking_code'];

                            $order_details['item_order_id'] = $order_item['order_id'];
                            $order_details['tracking_code'] = $order_item['tracking_code'];
                            $order_details['item_order_status'] = $order_item['status'];
                            $order_details['shipping_carrier'] = $order_item['shipment_provider'];
                            $order_details['item_shipping_day'] = date('d-m-Y H:i:s', strtotime($order_item['promised_shipping_time']));
                        }
                    }
                }
            }

            $data['lazada_item_order_ids'] = $lazada_item_order_ids;
            // $data['tracking_numbers'] = $trackingNumber;
            $data['orders'] = $order_details;

            $data['wproducts'] = array();
            if (isset($order_item_data['data']) && !empty($order_item_data['data'])) {
                $data['wproducts'] = $order_item_data['data'];
            }

            $data['vouchers'] = array();
            $vouchers = $this->model_sale_order->getOrderVouchers($this->request->get['order_id']);

            foreach ($vouchers as $voucher) {
                $data['vouchers'][] = array(
                    'description' => $voucher['description'],
                    'amount' => $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']),
                    'href' => $this->url->link('sale/voucher/edit', 'user_token=' . $this->session->data['user_token'] . '&voucher_id=' . $voucher['voucher_id'], 'SSL')
                );
            }

            $totals = $this->model_sale_order->getOrderTotals($this->request->get['order_id']);

            foreach ($totals as $total) {
                $data['totals'][] = array(
                    'title' => $total['title'],
                    'text' => $this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']),
                );
            }
            
            if ($this->hasAction('payment/' . $order_info['payment_code'] . '/orderAction') == true) {
                $data['payment_action'] = $this->getChild('payment/' . $order_info['payment_code'] . '/orderAction');
            } else {
                $data['payment_action'] = '';
            }

            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');

            $this->response->setOutput($this->load->view('cedlazada/order_info', $data));
        } else {
            $this->language->load('error/not_found');

            $this->document->setTitle($this->language->get('heading_title'));

            $data['heading_title'] = $this->language->get('heading_title');

            $data['text_not_found'] = $this->language->get('text_not_found');

            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL'),
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_ced_lazada'),
                'href' => $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('error/not_found', 'user_token=' . $this->session->data['user_token'], 'SSL'),
            );

            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');

            $this->response->setOutput($this->load->view('error/not_found', $data));
        }
    }

    public function fetchOrder()
    {
        $json = array();
        
        if(isset($this->request->post['created_after']) && !empty($this->request->post['created_after'])) {
            $date = (string)$this->request->post['created_after'];
            $this->request->post['created_after'] = $date . 'T09:00:00+08:00';
        }else{
            unset($this->request->post['created_after']);
        }

        if(isset($this->request->post['update_after']) && !empty($this->request->post['update_after'])) {
            $date = (string)$this->request->post['update_after'];
            $this->request->post['update_after'] = $date . 'T09:00:00+08:00';
        }else{
            unset($this->request->post['update_after']);
        }
        
        $postData = $this->request->post;
        
        $this->load->library('cedlazada');
        $cedlazada = Cedlazada::getInstance($this->registry);
        $config = $cedlazada->getAppData();
        $cedlazada->getFailureReason($config);
        $cedlazada->getShipmentProviders($config);

        // $client = new \Lazada\Sdk\Api\Client($config);
        // $request = new \Lazada\Sdk\Api\Request('/orders/get', 'GET');
        // foreach($postData as $key => $value){
        //  $request->addApiParam($key, $value);
        // }
        // $request->addHttpHeaderParam('order','fetchOrder');
        // $response = $client->execute($request, $access_token);
        $order = new \Lazada\Sdk\Api\Order($config);
        $response = $order->getOrders($postData);
        
        if(isset($response['code']) && $response['code'] == '0'){
            $res = $cedlazada->fetchOrder($response, $config);
            
            if(isset($res['success']) && $res['success']){
                $json['success'] = true;
                $json['message'] = 'Order Fetched Successfully!';
                if(!empty($res['message']))
                    $json['message'] = $res['message'];
            } else {
                $json['success'] = false;
                $json['message'] = $res['message'];
            }
        } else {
            $json['success'] = false;
            $json['message'] = $response['message'];
        }

        $this->response->setOutput(json_encode($json));
    }

    public function fail()
    {
        $this->load->language('cedlazada/failorder');
        $this->document->setTitle($this->language->get('heading_title'));
       
        if (isset($this->request->get['filter_lazada_order_id'])) {
            $filter_lazada_order_id = $this->request->get['filter_lazada_order_id'];
        } else {
            $filter_lazada_order_id = null;
        }

        if (isset($this->request->get['filter_lazada_item_order_id'])) {
            $filter_lazada_item_order_id = $this->request->get['filter_lazada_item_order_id'];
        } else {
            $filter_lazada_item_order_id = null;
        }

        if (isset($this->request->get['filter_merchant_sku'])) {
            $filter_merchant_sku = $this->request->get['filter_merchant_sku'];
        } else {
            $filter_merchant_sku = null;
        }

        if (isset($this->request->get['filter_reason'])) {
            $filter_reason = $this->request->get['filter_reason'];
        } else {
            $filter_reason = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'lazada_order_id';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'DESC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['filter_lazada_order_id'])) {
            $url .= '&filter_lazada_order_id=' . $this->request->get['filter_lazada_order_id'];
        }

        if (isset($this->request->get['filter_lazada_item_order_id'])) {
            $url .= '&filter_lazada_item_order_id=' . $this->request->get['filter_lazada_item_order_id'];
        }

        if (isset($this->request->get['filter_merchant_sku'])) {
            $url .= '&filter_merchant_sku=' . urlencode(html_entity_decode($this->request->get['filter_merchant_sku'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_reason'])) {
            $url .= '&filter_reason=' . $this->request->get['filter_reason'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_ced_lazada'),
            'href' => $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('cedlazada/order/rejected', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $order_prefix = $this->config->get('ced_lazada_order_id_prefix');

        if(!empty($order_prefix))
            $data['order_prefix'] = $order_prefix;
        else
            $data['order_prefix'] = '';

        $filter_data = array(
            'filter_lazada_order_id' => $filter_lazada_order_id,
            'filter_lazada_item_order_id' => $filter_lazada_item_order_id,
            'filter_customer' => $filter_merchant_sku,
            'filter_order_status' => $filter_reason,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );
        $this->load->model('cedlazada/order');
        $results = $this->model_cedlazada_order->getRejectedOrders($filter_data);
        $order_total = $this->model_cedlazada_order->getRejectedTotals($filter_data);
        
        if (!empty($results)) {
            foreach ($results as $result) {
                $data['orders'][] = array(
                    'id' => $result['lazada_order_id'],
                    'lazada_item_order_id' => $result['lazada_item_order_id'],
                    'merchantsku' => $result['merchant_sku'],
                    'reason' => $result['reason'],

                    'view' => $this->url->link('cedlazada/order/rejectview', 'user_token=' . $this->session->data['user_token'] . '&id=' . $result['id'] . $url, 'SSL')
                );
            }
        } else {
            $data['orders'] = array();
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_list'] = $this->language->get('text_list');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['column_lazada_order_id'] = $this->language->get('column_lazada_order_id');
        $data['column_lazada_item_order_id'] = $this->language->get('column_lazada_item_order_id');
        $data['column_merchant_sku'] = $this->language->get('column_merchant_sku');
        $data['column_reason'] = $this->language->get('column_reason');
        $data['column_action'] = $this->language->get('column_action');

        $data['entry_lazada_order_id'] = $this->language->get('entry_lazada_order_id');
        $data['entry_lazada_item_order_id'] = $this->language->get('entry_lazada_item_order_id');
        $data['entry_merchant_sku'] = $this->language->get('entry_merchant_sku');
        $data['entry_reason'] = $this->language->get('entry_reason');

        $data['button_edit'] = $this->language->get('viewrejected');
        $data['button_cancel'] = $this->language->get('button_cancel');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->request->post['selected'])) {
            $data['selected'] = (array)$this->request->post['selected'];
        } else {
            $data['selected'] = array();
        }

        $url = '';

        if (isset($this->request->get['filter_lazada_order_id'])) {
            $url .= '&filter_lazada_order_id=' . $this->request->get['filter_lazada_order_id'];
        }

        if (isset($this->request->get['filter_lazada_item_order_id'])) {
            $url .= '&filter_lazada_item_order_id=' . $this->request->get['filter_lazada_item_order_id'];
        }

        if (isset($this->request->get['filter_merchant_sku'])) {
            $url .= '&filter_merchant_sku=' . urlencode(html_entity_decode($this->request->get['filter_merchant_sku'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_reason'])) {
            $url .= '&filter_reason=' . $this->request->get['filter_reason'];
        }

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_lazada_order_id'] = $this->url->link('cedlazada/order/fail', 'user_token=' . $this->session->data['user_token'] . '&sort=lazada_order_id' . $url, 'SSL');
        $data['sort_lazada_item_order_id'] = $this->url->link('cedlazada/order/fail', 'user_token=' . $this->session->data['user_token'] . '&sort=lazada_item_order_id' . $url, 'SSL');
        $data['sort_merchant_sku'] = $this->url->link('cedlazada/order/fail', 'user_token=' . $this->session->data['user_token'] . '&sort=merchant_sku' . $url, 'SSL');
        $data['sort_reason'] = $this->url->link('cedlazada/order/fail', 'user_token=' . $this->session->data['user_token'] . '&sort=reason' . $url, 'SSL');

        $data['cancel'] = $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');

        $pagination = new Pagination();
        $pagination->total = $order_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('cedlazada/order/fail', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));

        $data['filter_lazada_order_id'] = $filter_lazada_order_id;
        $data['filter_lazada_item_order_id'] = $filter_lazada_item_order_id;
        $data['filter_customermerchant_sku'] = $filter_merchant_sku;
        $data['filter_reason'] = $filter_reason;
        $data['user_token'] = $this->session->data['user_token'];

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('cedlazada/rejectedorder', $data));
    }

    public function rejectview()
    {
        $errorlist = '';
        if (isset($this->request->get['id'])) {
            $this->load->language('cedlazada/orderrejectview');
            $this->document->setTitle($this->language->get('heading_title'));

            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_ced_lazada'),
                'href' => $this->url->link('cedlazada/order', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('cedlazada/order/rejectview', 'user_token=' . $this->session->data['user_token'] . '&id=' . $this->request->get['id'], 'SSL')
            );
            if (isset($this->error['warning'])) {
                $data['error_warning'] = $this->error['warning'];
            } else {
                $data['error_warning'] = '';
            }

            $id = 0;

            if (isset($this->request->get['id'])) {
                $id = $this->request->get['id'];
            }

            $this->load->model('cedlazada/order');
            $results = $this->model_cedlazada_order->getRejectedOrder($id);
            // echo '<pre>'; print_r($results); die;
            if (!empty($results)) {
                $order_details = array();

                $order_data = $results['order_data'];
                $item_order_data = $results['item_order_data'];

                if ($order_data && isset($order_data['order_id'])) {
                    $order_prefix = $this->config->get('ced_lazada_order_id_prefix');
                    if(!empty($order_prefix)){
                        $order_details['order_id'] = $order_prefix .''. $order_data['order_id'];
                    } else {
                        $order_details['order_id'] = $order_data['order_id'];
                    }
                    $data['order_id'] = $order_data['order_id'];
                }
                if ($item_order_data && isset($item_order_data['order_id'])) {
                    $order_details['item_order_id'] = $item_order_data['order_id'];
                    $data['item_order_id'] = $item_order_data['order_id'];
                }
                if ($item_order_data && isset($item_order_data['tracking_code'])) {
                    $order_details['tracking_code'] = $item_order_data['tracking_code'];
                }
                if ($order_data && isset($order_data['payment_method'])) {
                    $order_details['payment_method'] = $order_data['payment_method'];
                }
                if ($order_data && isset($order_data['statuses'])) {
                    $order_details['whole_order_status'] = $order_data['statuses'];
                }
                if ($item_order_data && isset($item_order_data['status'])) {
                    $order_details['item_order_status'] = $item_order_data['status'];
                }
                if ($item_order_data && isset($item_order_data['shipment_provider'])) {
                    $order_details['shipping_carrier'] = $item_order_data['shipment_provider'];
                }
                if ($order_data && isset($order_data['shipping_fee'])) {
                    $order_details['shipping_amount'] = $order_data['shipping_fee'];
                }
                if ($order_data && isset($order_data['promised_shipping_times'])) {
                    $order_details['whole_order_shipping_day'] = date('d-m-Y H:i:s', strtotime($order_data['promised_shipping_times']));
                }
                if ($item_order_data && isset($item_order_data['promised_shipping_time'])) {
                    $order_details['item_shipping_day'] = date('d-m-Y H:i:s', strtotime($item_order_data['promised_shipping_time']));
                }
                if ($order_data && isset($order_data['created_at'])) {
                    $order_details['create_time'] = date('d-m-Y H:i:s', strtotime($order_data['created_at']));
                }

                $data['shippingInfo'] = array();
                if ($order_data && isset($order_data['address_billing']['first_name'])) {
                    $data['shippingInfo']['name'] = $order_data['address_billing']['first_name'];
                    if(!empty($order_data['address_billing']['last_name']))
                        $data['shippingInfo']['name'] = $order_data['address_billing']['first_name'] . ' ' . $order_data['address_billing']['last_name'];
                }
                if ($order_data && isset($order_data['address_billing']['phone'])) {
                    $data['shippingInfo']['phone'] = $order_data['address_billing']['phone'];
                    if(!empty($order_data['address_billing']['phone2']))
                        $data['shippingInfo']['phone'] = $order_data['address_billing']['phone'] . ',' . $order_data['address_billing']['phone2'];
                }

                if ($order_data && isset($order_data['address_billing']['customer_email'])) {
                    $data['shippingInfo']['email'] = $order_data['address_billing']['customer_email'];
                }

                if ($order_data && isset($order_data['address_billing']['address1'])) {
                    $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'];
                    if(!empty($order_data['address_billing']['address2']))
                        $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'] . ' ' . $order_data['address_billing']['address2'];
                    if(!empty($order_data['address_billing']['address3']))
                        $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'] . ' ' . $order_data['address_billing']['address2'] . ' ' . $order_data['address_billing']['address3'];
                    if(!empty($order_data['address_billing']['address4']))
                        $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'] . ' ' . $order_data['address_billing']['address2'] . ' ' . $order_data['address_billing']['address3'] . ' ' . $order_data['address_billing']['address4'];
                    if(!empty($order_data['address_billing']['address5']))
                        $data['shippingInfo']['full_address'] = $order_data['address_billing']['address1'] . ' ' . $order_data['address_billing']['address2'] . ' ' . $order_data['address_billing']['address3'] . ' ' . $order_data['address_billing']['address4'] . ' ' . $order_data['address_billing']['address5'];
                }

                if ($order_data && isset($order_data['address_billing']['city'])) {
                    $data['shippingInfo']['city'] = $order_data['address_billing']['city'];
                }
                
                if ($order_data && isset($order_data['address_billing']['country'])) {
                    $data['shippingInfo']['country'] = $order_data['address_billing']['country'];
                }
                if ($order_data && isset($order_data['address_billing']['post_code'])) {
                    $data['shippingInfo']['zipcode'] = $order_data['address_billing']['post_code'];
                }

                $data['products'] = array();
                if ($item_order_data && !empty($item_order_data)) {
                    $data['products'] = $item_order_data;
                }

                $data['orders'] = $order_details;

                $data['failureReasons'] = $this->model_cedlazada_order->getFailureReason();

            } else {
                $errorlist = "Rejected Order Can not be Viewed.";
                $this->response->redirect($this->url->link('cedlazada/order/fail', 'user_token=' . $this->session->data['user_token'] . '&errorlist=' . (string)$errorlist, 'SSL'));
            }

            $data['heading_title'] = $this->language->get('heading_title');

            $data['text_list'] = $this->language->get('text_list');
            $data['text_no_results'] = $this->language->get('text_no_results');
            $data['text_confirm'] = $this->language->get('text_confirm');
            $data['text_missing'] = $this->language->get('text_missing');

            $data['column_order_id'] = $this->language->get('column_order_id');
            $data['column_customer'] = $this->language->get('column_customer');
            $data['column_status'] = $this->language->get('column_status');
            $data['column_total'] = $this->language->get('column_total');
            $data['column_product'] = $this->language->get('column_product');
            $data['column_date_added'] = $this->language->get('column_date_added');
            $data['column_date_modified'] = $this->language->get('column_date_modified');
            $data['column_action'] = $this->language->get('column_action');

            $data['entry_return_id'] = $this->language->get('entry_return_id');
            $data['entry_order_id'] = $this->language->get('entry_order_id');
            $data['entry_customer'] = $this->language->get('entry_customer');
            $data['entry_order_status'] = $this->language->get('entry_order_status');
            $data['entry_total'] = $this->language->get('entry_total');
            $data['entry_date_added'] = $this->language->get('entry_date_added');
            $data['entry_date_modified'] = $this->language->get('entry_date_modified');

            $data['button_invoice_print'] = $this->language->get('button_invoice_print');
            $data['button_shipping_print'] = $this->language->get('button_shipping_print');
            $data['button_insert'] = $this->language->get('button_insert');
            $data['button_edit'] = $this->language->get('viewrejected');
            $data['button_delete'] = $this->language->get('button_delete');
            $data['button_filter'] = $this->language->get('button_filter');
            $data['button_view'] = $this->language->get('button_view');
            $data['Items'] = $this->language->get('Items');
            $data['order_id'] = $this->language->get('order_id');
            $data['customer_reference_order_id'] = $this->language->get('customer_reference_order_id');
            $data['fulfillment_node'] = $this->language->get('fulfillment_node');
            $data['order_placed_date'] = $this->language->get('order_placed_date');
            $data['order_transmission_date'] = $this->language->get('order_transmission_date');
            $data['phone_number'] = $this->language->get('phone_number');
            $data['recipient'] = $this->language->get('recipient');
            $data['recipient_phone_number'] = $this->language->get('recipient_phone_number');
            $data['ship_to_address1'] = $this->language->get('ship_to_address1');
            $data['ship_to_address2'] = $this->language->get('ship_to_address2');
            $data['ship_to_city'] = $this->language->get('ship_to_city');
            $data['ship_to_state'] = $this->language->get('ship_to_state');
            $data['ship_to_zip_code'] = $this->language->get('ship_to_zip_code');
            $data['ship_to_state'] = $this->language->get('ship_to_state');
            $data['rejected_merchant_sku'] = $this->language->get('rejected_merchant_sku');
            $data['button_Back'] = $this->language->get('button_Back');
            $data['button_cancel'] = $this->language->get('button_cancel');
            $data['back'] = $this->url->link('cedlazada/order/fail', 'user_token=' . $this->session->data['user_token'], 'SSL');
            $data['cancel'] = $this->url->link('cedlazada/order/cancel', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $id, 'SSL');
            $data['user_token'] = $this->session->data['user_token'];

            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');

            $this->response->setOutput($this->load->view('cedlazada/rejectedorderview', $data));
        } else {
            $this->error['warning'] = 'No Error Order Id Found.';
            $this->rejected();
        }
    }

    public function cancelOrder()
    {
        $json = array();
        $postData = $this->request->post;
        $this->load->library('cedlazada');
        $cedlazada = Cedlazada::getInstance($this->registry);
        $config = $cedlazada->getAppData();
        
        $params = array(
            'order_item_id' => $postData['item_order_id'],
            'reason_id' => $postData['cancellationReason']
        );

        $order = new \Lazada\Sdk\Api\Order($config);
        $response = $order->cancelOrderItem($params);
        // echo '<pre>'; print_r($response); die;
        if(isset($response['code']) && !empty($response['message'])){
            $json = array('success' => false, 'message' => $response['message']);
        } else {
            $this->model_cedlazada_order->updateOrderStatus($postData['order_id'], 'canceled');
            $json = array('success' => true, 'message' => 'Order Canceled Successfully');
        }
        $this->response->setOutput(json_encode($json));
    }

    public function acceptOrder()
    {
        $json = array();
        $postData = $this->request->post;
        $this->load->library('cedlazada');
        $cedlazada = Cedlazada::getInstance($this->registry);
        $config = $cedlazada->getAppData();

        $params = array(
            'shipping_provider' => $postData['shipping_provider'],
            'delivery_type' => $postData['delivery_type'],
            'order_item_ids' => json_encode($postData['order_item_ids'])
        );

        $order = new \Lazada\Sdk\Api\Order($config);
        $response = $order->packOrderItems($params);
        // echo '<pre>'; print_r($response); die;
        if(isset($response['code']) && !empty($response['message'])){
            $json = array('success' => false, 'message' => $response['message']);
        } else {
            $this->model_cedlazada_order->updateOrderStatus($postData['order_id'], 'ready_to_ship');
            $json = array('success' => true, 'message' => 'Order Accepted Successfully');
        }
        $this->response->setOutput(json_encode($json));
    }

    public function shipOrder()
    {
        $json = array();
        $postData = $this->request->post;
        // echo '<pre>'; print_r($postData); die;
        $this->load->library('cedlazada');
        $cedlazada = Cedlazada::getInstance($this->registry);
        $config = $cedlazada->getAppData();

        $params = array(
            'tracking_number' => $postData['tracking_number'],
            'shipment_provider' => $postData['shipment_provider'],
            'delivery_type' => $postData['delivery_type'],
            'order_item_ids' => json_encode($postData['order_item_ids'])
        );
        // echo '<pre>'; print_r($params); die;

        $order = new \Lazada\Sdk\Api\Order($config);
        $response = $order->readyOrderItems($params);
        // echo '<pre>'; print_r($response); die;
        if(isset($response['code']) && !empty($response['message'])){
            $json = array('success' => false, 'message' => $response['message']);
        } else {
            $this->model_cedlazada_order->updateOrderStatus($postData['order_id'], 'shipped');
            $json = array('success' => true, 'message' => 'Order Accepted Successfully');
        }
        $this->response->setOutput(json_encode($json));
    }
}