<?php
require_once DIR_SYSTEM."library/lazada-sdk/Autoloader.php";

class ControllerCedlazadaBrand extends Controller
{
    // const DIRECTORY_NAME = 'categories';

    private $error = array();

    public function index()
    {
        $this->language->load('cedlazada/brand');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedlazada/brand');

        $this->getList();
    }

    protected function getList()
    {
        if (isset($this->request->get['filter_brand_name'])) {
            $filter_brand_name = $this->request->get['filter_brand_name'];
        } else {
            $filter_brand_name = null;
        }

        if (isset($this->request->get['filter_brand_id'])) {
            $filter_brand_id = $this->request->get['filter_brand_id'];
        } else {
            $filter_brand_id = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'brand_name';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['filter_brand_name'])) {
            $url .= '&filter_brand_name=' . urlencode(html_entity_decode($this->request->get['filter_brand_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_brand_id'])) {
            $url .= '&filter_brand_id=' . urlencode(html_entity_decode($this->request->get['filter_brand_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL'),
            'separator' => false
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('cedlazada/brand', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'),
            'separator' => ' :: '
        );

        $data['fetch'] = $this->url->link('cedlazada/brand/fetch', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
        $data['delete'] = $this->url->link('cedlazada/brand/delete', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');

        $limit = ($this->config->get('config_limit_admin')) ? $this->config->get('config_limit_admin') : '50';
        $filter_data = array(
            'filter_brand_name' => $filter_brand_name,
            'filter_brand_id' => $filter_brand_id,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $limit,
            'limit' => $limit
        );

        $brand_total = $this->model_cedlazada_brand->getTotalBrands($filter_data);

        $results = $this->model_cedlazada_brand->getBrands($filter_data);

        $data['brands'] = array();

        foreach ($results as $result) {

            $action = array();

            $action[] = array(
                'text' => $this->language->get('text_edit'),
                'href' => $this->url->link('cedlazada/brand/update', 'user_token=' . $this->session->data['user_token'] . '&brand_id=' . $result['brand_id'] . $url, 'SSL')
            );

            $data['brands'][] = array(
                'id' => $result['id'],
                'brand_id' => $result['brand_id'],
                'brand_name' => $result['brand_name'],
                'selected' => isset($this->request->post['selected']) && in_array($result['brand_id'], $this->request->post['selected']),
                'action' => $action
            );
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['text_image_manager'] = $this->language->get('text_image_manager');
        $data['text_list'] = $this->language->get('text_list');

        $data['column_brand_id'] = $this->language->get('column_brand_id');
        $data['column_brand_name'] = $this->language->get('column_brand_name');

        $data['entry_brand_id'] = $this->language->get('entry_brand_id');
        $data['entry_brand_name'] = $this->language->get('entry_brand_name');

        $data['column_action'] = $this->language->get('column_action');

        $data['button_add'] = $this->language->get('button_add');
        $data['button_delete'] = $this->language->get('button_delete');
        $data['button_filter'] = $this->language->get('button_filter');

        $data['user_token'] = $this->session->data['user_token'];

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_brand_id'])) {
            $url .= '&filter_brand_id=' . urlencode(html_entity_decode($this->request->get['filter_brand_id'], ENT_QUOTES, 'UTF-8'));
        }

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_brand_name'] = $this->url->link('cedlazada/brand', 'user_token=' . $this->session->data['user_token'] . '&sort=brand_name' . $url, 'SSL');
        $data['sort_brand_id'] = $this->url->link('cedlazada/brand', 'user_token=' . $this->session->data['user_token'] . '&sort=brand_id' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['filter_brand_name'])) {
            $url .= '&filter_brand_name=' . urlencode(html_entity_decode($this->request->get['filter_brand_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_brand_id'])) {
            $url .= '&filter_brand_id=' . urlencode(html_entity_decode($this->request->get['filter_brand_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $brand_total;
        $pagination->page = $page;
        $pagination->limit = $limit;
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('cedlazada/brand', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($brand_total) ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($brand_total - $limit)) ? $brand_total : ((($page - 1) * $limit) + $limit) , $brand_total, ceil($brand_total / $limit));

        $data['filter_brand_name'] = $filter_brand_name;
        $data['filter_brand_id'] = $filter_brand_id;

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('cedlazada/brand_list', $data));
    }

    public function fetchbrand()
    {
        $json = array();
        $offset = 0;
        $limit = 200;
        $this->load->library('cedlazada');
        $cedlazada = cedlazada::getInstance($this->registry);
        $config = $cedlazada->getAppData();

        do{
            $params['offset'] = $offset;
            $params['limit'] = $limit;
            $product = new \Lazada\Sdk\Api\Product($config);
            $response = $product->getBrands($params, true);
            // echo '<pre>'; print_r($response); die;
            if(isset($response) && is_array($response) && !empty($response))
            {
                $offset = $offset + $limit;
                $this->load->model('cedlazada/brand');
                $result = $this->model_cedlazada_brand->addBrands($response);
                $json = array('success' => true, 'message' => 'Brands fetched Successfully!');
            }
        } while(count($response) > 0);

        if(empty($json) && isset($response['message']))
            {
                $json = array('success' => false, 'message' => $response['message']);
            } elseif(empty($json)) {
                $json = array('success' => false, 'message' => 'Can\'t fetch Brands, something went wrong!');
            }

        $this->response->setOutput(json_encode($json));
    }

//    public function fetchbrand()
//    {
//        $json = array();
//        $getData = $this->request->post;
//        $baseDirectory = DIR_SYSTEM . 'var/lazada/categories/';
//        if(!is_dir($baseDirectory)){
//            mkdir($baseDirectory, 777, true);
//        }
//        $path = $baseDirectory . 'categoriesTree_'. $getData['profile_regions'] .'.json';
//        chmod($path, 0777);
//
//        if(file_exists($path) && file_get_contents($path)){
//            $brandTree = file_get_contents($path);
//        } else {
//            $this->load->library('cedlazada');
//            $cedlazada = cedlazada::getInstance($this->registry);
//            $config = $cedlazada->getAppById($getData['profile_app'], $getData['profile_regions']);
//
//            $product = new \Lazada\Sdk\Api\Product($config);
//            $response = $product->getCategories(true);
//
//            $this->load->model('cedlazada/brand');
//            $result = $this->model_cedlazada_brand->generatebrandTree($response, $getData['profile_regions']);
//
//            if (!file_exists($path)) {
//                if(!empty($result))
//                    file_put_contents($path, json_encode($result));
//                if (file_exists($path))
//                    $brandTree = file_get_contents($path);
//            } else {
//                if(!empty($result))
//                    file_put_contents($path, json_encode($result));
//                $brandTree = file_get_contents($path);
//            }
//        }
//
//        if(!empty($brandTree)){
//            $html = $this->preparebrandTree($brandTree);
//            $json = array('success' => true, 'message' => 'Categories fetched Successfully!', 'brandTree' => $html);
//        } else {
//            $json = array('success' => false, 'message' => 'Can\'t fetch Categories!', 'brandTree' => '');
//        }
//
//        $this->response->setOutput(json_encode($json));
//    }

}