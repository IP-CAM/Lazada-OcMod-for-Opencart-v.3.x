<?php
require_once DIR_SYSTEM."library/lazada-sdk/Autoloader.php";

class ControllerCedlazadaCategory extends Controller
{

    const DIRECTORY_NAME = 'categories';

	private $error = array();

    public function index()
    {

        $this->language->load('cedlazada/category');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedlazada/category');

        $this->getList();
    }

    public function delete() {
        $this->language->load('cedlazada/category');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedlazada/category');

        if (isset($this->request->post['selected']) && $this->validateDelete()) {
            foreach ($this->request->post['selected'] as $category_id) {

                $this->model_cedlazada_category->deleteCategory($category_id);
            }

            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('cedlazada/category', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
        }

        $this->getList();
    }

    protected function getList()
    {
        if (isset($this->request->get['filter_category_name'])) {
            $filter_category_name = $this->request->get['filter_category_name'];
        } else {
            $filter_category_name = null;
        }

        if (isset($this->request->get['filter_category_id'])) {
            $filter_category_id = $this->request->get['filter_category_id'];
        } else {
            $filter_category_id = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'category_name';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['filter_category_name'])) {
            $url .= '&filter_category_name=' . urlencode(html_entity_decode($this->request->get['filter_category_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category_id'])) {
            $url .= '&filter_category_id=' . urlencode(html_entity_decode($this->request->get['filter_category_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_ced_lazada'),
            'href' => $this->url->link('cedlazada/category', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('cedlazada/category', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $data['fetch'] = $this->url->link('cedlazada/category/fetch', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
        $data['delete'] = $this->url->link('cedlazada/category/delete', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');

        $filter_data = array(
            'filter_category_name' => $filter_category_name,
            'filter_category_id' => $filter_category_id,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );

        $category_total = $this->model_cedlazada_category->getTotalCategories($filter_data);

        $results = $this->model_cedlazada_category->getCategories($filter_data);

        $data['categories'] = array();

        foreach ($results as $result) {

            $action = array();

            $action[] = array(
                'text' => $this->language->get('text_edit'),
                'href' => $this->url->link('cedlazada/category/update', 'user_token=' . $this->session->data['user_token'] . '&category_id=' . $result['category_id'] . $url, 'SSL')
            );

            $data['categories'][] = array(
                'id' => $result['id'],
                'category_id' => $result['category_id'],
                'category_name' => $result['category_name'],
                'selected' => isset($this->request->post['selected']) && in_array($result['category_id'], $this->request->post['selected']),
                'action' => $action
            );
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_list'] = $this->language->get('text_list');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['text_image_manager'] = $this->language->get('text_image_manager');

        $data['column_category_id'] = $this->language->get('column_category_id');
        $data['column_category_name'] = $this->language->get('column_category_name');

        $data['entry_category_id'] = $this->language->get('entry_category_id');
        $data['entry_category_name'] = $this->language->get('entry_category_name');

        $data['column_action'] = $this->language->get('column_action');

        $data['button_add'] = $this->language->get('button_add');
        $data['button_delete'] = $this->language->get('button_delete');
        $data['button_filter'] = $this->language->get('button_filter');

        $data['user_token'] = $this->session->data['user_token'];

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category_id'])) {
            $url .= '&filter_category_id=' . urlencode(html_entity_decode($this->request->get['filter_category_id'], ENT_QUOTES, 'UTF-8'));
        }

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_category_name'] = $this->url->link('cedlazada/category', 'user_token=' . $this->session->data['user_token'] . '&sort=category_name' . $url, 'SSL');
        $data['sort_category_id'] = $this->url->link('cedlazada/category', 'user_token=' . $this->session->data['user_token'] . '&sort=category_id' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['filter_category_name'])) {
            $url .= '&filter_category_name=' . urlencode(html_entity_decode($this->request->get['filter_category_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category_id'])) {
            $url .= '&filter_category_id=' . urlencode(html_entity_decode($this->request->get['filter_category_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $category_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('cedlazada/category', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($category_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($category_total - $this->config->get('config_limit_admin'))) ? $category_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $category_total, ceil($category_total / $this->config->get('config_limit_admin')));

        $data['filter_category_name'] = $filter_category_name;
        $data['filter_category_id'] = $filter_category_id;

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('cedlazada/category_list', $data));
    }

    protected function validateDelete() {
        if (!$this->user->hasPermission('modify', 'cedlazada/category')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

     public function fetchCategory()
    {
        $json = array();
        $this->load->library('cedlazada');
        $cedlazada = cedlazada::getInstance($this->registry);
        $config = $cedlazada->getAppData();

        $product = new \Lazada\Sdk\Api\Product($config);
        $response = $product->getCategories(true);

        $this->load->model('cedlazada/category');
        $this->model_cedlazada_category->generateCategoryTree($response, $this->config->get('ced_lazada_profile_regions'));

        if(empty($response)){
            $json = array('success' => false, 'message' => 'can\'t fetch Categories! something went wrong!');
        }else{
            $json = array('success' => true, 'message' => 'Categories fetched Successfully!');
        }
        $this->response->setOutput(json_encode($json));
    }

    public function prepareCategoryTree($categoryTree){
        $categoryTree = json_decode($categoryTree, true);
        $html = '';
        $html .= '<td>';
        $html .= '<select name="lazada_category" id="lazada_category" style="height:32px;" class="form-control">';
        $html .= '<option value="">--Select Category--</option>';

        foreach($categoryTree as $key => $value){
            if($value["leaf"] != true){
                $optgroup = $value["optgroup"];
                $html .= '<optgroup label="-'.$value["label"].'">';
                $html .= $this->childCategories($optgroup, $value["label"]);
                $html .= '</optgroup>';
            } else {
                $html .= '<option value="'.$value["value"].'" disabled="disabled">';
                $html .= $key;
                $html .= '</option>';
            }
        }
        $html .= '</select>';
        $html .= '</td>';

        return $html;
    }

    public function childCategories($optgroup,$parentKey){
        $optgroupHtml = '';
        foreach($optgroup as $key => $value){
            if($value["leaf"] != true){
                $optgroup = $value["optgroup"];
                $optgroupHtml .= '<optgroup label="--'.$value["label"].'" style="margin-left: 1em;">';
                $optgroupHtml .= $this->childCategories($optgroup,$value["label"]);
                $optgroupHtml .= '</optgroup>';
            } else {
                $optgroupHtml .= '<option value="'.$value["value"].'">';
                $optgroupHtml .= $parentKey .' -> '. $key;
                $optgroupHtml .= '</option>';
            }
        }
        return $optgroupHtml;
    }
	
}