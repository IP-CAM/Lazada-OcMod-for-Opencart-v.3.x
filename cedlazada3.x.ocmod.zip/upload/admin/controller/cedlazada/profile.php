<?php
class ControllerCedlazadaProfile extends Controller {
	private $error = array();

	public function index() {
		$this->language->load('cedlazada/profile');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('cedlazada/profile');
		$this->getList();
	}

	public function insert() {
		$this->language->load('cedlazada/profile');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('cedlazada/profile');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
		      

			$this->model_cedlazada_profile->addProfile($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function update() {

		$this->language->load('cedlazada/profile');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('cedlazada/profile');
	
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->model_cedlazada_profile->editProfile($this->request->get['id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function delete() {
		$this->language->load('cedlazada/profile');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('cedlazada/profile');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $id) {

				$this->model_cedlazada_profile->deleteProfile($id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'title';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_ced_lazada'),
            'href' => $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
		);

		$data['insert'] = $this->url->link('cedlazada/profile/insert', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
		$data['delete'] = $this->url->link('cedlazada/profile/delete', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');	

		$data['profiles'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$profile_total = $this->model_cedlazada_profile->getTotalProfiles();

		$results = $this->model_cedlazada_profile->getProfiles($filter_data);

		foreach ($results as $result) {
			$action = array();

			$action[] = array(
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('cedlazada/profile/update', 'user_token=' . $this->session->data['user_token'] . '&id=' . $result['id'] . $url, 'SSL')
			);

			$data['profiles'][] = array(
				'id' => $result['id'],
//				'profile_code' => $result['profile_code'],
				'profile_name' => $result['profile_name'],
				'profile_status'     => ($result['profile_status']) ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
				'selected'       => isset($this->request->post['selected']) && in_array($result['id'], $this->request->post['selected']),
				'action'         => $action
			);
		}	

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_no_results'] = $this->language->get('text_no_results');

		$data['column_id'] = $this->language->get('column_id');
		$data['column_code'] = $this->language->get('column_code');
		$data['column_name'] = $this->language->get('column_name');
		$data['column_status'] = $this->language->get('column_status');

		$data['column_action'] = $this->language->get('column_action');
		$data['text_list'] = $this->language->get('text_list');		

		$data['button_insert'] = $this->language->get('button_insert');
		$data['button_delete'] = $this->language->get('button_delete');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_title'] = $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . '&sort=title' . $url, 'SSL');
		$data['sort_id'] = $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . '&sort=id' . $url, 'SSL');
		$data['sort_status'] = $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, 'SSL');

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $profile_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'SSL');

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($profile_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($profile_total - $this->config->get('config_limit_admin'))) ? $profile_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $profile_total, ceil($profile_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('cedlazada/profile_list', $data));
	}

	protected function getForm() {

		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_default'] = $this->language->get('text_default');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_form'] = !isset($this->request->get['id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		$data['entry_enable'] = $this->language->get('entry_enable');
//		$data['entry_profile_code'] = $this->language->get('entry_profile_code');
		$data['entry_profile_name'] = $this->language->get('entry_profile_name');
		$data['entry_profile_app'] = $this->language->get('entry_profile_app');
		$data['entry_profile_regions'] = $this->language->get('entry_profile_regions');
		$data['entry_lazada_category'] = $this->language->get('entry_lazada_category');
		$data['entry_lazada_attributes'] = $this->language->get('entry_lazada_attributes');
		$data['entry_store_attributes'] = $this->language->get('entry_store_attributes');
		$data['entry_default_value'] = $this->language->get('entry_default_value');
		$data['entry_lazada_attributes'] = $this->language->get('entry_lazada_attributes');
		$data['entry_store_category'] = $this->language->get('entry_store_category');

		$data['column_action'] = $this->language->get('column_action');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['tab_general'] = $this->language->get('tab_general');
		$data['tab_profile_mappings'] = $this->language->get('tab_profile_mappings');
		$data['tab_lazada_mappings'] = $this->language->get('tab_lazada_mappings');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_ced_lazada'),
            'href' => $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
		);

		if (!isset($this->request->get['id'])) {
			$data['action'] = $this->url->link('cedlazada/profile/insert', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
			$data['profile_id'] = '0';
		} else {
			$data['profile_id'] = $this->request->get['id'];
			$data['action'] = $this->url->link('cedlazada/profile/update', 'user_token=' . $this->session->data['user_token'] . '&id=' . $this->request->get['id'] . $url, 'SSL');
		}

		$data['cancel'] = $this->url->link('cedlazada/profile', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
		$profile_info = array();
		if (isset($this->request->get['id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$profile_info = $this->model_cedlazada_profile->getProfile($this->request->get['id']);
		}

		$data['user_token'] = $this->session->data['user_token'];


		$this->load->model('setting/store');

		$data['stores'] = $this->model_setting_store->getStores();

		if (isset($this->request->post['profile_status'])) {
			$data['profile_status'] = $this->request->post['profile_status'];
		} elseif (!empty($profile_info['profile_status'])) {
			$data['profile_status'] = $profile_info['profile_status'];
		} else {
			$data['profile_status'] = 1;
		}

//		if (isset($this->request->post['profile_code'])) {
//			$data['profile_code'] = $this->request->post['profile_code'];
//		} elseif (!empty($profile_info['profile_code'])) {
//			$data['profile_code'] = $profile_info['profile_code'];
//		} else {
//			$data['profile_code'] = '';
//		}

		if (isset($this->request->post['profile_name'])) {
			$data['profile_name'] = $this->request->post['profile_name'];
		} elseif (!empty($profile_info['profile_name'])) {
			$data['profile_name'] = $profile_info['profile_name'];
		} else {
			$data['profile_name'] = '';
		}

		$this->load->model('cedlazada/category');

		$data['categories'] = $this->model_cedlazada_category->getCategories();

		if (isset($this->request->post['lazada_category_name'])) {
			$data['lazada_category_name'] = $this->request->post['lazada_category_name'];
		} elseif (!empty($profile_info)) {
			$data['lazada_category_name'] = $profile_info['lazada_category_name'];
		} else {
			$data['lazada_category_name'] = '';
		}

		if (isset($this->request->post['lazada_category'])) {
			$data['lazada_category'] = $this->request->post['lazada_category'];
		} elseif (!empty($profile_info['lazada_category'])) {
			$data['lazada_category'] = $profile_info['lazada_category'];
		} else {
			$data['lazada_category'] = '';
		}

		if(!empty($profile_info['lazada_category_id'])){
			$data['lazada_category_id'] = $profile_info['lazada_category_id'];
		}

		$this->load->model('cedlazada/attribute');

		$data['lazadaAttributes'] = $this->model_cedlazada_attribute->getAttributes();

		$data['limit'] = count($data['lazadaAttributes']);

		if (isset($this->request->post['lazada_attributes'])) {
			$data['lazada_attributes'] = $this->request->post['lazada_attributes'];
		} elseif (!empty($profile_info['lazada_attributes'])) {
			$data['lazada_attributes'] = json_decode($profile_info['lazada_attributes'], true);
		} else {
			$data['lazada_attributes'] = array();
		}

		$this->load->model('catalog/attribute');

		$data['attributes'] = $this->model_catalog_attribute->getAttributes();

		if (isset($this->request->post['store_attributes'])) {
			$data['store_attributes'] = $this->request->post['store_attributes'];
		} elseif (!empty($profile_info['store_attributes'])) {
			$data['store_attributes'] = json_decode($profile_info['store_attributes'], true);
		} else {
			$data['store_attributes'] = array();
		}

		if (isset($this->request->post['default_value'])) {
			$data['default_value'] = $this->request->post['default_value'];
		} elseif (!empty($profile_info['default_value'])) {
			$data['default_value'] = json_decode($profile_info['default_value'], true);
		} else {
			$data['default_value'] = '';
		}

		if (isset($this->request->post['attributes_mapping'])) {
			$data['attributes_mapping'] = $this->request->post['attributes_mapping'];
		} elseif (!empty($profile_info['attributes_mapping'])) {
			$data['attributes_mapping'] = json_decode($profile_info['attributes_mapping'], true);
		} else {
			$data['attributes_mapping'] = array();
		}

		// $this->load->model('catalog/category');

		// $data['storeCategories'] = $this->model_catalog_category->getCategories();

		// if (isset($this->request->post['store_category'])) {
		// 	$data['store_category'] = $this->request->post['store_category'];
		// } elseif (!empty($profile_info['store_category'])) {
		// 	$data['store_category'] = $profile_info['store_category'];
		// } else {
		// 	$data['store_category'] = '';
		// }

		$this->load->model('catalog/category');

		if (isset($this->request->post['product_category'])) {
			$categories = $this->request->post['product_category'];
		} elseif (isset($profile_info['store_category']) && $profile_info['store_category']) {		
			$categories = json_decode($profile_info['store_category'], true);
		} else {
			$categories = array();
		}

		$data['product_categories'] = array();

		if(!empty($categories))
		{
			foreach ($categories as $category_id) {
				$category_info = $this->model_catalog_category->getCategory($category_id);

				if ($category_info) {
					$data['product_categories'][] = array(
						'category_id' => $category_info['category_id'],
						'name'        => ($category_info['path'] ? $category_info['path'] . ' &gt; ' : '') . $category_info['name']
					);
				}
			}
		}

		$data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('cedlazada/profile_form', $data));
	}

	protected function validateForm() {
		return true;
		if (!$this->user->hasPermission('modify', 'cedlazada/profile')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		foreach ($this->request->post['profile_description'] as $language_id => $value) {
			if ((utf8_strlen($value['title']) < 3) || (utf8_strlen($value['title']) > 64)) {
				$this->error['title'][$language_id] = $this->language->get('error_title');
			}

			if (utf8_strlen($value['description']) < 3) {
				$this->error['description'][$language_id] = $this->language->get('error_description');
			}
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'cedlazada/profile')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}

	public function autocomplete()
    {
        $json = array();

        if (isset($this->request->get['filter_name'])) {
            $this->load->model('cedlazada/category');

            if (isset($this->request->get['filter_name'])) {
                $filter_name = $this->request->get['filter_name'];
            } else {
                $filter_name = '';
            }

            if (isset($this->request->get['limit'])) {
                $limit = $this->request->get['limit'];
            } else {
                $limit = 20;
            }

            $data = array(
                'filter_category_name' => $filter_name,
                'start' => 0,
                'limit' => $limit
            );

            $results = $this->model_cedlazada_category->getCategories($data);

            foreach ($results as $category) {
                $json[] = array(
                    'category_id' => $category['category_id'],
                    'name' => strip_tags(html_entity_decode($category['category_name'], ENT_QUOTES, 'UTF-8')),
                );
            }

        }

        $this->response->setOutput(json_encode($json));
    }

//    public function getAttributesByCategory()
//    {
//        $category_id = isset($this->request->get['category_id'])?$this->request->get['category_id']:0;
//        $profile_id = isset($this->request->get['profile_id'])?$this->request->get['profile_id']:0;
//        $html ='No Attribute Found , Please checkCategory.';
//
//        if ($category_id) {
//            ini_set('memory_limit','512M');
//            $this->load->model('cedlazada/category');
//            $this->load->model('cedlazada/profile');
//            $this->load->model('cedlazada/attribute');
//            $attributes_options = $this->model_cedlazada_attribute->getAttributesByCategory($category_id);
//
//            $this->load->model('catalog/attribute');
//            $data['attributes'] = $this->model_catalog_attribute->getAttributes();
//
//            $mapped_attributes_options = array();
//            if($profile_id) {
//                $mapped_attributes_options = $this->model_cedlazada_profile->getMappedAttributes($profile_id);
//            }
//            //echo '<pre>'; print_r($mapped_attributes_options); die;
//            $results = $this->model_catalog_attribute->getAttributes();
//
//            $store_options = $this->model_cedlazada_attribute->getStoreOptions();
//            $options = $store_options['options'];
//            $attributes = $this->model_cedlazada_attribute->getAttributesByCategory($category_id);
//
//            $html ='';
//            $required = array();
//            foreach ($attributes as $attribute) {
//
//                $key = $attribute['attribute_id'];
//                $html .= '<tr>';
//                $html .= '<td class="left">';
//                if (isset($attribute['is_mandatory']) && $attribute['is_mandatory']) {
//                    $required[] = $attribute['attribute_id'];
//                    $html .= '<span class="required">*</span>';
//                    $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][is_mandatory]" value="1"/>';
//                } else {
//                    $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][is_mandatory]" value="0"/>';
//                }
//                $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][attribute_type]" value="' . $attribute['attribute_type'] . '"/>';
//                $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][input_type]" value="' . $attribute['input_type'] . '"/>';
//                $html .= '<select name="attributes_mapping[' . $key . '][lazada_attribute]" class="form-control">';
//
//                $mapped_options = false;
//                $store_selected_option = false;
//                $default_values_selected = false;
//                $default_values_id_selected = false;
//                $lazada_selected_option = false;
//                if (isset($mapped_attributes_options[$attribute['attribute_id']]) && isset($mapped_attributes_options[$attribute['attribute_id']]['option']) && isset($mapped_attributes_options[$attribute['attribute_id']]['option'])) {
//                    $mapped_options = $mapped_attributes_options[$attribute['attribute_id']]['option'];
//
//                    if (is_array($mapped_options) && !empty($mapped_options)) {
//                        $mapped_options = array_filter($mapped_options);
//                        $mapped_options = array_values($mapped_options);
//                    }
//
//                    if (isset($mapped_attributes_options[$attribute['attribute_id']]['store_attribute']) && $mapped_attributes_options[$attribute['attribute_id']]['store_attribute'])
//                        $store_selected_option = $mapped_attributes_options[$attribute['attribute_id']]['store_attribute'];
//
//                    if (isset($mapped_attributes_options[$attribute['attribute_id']]['lazada_attribute']) && !empty($mapped_attributes_options[$attribute['attribute_id']]['lazada_attribute']))
//                        $lazada_selected_option = $mapped_attributes_options[$attribute['attribute_id']]['lazada_attribute'];
//
//                    if (isset($mapped_attributes_options[$attribute['attribute_id']]['default_values']) && !empty($mapped_attributes_options[$attribute['attribute_id']]['default_values']))
//                        $default_values_selected = $mapped_attributes_options[$attribute['attribute_id']]['default_values'];
//
//                    if (isset($mapped_attributes_options[$attribute['attribute_id']]['default_value_id']) && !empty($mapped_attributes_options[$attribute['attribute_id']]['default_value_id']))
//                        $default_values_id_selected = $mapped_attributes_options[$attribute['attribute_id']]['default_value_id'];
//                }
//
//                if ($attribute['is_mandatory'] == 0) {
//                    $html .= '<option value=""></option>';
//                }
//                if(isset($attributes_options) && is_array($attributes_options) && !empty($attributes_options))
//                {
//                    foreach ($attributes_options as $attribute_option) {
//                        if ($lazada_selected_option && ($attribute_option['attribute_id'] == $lazada_selected_option)) {
//                            $html .= '<option selected="selected" value="' . $attribute_option['attribute_id'] . '">';
//                            $html .= $attribute_option['label'];
//                            $html .= '</option>';
//                        }else if ($attribute['is_mandatory'] && ($attribute_option['attribute_id'] == $attribute['attribute_id'])) {
//                            $html .= '<option selected="selected" value="' . $attribute_option['attribute_id'] . '">';
//                            $html .= $attribute_option['label'];
//                            $html .= '</option>';
//                            //break;
//                        } else {
//                            $html .= '<option value="' . $attribute_option['attribute_id'] . '">';
//                            $html .= $attribute_option['label'];
//                            $html .= '</option>';
//                        }
//                    }
//                }
//
//                $html .= '</select>';
//                $html .= '</td>';
////
//                $html .= '<td class="text-left">';
//
//                $attribute['options'] = json_decode($attribute['options'], true);
////                echo '<pre>'; print_r($attribute['options']);
//
////                if(isset($attribute['options']) && is_array($attribute['options']) && !empty($attribute['options']))
////                {
////                    $html .= '<select id="attributes_mapping[' . $key . '][store_attribute]" name="attributes_mapping[' . $key . '][store_attribute]" class="form-control">';
////                    $html .= '<option value="">Select Lazada Options</option>';
////                    foreach($attribute['options'] as $attr_id => $attr_val)
////                    {
////                        if ($store_selected_option && ($attr_id == $store_selected_option)) {
////                            $html .= '<option show_option_mapping="1" selected="selected" value="'. $attr_val['name'] . '">';
////                            $html .= $attr_val['name'];
////                            $html .= '</option>';
////                        } else {
////                            $html .= '<option show_option_mapping="1" value="' . $attr_val['name'] . '">';
////                            $html .= $attr_val['name'];
////                            $html .= '</option>';
////                        }
////                    }
////                    $html .= '</select>';
//               // } else {
//                    $html .= '<select id="attributes_mapping[' . $key . '][store_attribute]" name="attributes_mapping[' . $key . '][store_attribute]" class="form-control">';
//
////                  $html .= '<optgroup label="Store Options">';
////                        foreach ($options as $option) {
////                            if ($store_selected_option && ('option-' . $option['option_id'] == $store_selected_option)) {
////                                $html .= '<option show_option_mapping="1" selected="selected" value="option-' . $option['option_id'] . '">';
////                                $html .= $option['name'];
////                                $html .= '</option>';
////                            } else {
////                                $html .= '<option show_option_mapping="1" value="option-' . $option['option_id'] . '">';
////                                $html .= $option['name'];
////                                $html .= '</option>';
////                            }
////                        }
////                    $html .= '</optgroup>';
//
////                    $html .= '<optgroup label="Store Attributes">';
////                    foreach ($results as $result) {
////                        if ($store_selected_option && ('attribute-' . $result['attribute_id'] == $store_selected_option)) {
////                            $html .= '<option show_option_mapping="0" selected="selected" value="attribute-' . $result['attribute_id'] . '">';
////                            $html .= $result['name'];
////                            $html .= '</option>';
////                        } else {
////                            $html .= '<option show_option_mapping="0" value="attribute-' . $result['attribute_id'] . '">';
////                            $html .= $result['name'];
////                            $html .= '</option>';
////                        }
////                    }
//                    //$html .= '</optgroup>';
//                    if(($attribute['attribute_name'] == 'brand') || ($attribute['attribute_name'] == 'package_content') || ($attribute['attribute_name'] == 'color_family'))
//                    {
//                        $html .= '<option selected="selected" value="default">Default Value</option>';
//                    } else {
//                        $html .= '<option value="">Select Mapping</option>';
//                        $product_fields = array();
//                        try {
//                            $colomns = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product`;");
//                            if ($colomns->num_rows) {
//                                $product_fields = $colomns->rows;
//                            }
//                            $this->array_sort_by_column($product_fields, 'Field');
//                        } catch (Exception $e) {
//                            echo $e->getMessage();
//                            die;
//                        }
//
//                        $html .= '<optgroup label="Product Fields">';
//                        foreach ($product_fields as $result) {
//                            $show_option_mapping = 0;
//                            if (in_array($result['Field'], array('manufacturer_id')))
//                                $show_option_mapping = 1;
//                            if ($store_selected_option && ('product-' . $result['Field'] == $store_selected_option)) {
//                                $html .= '<option show_option_mapping="' . $show_option_mapping . '" selected="selected" value="product-' . $result['Field'] . '">';
//                                $html .= ucfirst(str_replace('_', ' ', $result['Field']));
//                                $html .= '</option>';
//                            } else {
//                                $html .= '<option show_option_mapping="' . $show_option_mapping . '" value="product-' . $result['Field'] . '">';
//                                $html .= ucfirst(str_replace('_', ' ', $result['Field']));
//                                $html .= '</option>';
//                            }
//                        }
//                        if ($store_selected_option && ('product-name' == $store_selected_option)) {
//                            $html .= '<option show_option_mapping="0" value="product-name" selected="selected">Name</option>';
//                        } else {
//                            $html .= '<option show_option_mapping="0" value="product-name">Name</option>';
//                        }
//                        if ($store_selected_option && ('product-meta_description' == $store_selected_option)) {
//                            $html .= '<option show_option_mapping="0" value="product-meta_description" selected="selected">Meta Description</option>';
//                        } else {
//                            $html .= '<option show_option_mapping="0" value="product-meta_description">Meta Description</option>';
//                        }
//                        if ($store_selected_option && ('product-description' == $store_selected_option)) {
//                            $html .= '<option show_option_mapping="0" value="product-description" selected="selected">Description</option>';
//                        } else {
//                            $html .= '<option show_option_mapping="0" value="product-description">Description</option>';
//                        }
//
//                        $html .= '</optgroup>';
//                    }
//
//                    $html .= '</select>';
////                    $option_html = '';
////                    $option_html .= '<a style="margin-left:1%;" class="text-center btn" onclick="toggleOptions('.$key.')"> Map Option(s)</a><div style="display:none;" id="panel_' . (string)$key . '">';
////                    $option_html .= '<table class="table table-bordered table-hover" id="option_mapping_' .$key. '">';
////                    $option_html .= '<thead>';
////                    $option_html .= '<tr>';
////                    $option_html .= '<td class="text-center">';
////                    $option_html .= 'Store Option';
////                    $option_html .= '</td>';
////                    $option_html .= '<td class="text-center">';
////                    $option_html .= 'Lazada Option';
////                    $option_html .= '</td>';
////                    $option_html .= '</tr>';
////                    $option_html .= '<tr>';
////                    $option_html .= '<td>';
////                    $option_html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][option][store_attribute]" onkeyup="getStoreOptions(this)" data-id="' . $key . '"/>';
////                    $option_html .= '<input type="hidden" name="attributes_mapping[' . $key . '][option][store_attribute_id]"/>';
////                    $option_html .= '</td>';
////                    $option_html .= '<td>';
////                    $option_html .= '<input type="text" class="form-control" name="attributes_mapping['.$key.'][option][lazada_attribute]" onkeyup="getOptions(this)" data-id="' . $key . '">';
////                    $option_html .= '</td>';
////                    $option_html .= '<td>';
////                    $option_html .= '<button type="button" class="btn btn-primary" onclick="addAttribute(this,'.$key.');" ><i class="fa fa-plus"></i></button>';
////                    $option_html .= '</td>';
////                    $option_html .= '</tr>';
////                    $option_html .= '</thead>';
////                    if (!empty($mapped_options)) {
////                        foreach ($mapped_options as $key_p => $value) {
////                            $option_html .= '<tr id="attribute-row' . $key . $key_p . '">';
////                            $option_html .= '<td>';
////                            $option_html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][option][' . $key_p . '][store_attribute]" value="' . $value['store_attribute'] . '"/>';
////                            $option_html .= '<input type="hidden" name="attributes_mapping[' . $key . '][option][' . $key_p . '][store_attribute_id]" value="' . $value['store_attribute_id'] . '"/>';
////                            $option_html .= '</td>';
////                            $option_html .= '<td>';
////                            $option_html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][option][' . $key_p . '][lazada_attribute]" value="' . $value['lazada_attribute'] . '">';
////                            $option_html .= '</td>';
////                            $option_html .= '<td>';
////                            $option_html .= '<a onclick="$(\'#attribute-row' . $key . $key_p . '\').remove();" class="btn btn-danger"><i class="fa fa-trash"></i></a>';
////                            $option_html .= '</td>';
////                            $option_html .= '</tr>';
////                        }
////                    }
////                    $option_html .= '</table>';
////                    $option_html .= '</div>';
////                    $html .= $option_html;
//               // }
//                $html .= '</td>';
//
//                $html .= '<td>';
//
//                if($attribute['attribute_name'] == 'brand')
//                {
//                    if (isset($mapped_attributes_options[$key]['default_values']) && !empty($mapped_attributes_options[$key]['default_values'])) {
//                        $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" onkeyup="getBrand(this)" data-id="' . $key . '" value ="' . $default_values_selected . '" >';
//                    } else {
//                        $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" onkeyup="getBrand(this)" data-id="' . $key . '">';
//                    }
//                    $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][default_value_id]" value ="' . $default_values_id_selected . '" >';
//                } else if(($attribute['attribute_name'] == 'color_family') || ($attribute['attribute_name'] == 'package_content')) {
//                    if (isset($mapped_attributes_options[$key]['default_values']) && !empty($mapped_attributes_options[$key]['default_values'])) {
//                        $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" data-id="' . $key . '" value ="' . $default_values_selected . '" >';
//                    } else {
//                        $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" data-id="' . $key . '">';
//                    }
//                } else if(isset($attribute['options']) && is_array($attribute['options']) && !empty($attribute['options']))
//                {
//                    $html .= '<select id="attributes_mapping[' . $key . '][default_values]" name="attributes_mapping[' . $key . '][default_values]" class="form-control">';
//                    $html .= '<option value="">Select Lazada Options</option>';
//                    foreach($attribute['options'] as $attr_id => $attr_val)
//                    {
//                        if ($store_selected_option && ($attr_id == $store_selected_option)) {
//                            $html .= '<option show_option_mapping="1" selected="selected" value="'. $attr_val['name'] . '">';
//                            $html .= $attr_val['name'];
//                            $html .= '</option>';
//                        } else {
//                            $html .= '<option show_option_mapping="1" value="' . $attr_val['name'] . '">';
//                            $html .= $attr_val['name'];
//                            $html .= '</option>';
//                        }
//                    }
//                    $html .= '</select>';
//                } else {
//                    if (isset($mapped_attributes_options[$key]['default_values']) && !empty($mapped_attributes_options[$key]['default_values'])) {
//                        $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" data-id="' . $key . '" value ="' . $default_values_selected . '" >';
//                    } else {
//                        $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" data-id="' . $key . '">';
//                    }
//                }
////
//               $html .= '</td>';
//                $html .= '</tr>';
//
//            }
//            $this->response->setOutput($html);
//        } else {
//            $this->response->setOutput($html);
//        }
//    }

    public function getAttributesByCategory()
    {
        $category_id = isset($this->request->get['category_id'])?$this->request->get['category_id']:0;
        $profile_id = isset($this->request->get['profile_id'])?$this->request->get['profile_id']:0;
        //$html ='No Attribute Found , Please checkCategory.';
        $html ='';

        if ($category_id) {
            ini_set('memory_limit','512M');
            $this->load->model('cedlazada/category');
            $this->load->model('cedlazada/profile');
            $this->load->model('cedlazada/attribute');
            $attributes = $attributes_options = $this->model_cedlazada_attribute->getAttributesByCategory($category_id);

            $mapped_attributes_options = array();
            if($profile_id) {
                $mapped_attributes_options = $this->model_cedlazada_profile->getMappedAttributes($profile_id);
            }

            $store_options = $this->model_cedlazada_attribute->getStoreOptions();
            $options = $store_options['options'];

            $required = array();
            if(isset($attributes) && is_array($attributes) && !empty($attributes))
            {
                foreach ($attributes as $attribute)
                {
                    $key = $attribute['attribute_id'];
                    $html .= '<tr>';
                    $html .= '<td class="text-left">';
                    if (isset($attribute['is_mandatory']) && $attribute['is_mandatory'])
                    {
                        $required[] = $attribute['attribute_id'];
                        $html .= '<span class="required">*</span>';
                        $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][is_mandatory]" value="1"/>';
                    } else {
                        $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][is_mandatory]" value="0"/>';
                    }
                    $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][attribute_type]" value="' . $attribute['attribute_type'] . '"/>';
                    $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][input_type]" value="' . $attribute['input_type'] . '"/>';

                    $html .= '<select name="attributes_mapping[' . $key . '][lazada_attribute]" class="form-control">';

                    $mapped_options = false;
                    $store_selected_option = false;
                    $default_values_selected = false;
                    $default_values_id_selected = false;
                    $lazada_selected_option = false;

                    if (isset($mapped_attributes_options[$attribute['attribute_id']]))
                    {
                        if (isset($mapped_attributes_options[$attribute['attribute_id']]['option']) && isset($mapped_attributes_options[$attribute['attribute_id']]['option']))
                        {
                            $mapped_options = $mapped_attributes_options[$attribute['attribute_id']]['option'];

                            if (is_array($mapped_options) && !empty($mapped_options))
                            {
                                $mapped_options = array_filter($mapped_options);
                                $mapped_options = array_values($mapped_options);
                            }
                        }
                        if (isset($mapped_attributes_options[$attribute['attribute_id']]['store_attribute']) && $mapped_attributes_options[$attribute['attribute_id']]['store_attribute'])
                            $store_selected_option = $mapped_attributes_options[$attribute['attribute_id']]['store_attribute'];

                        if (isset($mapped_attributes_options[$attribute['attribute_id']]['lazada_attribute']) && !empty($mapped_attributes_options[$attribute['attribute_id']]['lazada_attribute']))
                            $lazada_selected_option = $mapped_attributes_options[$attribute['attribute_id']]['lazada_attribute'];

                        if (isset($mapped_attributes_options[$attribute['attribute_id']]['default_values']) && !empty($mapped_attributes_options[$attribute['attribute_id']]['default_values']))
                            $default_values_selected = $mapped_attributes_options[$attribute['attribute_id']]['default_values'];

                        if (isset($mapped_attributes_options[$attribute['attribute_id']]['default_value_id']) && !empty($mapped_attributes_options[$attribute['attribute_id']]['default_value_id']))
                            $default_values_id_selected = $mapped_attributes_options[$attribute['attribute_id']]['default_value_id'];
                    }

                    if ($attribute['is_mandatory'] == 0) {
                        $html .= '<option value=""></option>';
                    }
                    if(isset($attributes_options) && is_array($attributes_options) && !empty($attributes_options))
                    {
                        foreach ($attributes_options as $attribute_option)
                        {
                            if ($lazada_selected_option && ($attribute_option['attribute_id'] == $lazada_selected_option)) {
                                $html .= '<option selected="selected" value="' . $attribute_option['attribute_id'] . '">';
                                $html .= $attribute_option['label'];
                                $html .= '</option>';
                            }else if ($attribute['is_mandatory'] && ($attribute_option['attribute_id'] == $attribute['attribute_id'])) {
                                $html .= '<option selected="selected" value="' . $attribute_option['attribute_id'] . '">';
                                $html .= $attribute_option['label'];
                                $html .= '</option>';
                                //break;
                            } else {
                                $html .= '<option value="' . $attribute_option['attribute_id'] . '">';
                                $html .= $attribute_option['label'];
                                $html .= '</option>';
                            }
                        }
                    }

                    $html .= '</select>';
                    $html .= '</td>';
//
                    $html .= '<td class="text-left">';

                    $html .= '<select id="attributes_mapping[' . $key . '][store_attribute]" name="attributes_mapping[' . $key . '][store_attribute]" class="form-control">';
                    if(($attribute['attribute_name'] == 'brand') || ($attribute['attribute_name'] == 'package_content') || ($attribute['attribute_name'] == 'color_family'))
                    {
                        $html .= '<option selected="selected" value="default">Default Value</option>';
                    } else if($attribute['attribute_name'] == 'size'){
                        $html .= '<option value="">Select Mapping</option>';
                        $html .= '<optgroup label="Store Options">';
                        foreach ($options as $option) {
                            if ($store_selected_option && ('option-' . $option['option_id'] == $store_selected_option)) {
                                $html .= '<option show_option_mapping="1" selected="selected" value="option-' . $option['option_id'] . '">';
                                $html .= $option['name'];
                                $html .= '</option>';
                            } else {
                                $html .= '<option show_option_mapping="1" value="option-' . $option['option_id'] . '">';
                                $html .= $option['name'];
                                $html .= '</option>';
                            }
                        }
                        $html .= '</optgroup>';
                    } else {
                        $html .= '<option value="">Select Mapping</option>';
                        if ($store_selected_option && ('default' == $store_selected_option)) {
                            $html .= '<option selected="selected" value="default">Default Value</option>';
                        } else {
                            $html .= '<option value="default">Default Value</option>';
                        }

                        $product_fields = array();
                        try {
                            $colomns = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product`;");
                            if ($colomns->num_rows) {
                                $product_fields = $colomns->rows;
                            }
                            $this->array_sort_by_column($product_fields, 'Field');
                        } catch (Exception $e) {
                            echo $e->getMessage();
                            die;
                        }

                        $html .= '<optgroup label="Product Fields">';
                        foreach ($product_fields as $result) {
                            $show_option_mapping = 0;
                            if (in_array($result['Field'], array('manufacturer_id')))
                                $show_option_mapping = 1;
                            if ($store_selected_option && ('product-' . $result['Field'] == $store_selected_option)) {
                                $html .= '<option show_option_mapping="' . $show_option_mapping . '" selected="selected" value="product-' . $result['Field'] . '">';
                                $html .= ucfirst(str_replace('_', ' ', $result['Field']));
                                $html .= '</option>';
                            } else {
                                $html .= '<option show_option_mapping="' . $show_option_mapping . '" value="product-' . $result['Field'] . '">';
                                $html .= ucfirst(str_replace('_', ' ', $result['Field']));
                                $html .= '</option>';
                            }
                        }
                        if ($store_selected_option && ('product-name' == $store_selected_option)) {
                            $html .= '<option show_option_mapping="0" value="product-name" selected="selected">Name</option>';
                        } else {
                            $html .= '<option show_option_mapping="0" value="product-name">Name</option>';
                        }
                        if ($store_selected_option && ('product-meta_description' == $store_selected_option)) {
                            $html .= '<option show_option_mapping="0" value="product-meta_description" selected="selected">Meta Description</option>';
                        } else {
                            $html .= '<option show_option_mapping="0" value="product-meta_description">Meta Description</option>';
                        }
                        if ($store_selected_option && ('product-description' == $store_selected_option)) {
                            $html .= '<option show_option_mapping="0" value="product-description" selected="selected">Description</option>';
                        } else {
                            $html .= '<option show_option_mapping="0" value="product-description">Description</option>';
                        }
                        $html .= '</optgroup>';
                    }
                    $html .= '</select>';
                    if($attribute['attribute_name'] == 'size'){
                        $option_html = '';
                        $option_html .= '<a style="margin-left:1%;" class="text-center btn" onclick="toggleOptions('.$key.')"> Map Option(s)</a><div style="display:none;" id="panel'. $key .'">';
                        $option_html .= '<table class="table table-bordered table-hover" id="option_mapping' .$key. '">';
                        $option_html .= '<thead>';
                        $option_html .= '<tr>';
                        $option_html .= '<td class="text-center">';
                        $option_html .= 'Store Option';
                        $option_html .= '</td>';
                        $option_html .= '<td class="text-center">';
                        $option_html .= 'Lazada Option';
                        $option_html .= '</td>';
                        $option_html .= '</tr>';
                        $option_html .= '<tr>';
                        $option_html .= '<td>';
                        $option_html .= '<input type="text" class="form-control" name="attributes_mapping['. $key .'][option][store_attribute]" onkeyup="getStoreOptions(this)" data-id="'. $key .'"/>';
                        $option_html .= '<input type="hidden" name="attributes_mapping[' . $key . '][option][store_attribute_id]"/>';
                        $option_html .= '</td>';
                        $option_html .= '<td>';
                        $option_html .= '<input type="text" class="form-control" name="attributes_mapping['.$key.'][option][lazada_attribute]" onkeyup="getOptions(this)" data-id="'. $key .'">';
                        $option_html .= '</td>';
                        $option_html .= '<td>';
                        $option_html .= '<button type="button" class="btn btn-primary" onclick="addAttribute(this,'.$key.');" ><i class="fa fa-plus"></i></button>';
                        $option_html .= '</td>';
                        $option_html .= '</tr>';
                        $option_html .= '</thead>';
                        $option_html .= '<tbody>';
                        if (!empty($mapped_options)) {
                            foreach ($mapped_options as $key_p => $value) {
                                $option_html .= '<tr id="attribute-row'. $key . $key_p .'">';
                                $option_html .= '<td>';
                                $option_html .= '<input type="text" class="form-control" name="attributes_mapping['. $key .'][option]['. $key_p .'][store_attribute]" value="' . $value['store_attribute'] . '"/>';
                                $option_html .= '<input type="hidden" name="attributes_mapping['. $key .'][option]['. $key_p .'][store_attribute_id]" value="' . $value['store_attribute_id'] . '"/>';
                                $option_html .= '</td>';
                                $option_html .= '<td>';
                                $option_html .= '<input type="text" class="form-control" name="attributes_mapping['. $key .'][option]['. $key_p .'][lazada_attribute]" value="' . $value['lazada_attribute'] . '">';
                                $option_html .= '</td>';
                                $option_html .= '<td>';
                                $option_html .= '<a onclick="$(\'#attribute-row' . $key . $key_p . '\').remove();" class="btn btn-danger"><i class="fa fa-trash"></i></a>';
                                $option_html .= '</td>';
                                $option_html .= '</tr>';
                            }
                        }
                        $option_html .= '</tbody>';
                        $option_html .= '</table>';
                        $option_html .= '</div>';
                        $html .= $option_html;
                    }

                    $html .= '</td>';

                    $html .= '<td class="text-left">';

                    $attribute['options'] = json_decode($attribute['options'], true);

                    if($attribute['attribute_name'] == 'brand')
                    {
                        if (isset($mapped_attributes_options[$key]['default_values']) && !empty($mapped_attributes_options[$key]['default_values'])) {
                            $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" onkeyup="getBrand(this)" data-id="' . $key . '" value ="' . $default_values_selected . '" >';
                        } else {
                            $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" onkeyup="getBrand(this)" data-id="' . $key . '">';
                        }
                        $html .= '<input type="hidden" name="attributes_mapping[' . $key . '][default_value_id]" value ="' . $default_values_id_selected . '" >';
                    } else if(($attribute['attribute_name'] == 'color_family') || ($attribute['attribute_name'] == 'package_content')) {
                        if (isset($mapped_attributes_options[$key]['default_values']) && !empty($mapped_attributes_options[$key]['default_values'])) {
                            $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" data-id="' . $key . '" value ="' . $default_values_selected . '" >';
                        } else {
                            $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" data-id="' . $key . '">';
                        }
                    } else if(isset($attribute['options']) && is_array($attribute['options']) && !empty($attribute['options']))
                    {
                        $html .= '<select id="attributes_mapping[' . $key . '][default_values]" name="attributes_mapping[' . $key . '][default_values]" class="form-control" onchange="checkSelectMapping('. $key.', this.value)">';
                        $html .= '<option value="">Select Lazada Options</option>';
                        foreach($attribute['options'] as $attr_id => $attr_val)
                        {
                            if ($default_values_selected && ($attr_id == $default_values_selected)) {
                                $html .= '<option show_option_mapping="1" selected="selected" value="'. $attr_val['name'] . '">';
                                $html .= $attr_val['name'];
                                $html .= '</option>';
                            } else {
                                $html .= '<option show_option_mapping="1" value="' . $attr_val['name'] . '">';
                                $html .= $attr_val['name'];
                                $html .= '</option>';
                            }
                        }
                        $html .= '</select>';
                    } else {
                        if (isset($mapped_attributes_options[$key]['default_values']) && !empty($mapped_attributes_options[$key]['default_values'])) {
                            $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" data-id="' . $key . '" value ="' . $default_values_selected . '" onkeyup="checkMapping(this)" />';
                        } else {
                            $html .= '<input type="text" class="form-control" name="attributes_mapping[' . $key . '][default_values]" data-id="' . $key . '" value="" onkeyup="checkMapping(this)" />';
                        }
                    }
                    $html .= '</td>';
                    $html .= '</tr>';

                }
            }
            $this->response->setOutput($html);
        } else {
            $html .= '<tr>';
            $html .= '<td>';
            $html .= '</td>';
            $html .= '<td>';
            $html .= '<p style="color: red; font-weight: bold;">No Attributes found for selected category!</p>';
            $html .= '</td>';
            $html .= '<td>';
            $html .= '</td>';
            $html .= '</tr>';
            $this->response->setOutput($html);
        }
    }

    public function array_sort_by_column(&$arr, $col, $dir = SORT_ASC) {
        $sort_col = array();
        foreach ($arr as $key=> $row) {
            $sort_col[$key] = $row[$col];
        }

        array_multisort($sort_col, $dir, $arr);
    }

     public function brandAuto()
    {
        $returnResponse = array();
        $this->load->model('cedlazada/attribute');
        $data = $this->request->get;

        if(isset($data['filter_name']) && !empty($data['filter_name']) && isset($data['fetch_type']) && ($data['fetch_type'] == 'brand'))
        {
            $returnResponse = $this->model_cedlazada_attribute->getBrand($data['filter_name']);
        } else {
            if(isset($data['attribute_id']) && !empty($data['attribute_id']) && isset($data['catId']) && !empty($data['catId']))
            {
                $returnResponse = $this->model_cedlazada_attribute->getBrands($data['catId'], $data['attribute_id'], $data['filter_name']);
            }
        }
        $this->response->setOutput(json_encode($returnResponse));
    }

    public function getStoreOptions()
    {
        $returnResponse = array();
        $this->load->model('cedlazada/profile');
        $data = $this->request->get;
        if (isset($data['filter_name']) && !empty($data['filter_name']) && isset($data['attribute_id']) && !empty($data['attribute_id']) && isset($data['catId']) && !empty($data['catId'])) {
            $attribute_id = $data['attribute_id']; 
            $type_array = explode('-', $attribute_id );
            if (isset($type_array['0']) && ($type_array['0']=='product')){
                $this->load->model('catalog/manufacturer');
                $returnResponse = $this->model_catalog_manufacturer->getManufacturers(array('filter_name' => $data['filter_name']));
            } else if (isset($type_array['0']) && ($type_array['0']=='option')){
                $returnResponse = $this->model_cedlazada_profile->getStoreOptions($data['catId'],$type_array['1'], $data['filter_name']);
            }
            
        }
        $this->response->setOutput(json_encode($returnResponse));
    }
}
