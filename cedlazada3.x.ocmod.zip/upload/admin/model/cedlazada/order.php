<?php
// require_once DIR_SYSTEM."library/lazada-sdk/Autoloader.php";

/**
* CedCommerce
*
* NOTICE OF LICENSE
*
* This source file is subject to the End User License Agreement (EULA)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://cedcommerce.com/license-agreement.txt
*
* @category  modules
* @package   cedlazada
* @author    CedCommerce Core Team 
* @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
* @license   http://cedcommerce.com/license-agreement.txt
*/
class ModelCedlazadaOrder extends Model
{
	protected $error=array();

	public function getOrders($data = array()) {
		$sql = "SELECT wo.lazada_order_id ,wo.status as `wstatus`, wo.order_item_data, wo.order_data, o.order_id, CONCAT(o.firstname, ' ', o.lastname) AS customer, (SELECT os.name FROM " . DB_PREFIX . "order_status os WHERE os.order_status_id = o.order_status_id AND os.language_id = '" . (int)$this->config->get('config_language_id') . "') AS order_status, o.shipping_code, o.total, o.currency_code, o.currency_value, o.date_added, o.date_modified FROM `" . DB_PREFIX . "order` o JOIN `" . DB_PREFIX . "cedlazada_order` wo on (o.order_id = wo.opencart_order_id)";

		if (isset($data['filter_order_status'])) {
			$implode = array();

			$order_statuses = explode(',', $data['filter_order_status']);

			foreach ($order_statuses as $order_status_id) {
				$implode[] = "o.order_status_id = '" . (int)$order_status_id . "'";
			}

			if ($implode) {
				$sql .= " WHERE (" . implode(" OR ", $implode) . ")";
			}
		} else {
			$sql .= " WHERE o.order_status_id > '0'";
		}

		if (!empty($data['filter_order_id'])) {
			$sql .= " AND o.order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		if (!empty($data['filter_customer'])) {
			$sql .= " AND CONCAT(o.firstname, ' ', o.lastname) LIKE '%" . $this->db->escape($data['filter_customer']) . "%'";
		}

		if (!empty($data['filter_date_added'])) {
			$sql .= " AND DATE(o.date_added) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
		}

		if (!empty($data['filter_date_modified'])) {
			$sql .= " AND DATE(o.date_modified) = DATE('" . $this->db->escape($data['filter_date_modified']) . "')";
		}

		if (!empty($data['filter_total'])) {
			$sql .= " AND o.total = '" . (float)$data['filter_total'] . "'";
		}

		$sort_data = array(
			'o.order_id',
			'customer',
			'order_status',
			'o.date_added',
			'o.date_modified',
			'o.total'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY o.order_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}
	public function getTotalOrders($data = array())
	{
		$sql = "SELECT wo.lazada_order_id ,wo.status as `wstatus`, o.order_id, CONCAT(o.firstname, ' ', o.lastname) AS customer, (SELECT os.name FROM " . DB_PREFIX . "order_status os WHERE os.order_status_id = o.order_status_id AND os.language_id = '" . (int)$this->config->get('config_language_id') . "') AS order_status, o.shipping_code, o.total, o.currency_code, o.currency_value, o.date_added, o.date_modified FROM `" . DB_PREFIX . "order` o JOIN `" . DB_PREFIX . "cedlazada_order` wo on (o.order_id = wo.opencart_order_id)";

		if (isset($data['filter_order_status'])) {
			$implode = array();

			$order_statuses = explode(',', $data['filter_order_status']);

			foreach ($order_statuses as $order_status_id) {
				$implode[] = "o.order_status_id = '" . (int)$order_status_id . "'";
			}

			if ($implode) {
				$sql .= " WHERE (" . implode(" OR ", $implode) . ")";
			}
		} else {
			$sql .= " WHERE o.order_status_id > '0'";
		}

		if (!empty($data['filter_order_id'])) {
			$sql .= " AND o.order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		if (!empty($data['filter_customer'])) {
			$sql .= " AND CONCAT(o.firstname, ' ', o.lastname) LIKE '%" . $this->db->escape($data['filter_customer']) . "%'";
		}

		if (!empty($data['filter_date_added'])) {
			$sql .= " AND DATE(o.date_added) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
		}

		if (!empty($data['filter_date_modified'])) {
			$sql .= " AND DATE(o.date_modified) = DATE('" . $this->db->escape($data['filter_date_modified']) . "')";
		}

		if (!empty($data['filter_total'])) {
			$sql .= " AND o.total = '" . (float)$data['filter_total'] . "'";
		}

		$sort_data = array(
			'o.order_id',
			'customer',
			'order_status',
			'o.date_added',
			'o.date_modified',
			'o.total'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY o.order_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		$query = $this->db->query($sql);

		return $query->num_rows;
	}

	public function getRejectedOrders($data = array())
  	{
    	$sql = "SELECT * FROM `".DB_PREFIX."cedlazada_order_error` WHERE lazada_order_id > 0";

    	if (!empty($data['filter_lazada_order_id'])) {
			$sql .= " AND lazada_order_id = '" . (int)$data['filter_lazada_order_id'] . "'";
		}

		if (!empty($data['filter_lazada_item_order_id'])) {
			$sql .= " AND lazada_item_order_id = '" . (int)$data['filter_lazada_item_order_id'] . "'";
		}

		if (!empty($data['filter_customermerchant_sku'])) {
			$sql .= " AND merchant_sku = '" . (int)$data['filter_customermerchant_sku'] . "'";
		}

		if (!empty($data['filter_reason'])) {
			$sql .= " AND reason = '" . (int)$data['filter_reason'] . "'";
		}

		$sort_data = array(
			'lazada_order_id',
			'lazada_item_order_id',
			'merchant_sku',
			'reason'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY lazada_order_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

    	$query=$this->db->query($sql);

	    return $query->rows;
  	}
  	public function getRejectedTotals($data = array())
  	{
    	$sql = "SELECT * FROM `".DB_PREFIX."cedlazada_order_error` WHERE lazada_order_id > 0";

    	if (!empty($data['filter_lazada_order_id'])) {
			$sql .= " AND lazada_order_id = '" . (int)$data['filter_lazada_order_id'] . "'";
		}

		if (!empty($data['filter_lazada_item_order_id'])) {
			$sql .= " AND lazada_item_order_id = '" . (int)$data['filter_lazada_item_order_id'] . "'";
		}

		if (!empty($data['filter_customermerchant_sku'])) {
			$sql .= " AND merchant_sku = '" . (int)$data['filter_customermerchant_sku'] . "'";
		}

		if (!empty($data['filter_reason'])) {
			$sql .= " AND reason = '" . (int)$data['filter_reason'] . "'";
		}

		$sort_data = array(
			'lazada_order_id',
			'lazada_item_order_id',
			'merchant_sku',
			'reason'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY lazada_order_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

    	$query = $this->db->query($sql);

    	return count($query->rows);
  	}
  	public function getRejectedOrder($id)
  	{
  		$response = array();
    	$sql="SELECT `order_data`, `item_order_data` FROM `".DB_PREFIX."cedlazada_order_error` WHERE `id` = '".$id."'";
    	$query=$this->db->query($sql);
    	if ($query && $query->num_rows) {
    		$response = array(
    			'order_data' => json_decode($query->row['order_data'], true),
    			'item_order_data' => json_decode($query->row['item_order_data'], true)
    			);
    		return $response;
    	} else {
    		return array();
    	}
  	}

  	public function getFailureReason()
    {
      $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_failure_reason` ");
      if($sql->num_rows){
        return $sql->rows;
      } else {
      	return array();
      }
    }

    public function getShipmentProviders()
    {
      $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_shipment_provider` ");
      if($sql->num_rows){
        return $sql->rows;
      } else {
      	return array();
      }
    }

    public function updateOrderStatus($orderId, $status = 'processing')
    {
    	$this->db->query("UPDATE `". DB_PREFIX ."cedlazada_order` SET status = '". $status ."' WHERE lazada_order_id = '". $orderId ."' ");
    }
}