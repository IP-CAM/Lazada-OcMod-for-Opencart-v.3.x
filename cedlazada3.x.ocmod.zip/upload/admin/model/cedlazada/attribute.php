<?php

require_once DIR_SYSTEM."library/lazada-sdk/Autoloader.php";

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedlazada
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
class ModelCedlazadaAttribute extends Model {

    public function getAttributes($data = array()){
        $sql = "SELECT * FROM " . DB_PREFIX . "cedlazada_attribute WHERE attribute_id >= '0'";

        if (!empty($data['filter_attribute_name'])) {
            $sql .= " AND label LIKE '" . $this->db->escape($data['filter_attribute_name']) . "%'";
        }

        if (!empty($data['filter_attribute_id'])) {
            $sql .= " AND attribute_id = '" . $this->db->escape($data['filter_attribute_id']) . "'";
        }

        $sort_data = array(
            'label',
            'attribute_id'
        );

        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY attribute_id";
        }

        if (isset($data['order']) && ($data['order'] == 'DESC')) {
            $sql .= " DESC";
        } else {
            $sql .= " ASC";
        }

        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }

            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }

            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }

        $query = $this->db->query($sql);

        return $query->rows;
    }

    public function getTotalAttributes($data = array())
    {
        $sql = "SELECT count(attribute_id) AS total FROM " . DB_PREFIX . "cedlazada_attribute WHERE attribute_id > '0' ";

        if (!empty($data['filter_attribute_name'])) {
            $sql .= " AND label LIKE '" . $this->db->escape($data['filter_attribute_name']) . "%'";
        }

        if (!empty($data['filter_attribute_id'])) {
            $sql .= " AND attribute_id = '" . $this->db->escape($data['filter_attribute_id']) . "'";
        }

        $query = $this->db->query($sql);

        return $query->row['total'];
    }

    public function getAttributesByCategory($category_id)
    {
        $sql = $this->db->query("SELECT * FROM `". DB_PREFIX."cedlazada_attribute` WHERE category_id = '". $category_id."' ");

        if($sql->num_rows)
        {
            return $sql->rows;
        } else {
            $this->load->library('cedlazada');
            $cedlazada = cedlazada::getInstance($this->registry);
            $config = $cedlazada->getAppData();

            $product = new \Lazada\Sdk\Api\Product($config);
            $response = $product->getCategoriesAttributes($category_id, true);

            if(isset($response) && is_array($response) && !empty($response))
            {
                $this->addAttributes($response, $this->config->get('ced_lazada_profile_regions'), $category_id);
                $sql = $this->db->query("SELECT * FROM `". DB_PREFIX."cedlazada_attribute` WHERE category_id = '". $category_id."' ");
                return $sql->num_rows;
            }

            return $response;
        }
    }

    public function deleteAttribute($attribute_id){
        $this->db->query("DELETE FROM `". DB_PREFIX ."cedlazada_attribute` WHERE `attribute_id` = '". $attribute_id ."' ");
    }

    public function getBrand($brand_name)
    {
        $sql = $this->db->query("SELECT `brand_name` FROM `". DB_PREFIX ."cedlazada_brands` WHERE `brand_name` LIKE '" . $this->db->escape(trim($brand_name)) . "%' ");
        if($sql->num_rows)
        {
            return $sql->rows;
        } else {
            return array();
        }
    }

    public function getBrands($catId, $attribute_id, $brandName)
    {
        $brandArray = array();
        $results = $this->db->query("SELECT * FROM `".DB_PREFIX."cedlazada_attribute` WHERE category_id='".$catId."' AND attribute_id='".$attribute_id."'");

        foreach ($results->rows as $res) {
            $brandArray = json_decode($res['options'],true);
            foreach($brandArray as $key => &$option){
//                $option['value'] = $option['name'];
                $brandArray = array_merge_recursive($brandArray, $option);
            }
        }
        $input = preg_quote($brandName, '~');
        $result = preg_grep('~' . $input . '~', $brandArray);

        if(empty($result))
            return $brandArray;

        return $result;
    }

    public function getStoreOptions()
    {
        $sql = "SELECT * FROM `" . DB_PREFIX . "option` o LEFT JOIN " . DB_PREFIX . "option_description od ON (o.option_id = od.option_id) WHERE od.language_id = '" . (int)$this->config->get('config_language_id') . "' AND `type` IN ('checkbox','select','radio') ORDER BY od.name";
        $result = $this->db->query($sql);
        $options = $result->rows;
        $option_value_data = array();
        if (!empty($options)) {
            foreach ($options as $option) {
                $option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value ov LEFT JOIN " . DB_PREFIX . "option_value_description ovd ON (ov.option_value_id = ovd.option_value_id) WHERE ov.option_id = '" . (int)$option['option_id'] . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY ov.sort_order ASC");
                foreach ($option_value_query->rows as $option_value) {
                    $option_value_data[$option['option_id']][] = array(
                        'option_value_id' => $option_value['option_value_id'],
                        'name' => $option_value['name'],
                    );
                }
            }
            return array('options' => $options, 'option_values' => $option_value_data);
        }
        return array('options' => $options, 'option_values' => $option_value_data);
    }

    public function addAttributes($data = array(), $regionId = NULL, $catId = NULL){
        $this->db->query("DELETE FROM `". DB_PREFIX ."cedlazada_attribute` WHERE category_id = '". (int)$catId ."' AND region_id = '". $this->db->escape($regionId) ."' ");

        foreach($data as $key => $value){
            $this->db->query("INSERT INTO `". DB_PREFIX ."cedlazada_attribute` (`attribute_name`, `label`, `is_mandatory`, `is_sale_prop`, `attribute_type`, `input_type`, `options`, `category_id`, `region_id`) VALUES('". $this->db->escape($value['name']) ."', '". $this->db->escape($value['label']) ."', '". (int)$value['is_mandatory'] ."', '". (int)$value['is_sale_prop'] ."', '". $this->db->escape($value['attribute_type']) ."', '". $this->db->escape($value['input_type']) ."', '". $this->db->escape(json_encode($value['options'])) ."', '". (int)$catId ."', '". $this->db->escape($regionId) ."') ");
        }
    }
}