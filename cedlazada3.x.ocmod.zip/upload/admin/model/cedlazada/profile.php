<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedlazada
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
class ModelCedlazadaProfile extends Model {

	public function addProfile($data) {

	    if(isset($data['attributes_mapping']) && $data['attributes_mapping'])
        {
            $data['attributes_mapping'] = $data['attributes_mapping'];
        } else {
            $data['attributes_mapping'] = array();
        }
		$this->db->query("INSERT INTO " . DB_PREFIX . "cedlazada_profile SET 
            profile_status = '" . (int)$data['profile_status'] . "',
            profile_name = '" . $this->db->escape($data['profile_name']) . "',
            store_category = '" . $this->db->escape(json_encode($data['store_category'])) . "',
            lazada_category_id = '". (int) $data['lazada_category_id'] ."',
            lazada_category_name = '" . $this->db->escape($data['lazada_category']) . "',
            attributes_mapping = '". $this->db->escape(json_encode($data['attributes_mapping'])) ."'
		");
	    // profile_code = '" . $this->db->escape($data['profile_code']) . "',
		$profile_id = $this->db->getLastId();
		if($profile_id){
			$this->removeProductFromProfile($profile_id);
			$this->addProductInProfile($profile_id, $data['store_category']);	
		}
	}

	public function editProfile($profile_id, $data) {

        if(isset($data['store_category']) && $data['store_category'])
        {
            $data['store_category'] = $data['store_category'];
        } else {
            $data['store_category'] = array();
        }

        if(isset($data['attributes_mapping']) && $data['attributes_mapping'])
        {
            $data['attributes_mapping'] = $data['attributes_mapping'];
        } else {
            $data['attributes_mapping'] = array();
        }
		$this->db->query("UPDATE " . DB_PREFIX . "cedlazada_profile SET 
            profile_status = '" . (int)$data['profile_status'] . "',
            profile_name = '" . $this->db->escape($data['profile_name']) . "',  
            store_category = '" . $this->db->escape(json_encode($data['store_category'])) . "',
            lazada_category_id = '". (int) $data['lazada_category_id'] ."',
            lazada_category_name = '" . $this->db->escape($data['lazada_category']) . "',
            attributes_mapping = '". $this->db->escape(json_encode($data['attributes_mapping'])) ."' 
            WHERE id = '". (int) $profile_id ."'
		");

//		$this->removeProductFromProfile($profile_id);
		$this->updateProductInProfile($profile_id, $data['store_category']);
	}

	public function removeProductFromProfile($profile_id)
	{
		$this->db->query("DELETE FROM `".DB_PREFIX."cedlazada_profile_products` WHERE `lazada_profile_id` = '".$profile_id."' ");
	}

	public function addProductInProfile($profile_id, $categories)
	{
		$sql = "SELECT DISTINCT (p.product_id) FROM `".DB_PREFIX."product` p LEFT JOIN `".DB_PREFIX."product_to_category` ptc on (ptc.product_id = p.product_id) WHERE p.quantity > 0 ";

		if(!empty($categories)){
			$sql .= "AND ptc.category_id IN(".implode(',', $categories).") ";
		}

		$result = $this->db->query( $sql);

		if($result && $result->num_rows) {
			
			$products =  array_chunk( $result->rows, 1000);
			foreach ($products as $key => $value) {
				$sql = "INSERT INTO `".DB_PREFIX."cedlazada_profile_products` (`product_id`,`lazada_profile_id`) values ";
				foreach ( $result->rows as $key => $product) {
					$sql .= "('".$product['product_id']."','".$profile_id."'), ";
				}
				$sql = rtrim($sql, ', ');
				$this->db->query($sql);		
			}	
		}
	}

    public function updateProductInProfile($profile_id, $categories)
    {
        $sql = "SELECT DISTINCT (p.product_id) FROM `".DB_PREFIX."product` p LEFT JOIN `".DB_PREFIX."product_to_category` ptc on (ptc.product_id = p.product_id) WHERE p.quantity >0 ";

        if(!empty($categories)){
            $sql .= "AND ptc.category_id IN(".implode(',', $categories).") ";
        }

        $result = $this->db->query($sql);

        if($result && $result->num_rows)
        {
            $products =  array_chunk( $result->rows, 1000);
            foreach ($products as $key => $value) {
                foreach ($result->rows as $key => $product)
                {
                    $sql = $this->db->query("SELECT * FROM `".DB_PREFIX."cedlazada_profile_products` WHERE `product_id` = '". $product['product_id'] ."' ");
                    if($sql->num_rows == 0)
                    {
                        $this->db->query("INSERT INTO `".DB_PREFIX."cedlazada_profile_products` SET `product_id` = '". $product['product_id'] ."' ,`lazada_profile_id` = '". $profile_id ."' ");
                    }
                }
            }
        }
    }

	public function deleteProfile($profile_id) {
        $this->db->query("DELETE FROM " . DB_PREFIX . "cedlazada_profile WHERE id = '" . (int)$profile_id . "'");

        $query = $this->db->query("SELECT product_id FROM " . DB_PREFIX . "cedlazada_profile_products WHERE lazada_profile_id = '" . (int)$profile_id . "' ");
        $result = $query->rows;

        if($result){
            foreach($result as $product_array){
                $this->db->query("DELETE FROM " . DB_PREFIX . "cedlazada_profile_products WHERE product_id = '" . (int)$product_array['product_id'] . "' AND lazada_profile_id = '" . (int)$profile_id . "'");
            }

        }

        $sql = $this->db->query("SELECT product_id FROM " . DB_PREFIX . "cedlazada_product_attribute_combination WHERE lazada_profile_id = '" . (int)$profile_id . "' ");
        $res = $query->rows;

        if($res){
            foreach($res as $productArray){
                $this->db->query("DELETE FROM " . DB_PREFIX . "cedlazada_product_attribute_combination WHERE product_id = '" . (int)$productArray['product_id'] . "' AND lazada_profile_id = '" . (int)$profile_id . "'");
            }

        }

        $this->cache->delete('profile');
    }

	public function getProfile($profile_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedlazada_profile WHERE id = '" . (int)$profile_id . "'");

		return $query->row;
	}

	public function getProfiles($data = array()) {

			$sql = "SELECT * FROM " . DB_PREFIX . "cedlazada_profile WHERE id >= '0'";

			$sort_data = array(
				'profile_status',
				'profile_code',
				'profile_name',
				'id'
			);		

			if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
				$sql .= " ORDER BY " . $data['sort'];	
			} else {
				$sql .= " ORDER BY id";	
			}

			if (isset($data['order']) && ($data['order'] == 'DESC')) {
				$sql .= " DESC";
			} else {
				$sql .= " ASC";
			}

			if (isset($data['start']) || isset($data['limit'])) {
				if ($data['start'] < 0) {
					$data['start'] = 0;
				}		

				if ($data['limit'] < 1) {
					$data['limit'] = 20;
				}	

				$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
			}	

			$query = $this->db->query($sql);

			return $query->rows;
	}

	public function getTotalProfiles() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "cedlazada_profile");

		return $query->row['total'];
	}

	public function getMappedAttributes($profile_id) {
		$query = $this->db->query("SELECT `attributes_mapping` FROM " . DB_PREFIX . "cedlazada_profile WHERE `id` = '" . (int)$profile_id . "'");
		if($query->num_rows){
			return json_decode($query->row['attributes_mapping'], true);
		}
	}

	public function getStoreOptions($catId, $attribute_id, $brandName)
    {
        $option_value_data = array();
       	$option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value ov LEFT JOIN " . DB_PREFIX . "option_value_description ovd ON (ov.option_value_id = ovd.option_value_id) WHERE ov.option_id = '" . (int)$attribute_id . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND ovd.name LIKE '%".$brandName."%' ORDER BY ov.sort_order ASC");
				
		foreach ($option_value_query->rows as $option_value) {
			$option_value_data[] = array(
				'option_value_id' => $option_value['option_value_id'],
				'name'            => $option_value['name'],
				'image'           => $option_value['image'],
				'sort_order'      => $option_value['sort_order']
			);
		}
		return $option_value_data;
    }
}