<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @brand  modules
 * @package   cedshopee
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
class ModelCedlazadaBrand extends Model {

    public function getBrands($data = array()) {

        $sql = "SELECT * FROM " . DB_PREFIX . "cedlazada_brands WHERE brand_id >0 ";

        if (!empty($data['filter_brand_name'])) {
            $sql .= " AND brand_name LIKE '%" .  strip_tags(html_entity_decode($this->db->escape($data['filter_brand_name']))) . "%'";
        }

        if (!empty($data['filter_brand_id'])) {
            $sql .= " AND brand_id = '" . $this->db->escape($data['filter_brand_id']) . "'";
        }

        $sql .= " GROUP BY brand_id";

        $sort_data = array(
            'brand_name',
            'brand_id'
        );

        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY brand_name";
        }

        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }

            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }

            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }

        //echo '<pre>'; print_r($sql); die;
        $query = $this->db->query($sql);
        //echo '<pre>'; print_r($query); die;
        return $query->rows;
    }

    public function getTotalBrands($data = array())
    {
        $sql = "SELECT DISTINCT count(brand_id) AS total FROM " . DB_PREFIX . "cedlazada_brands WHERE brand_id > '0' ";

        if (!empty($data['filter_brand_name'])) {
            $sql .= " AND brand_name LIKE '" . $this->db->escape($data['filter_brand_name']) . "%'";
        }

        if (!empty($data['filter_brand_id'])) {
            $sql .= " AND brand_id = '" . $this->db->escape($data['filter_brand_id']) . "'";
        }

        $query = $this->db->query($sql);

        return $query->row['total'];
    }

    public function deletebrand($brand_id) {

        $this->db->query("DELETE FROM `".DB_PREFIX."cedlazada_brands` WHERE `id`='". (int)$brand_id ."'");
    }

    public function addBrands($data = array())
    {
        foreach($data as $key => $value)
        {
            $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedlazada_brands` WHERE `brand_id` = '" . $value['brand_id'] . "' ");

            if ($sql->num_rows == '0') {
                $this->db->query("INSERT INTO `". DB_PREFIX ."cedlazada_brands` SET 
                `brand_id` = '" . (int) $value['brand_id'] . "',
                `brand_name` = '" . $this->db->escape($value['name']) . "',
                `global_identifier` = '" . $this->db->escape($value['global_identifier']) . "',
                `name_en` = '" . $this->db->escape($value['name_en']) . "'
                ");
            }
        }
    }

}