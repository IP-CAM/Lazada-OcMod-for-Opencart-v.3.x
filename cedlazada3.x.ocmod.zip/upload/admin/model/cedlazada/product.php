<?php
// require_once DIR_SYSTEM."library/lazada-sdk/Autoloader.php";
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedlazada
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

class ModelCedlazadaProduct extends Model {

    public function getProducts($data = array()) {

        $sql = "SELECT pd.name,cpp.error_message,cp.profile_name,cup.lazada_status,p.* FROM `" . DB_PREFIX . "product` p LEFT JOIN `" . DB_PREFIX . "product_description` pd ON (p.product_id = pd.product_id) JOIN `" . DB_PREFIX . "cedlazada_profile_products` cpp ON (p.product_id = cpp.product_id) LEFT JOIN `".DB_PREFIX."cedlazada_profile` cp ON (cp.id = cpp.lazada_profile_id) LEFT JOIN `".DB_PREFIX."cedlazada_uploaded_products` cup ON (cup.product_id = cpp.product_id)";

        $sql .= " WHERE pd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

        if (!empty($data['filter_name'])) {
            $sql .= " AND pd.name LIKE '%" . $this->db->escape(trim($data['filter_name'])) . "%'";
        }

        if (!empty($data['filter_profile_name'])){
            $sql .= "AND cp.profile_name LIKE '%" . $this->db->escape(trim($data['filter_profile_name'])) . "%'";
        }

        if (!empty($data['filter_model'])) {
            $sql .= " AND p.model LIKE '%" . $this->db->escape(trim($data['filter_model'])) . "%'";
        }

        if (isset($data['filter_price']) && !is_null($data['filter_price'])) {
            $sql .= " AND p.price LIKE '" . $this->db->escape($data['filter_price']) . "%'";
        }

        if (isset($data['filter_quantity']) && !is_null($data['filter_quantity'])) {
            $sql .= " AND p.quantity = '" . (int)$data['filter_quantity'] . "'";
        }

        if (isset($data['filter_status'])) {
            $sql .= " AND p.status = '" . (int)$data['filter_status'] . "'";
        }

        if (isset($data['filter_lazada_status']) && !is_null($data['filter_lazada_status'])) {
            $sql .= " AND cup.lazada_status = '" . $data['filter_lazada_status'] . "'";
        }

        $sql .= " GROUP BY p.product_id";

        $sort_data = array(
            'pd.name',
            'p.model',
            'p.price',
            'p.quantity',
            'p.status',
            'p.sort_order',
            'cup.lazada_status',
            'cpp.error_message'
        );

        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY pd.name";
        }
        if (isset($data['order']) && ($data['order'] == 'DESC')) {
            $sql .= " DESC";
        } else {
            $sql .= " ASC";
        }

        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }

            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }
            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }

        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function getTotalProducts($data = array()) {

          $sql = "SELECT count(DISTINCT p.product_id) AS total FROM `" . DB_PREFIX . "product` p LEFT JOIN `" . DB_PREFIX . "product_description` pd ON (p.product_id = pd.product_id) JOIN `" . DB_PREFIX . "cedlazada_profile_products` cpp ON (p.product_id = cpp.product_id) LEFT JOIN `".DB_PREFIX."cedlazada_profile` cp ON (cp.id = cpp.lazada_profile_id) LEFT JOIN `".DB_PREFIX."cedlazada_uploaded_products` cup ON (cup.product_id = cpp.product_id)";

          $sql .= " WHERE pd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

        if (!empty($data['filter_name'])) {
            $sql .= " AND pd.name LIKE '%" . $this->db->escape(trim($data['filter_name'])) . "%'";
        }

        if (!empty($data['filter_profile_name'])){
            $sql .= "AND cp.profile_name LIKE '%" . $this->db->escape(trim($data['filter_profile_name'])) . "%'";
        }

        if (!empty($data['filter_model'])) {
            $sql .= " AND p.model LIKE '%" . $this->db->escape(trim($data['filter_model'])) . "%'";
        }

        if (isset($data['filter_price']) && !is_null($data['filter_price'])) {
            $sql .= " AND p.price LIKE '" . $this->db->escape($data['filter_price']) . "%'";
        }

        if (isset($data['filter_quantity']) && !is_null($data['filter_quantity'])) {
            $sql .= " AND p.quantity = '" . (int)$data['filter_quantity'] . "'";
        }

        if (isset($data['filter_status'])) {
            $sql .= " AND p.status = '" . (int)$data['filter_status'] . "'";
        }

        if (isset($data['filter_lazada_status']) && !is_null($data['filter_lazada_status'])) {
            $sql .= " AND cup.lazada_status = '" . $data['filter_lazada_status'] . "'";
        }

        $sql .= " GROUP BY p.product_id";

        $query = $this->db->query($sql);

        return $query->num_rows;
    }

    public function getAllProfiles()
    {
        $query = $this->db->query("SELECT * FROM `".DB_PREFIX."cedlazada_profile`");
        if ($query->num_rows) {
            return $query->rows;
        } else {
            return array();
        }
    }

    public function getAllLazadaProductIds() {
        $product_ids = array();
        $query = $this->db->query("SELECT `product_id` FROM `" . DB_PREFIX . "cedlazada_profile_products`");
        if ($query && $query->num_rows) {
            foreach ($query->rows as $key => $value) {
                if (isset($value['product_id']) && $value['product_id']) {
                    $product_ids[] = $value['product_id'];
                }
            }
        }
        return $product_ids;
    }

     public function getlazadaStatuses()
    {
        return array(
            'NOT_UPLOADED' => 'Not Uploaded',
            'UPLOADED' => 'Uploaded',
            'DELETED' => 'Deleted'
        );
    }
}