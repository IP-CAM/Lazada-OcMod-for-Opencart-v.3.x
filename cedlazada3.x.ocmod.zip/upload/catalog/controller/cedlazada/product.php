<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedlazada
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

class ControllerCedlazadaProduct extends Controller {
    private $error = array();

    public function addNewProduct() {

        // $this->load->language('cedlazada/product');
        $this->load->model('cedlazada/product');

        $response = $this->model_cedlazada_product->addNewProduct();

        if(isset($response['success']) && !empty($response['message']))
            $this->response->setOutput(json_encode($response));
        else
            $this->response->setOutput(json_encode(array('success' => false, 'message' => ' Error Updating Products.')));
    }

    public function updateStock()
    {
        // $this->load->language('cedlazada/product');
        // $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('cedlazada/product');

        $productIds = $this->model_cedlazada_product->getAllLazadaProductIds();
        if (!empty($productIds) && is_array($productIds)) {
            $product_ids = $productIds;
            if (is_array($product_ids) && count($product_ids)) {
                $this->load->library('cedlazada');
                $cedlazada = Cedlazada::getInstance($this->registry);
                $result = $cedlazada->updatePriceQuantity($product_ids);
                
                if(isset($result['success']) && $result['success'] == true){
                    $this->response->setOutput(json_encode($result));
                    // $this->session->data['success'] = $result['message'];
                } else {
                    $this->response->setOutput(json_encode($result));
                    // $this->error['warning'] = $result['message'];
                }
            }
        } else {
            $this->response->setOutput(json_encode(array('success' => false, 'message' => ' Error while updating stock.')));
            // $this->error['warning'] = 'Error while updating stock.';
        }
        // $this->getList();
    }

}