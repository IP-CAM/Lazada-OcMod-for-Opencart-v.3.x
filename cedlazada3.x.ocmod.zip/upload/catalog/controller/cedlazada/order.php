<?php
require_once DIR_SYSTEM."library/lazada-sdk/Autoloader.php";
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedlazada
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
class ControllerCedlazadaOrder extends Controller
{
	
	public function fetchOrder()
    {
    	$json = array();
    	$postData = array(
            'created_after' => date('Y-m-d h:i:s a')
        );
    	
    	$this->load->library('cedlazada');
        $cedlazada = Cedlazada::getInstance($this->registry);
        $config = $cedlazada->getAppData();
        $cedlazada->getFailureReason($config);
        $cedlazada->getShipmentProviders($config);

        $order = new \Lazada\Sdk\Api\Order($config);
        $response = $order->getOrders($postData);
        // echo '<pre>'; print_r($response); die;

        if(isset($response['code']) && $response['code'] == 0){
            $response = json_decode($response, true);
            $res = $cedlazada->fetchOrder($response, $config);
            
            if(isset($res['success']) && $res['success']){
                $json['success'] = true;
                $json['message'] = 'Order Fetched Successfully!';
                if(!empty($res['message']))
                    $json['message'] = $res['message'];
            } else {
                $json['success'] = false;
                $json['message'] = $res['message'];
            }
        } else {
            $json['success'] = false;
            $json['message'] = $response['message'];
        }

    	$this->response->setOutput(json_encode($json));
    }
}