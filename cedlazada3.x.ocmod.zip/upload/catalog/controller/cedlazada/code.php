<?php
class ControllerCedlazadaCode extends Controller {

    public function getCode()
    {
        $json = array();
        if(!empty($this->request->get['code']))
        {
            $code = $this->request->get['code'];

            $params = array(
                'code'              => $code,
                'app_key'           => $this->config->get('ced_lazada_app_key'),
                'app_secret'        => $this->config->get('ced_lazada_app_secret')
            );

            $this->load->library('cedlazada');
            $cedlazada = Cedlazada::getInstance($this->registry);
            $res = $cedlazada->getAccessTokenFromLazada($params);
            //echo '<pre>'; print_r($res); die;
            // code = 0_110907_RUmgZixNnrN32ATUPWAu471R6164
            //
            if(isset($res['message']) && $res['message'])
            {
                $json['success'] = false;
                $json['message'] = $res['message'];
            } else {
                $this->updateValue($code, $res);

                $json['success'] = true;
                $json['message'] = 'Code Accessed Successfully. Please Once refresh Configuration page';
                $json['data'] = array('code' => $code, 'access_token' => $res['access_token'], 'refresh_token' => $res['refresh_token']);
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'Code not found';
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function updateValue($code, $response){

        $this->db->query("UPDATE " . DB_PREFIX . "setting SET `value` = '" . $this->db->escape($code) . "' WHERE `code` = 'ced_lazada' AND `key` = 'ced_lazada_code' AND store_id = '0'");

        foreach($response as $key => $value)
        {
            if($key == 'refresh_token' || $key == 'access_token' || $key == 'refresh_expires_in' || $key == 'expires_in')
            {
                $this->db->query("DELETE FROM  " . DB_PREFIX . "setting WHERE `key` = 'ced_lazada_".$key."' AND `code` = 'ced_lazada' ");

                $this->db->query("INSERT INTO " . DB_PREFIX . "setting SET `code` = 'ced_lazada', `key` = 'ced_lazada_".$key."', `value` = '" . $this->db->escape($value) . "', `store_id` = 0 ");
            }
        }
    }
}